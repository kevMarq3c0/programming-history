﻿using HelpdeskViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Reflection;

namespace ExercisesWebsite.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        //The client is going to request data and it will pass along a variable called lastname
        [HttpGet("{email}")]
        //We are going to use lastname variable in the method 
        public async Task<IActionResult> GetByLastname(string email)
        {
            //IActionResult controller is controlling this instance to a JSON object, and sending it back
            try
            {
                //Set up a new viewmodel and set the value of the lastname equal to the lastname string variable 
                EmployeeViewModel viewmodel = new() { Email = email };
                await viewmodel.GetByEmail();
                //OK is going to send a 200, which means things worked 
                return Ok(viewmodel);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " +
                MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                //This will send a 500, which means something has gone wrong 
                return StatusCode(StatusCodes.Status500InternalServerError); // something went wrong
            }
        }
    }
}

