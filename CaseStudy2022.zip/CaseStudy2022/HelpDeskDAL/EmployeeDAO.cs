﻿using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Reflection;

namespace HelpDeskDAL
{
   
    public class EmployeeDAO
    {
        public async Task<Employee> GetByEmail(string email)
        {
            Employee? selectedEmp;
            try
            {
                HelpDeskContext _db = new();
                selectedEmp = await _db.Employees.FirstOrDefaultAsync(stu => stu.Email == email);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            return selectedEmp!;
        }

        public async Task<Employee> GetByID(int id)
        {
            Employee? selectedEmployee;
            try
            {
                HelpDeskContext _db = new();
                selectedEmployee = await _db.Employees.FindAsync(id);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            return selectedEmployee!;
        }

        public async Task<List<Employee>> GetAll()
        {
            List<Employee> allEmployees;
            try
            {
                HelpDeskContext _db = new();
                allEmployees = await _db.Employees.ToListAsync();
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            return allEmployees;
        }

        public async Task<int> Add(Employee newEmployee)
        {
            try
            {
                HelpDeskContext _db = new();
                await _db.Employees.AddAsync(newEmployee);
                await _db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            return newEmployee.Id;
        }

        public async Task<int> Update(Employee updatedEmployee)
        {
            int employeeUpdated = -1;
            try
            {
                HelpDeskContext _db = new();
                Employee? currentEmployee = await _db.Employees.FirstOrDefaultAsync(emp => emp.Id == updatedEmployee.Id);
                _db.Entry(currentEmployee!).CurrentValues.SetValues(updatedEmployee);
                employeeUpdated = await _db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            return employeeUpdated;
        }

        public async Task<int> Delete(int? id)
        {
            int employeesDeleted = -1;
            try
            {
                HelpDeskContext _db = new();
                Employee? selectedEmployee = await _db.Employees.FirstOrDefaultAsync(emp => emp.Id == id);
                _db.Employees.Remove(selectedEmployee);
                employeesDeleted = await _db.SaveChangesAsync(); 
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            return employeesDeleted;
        }
    }

}
