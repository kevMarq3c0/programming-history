﻿/*
 * Program: Program.cs
 * Date: 2024-01-27
 * Author: Kevin Marquez #1054838
 * Purpose: This is the console client where we will test our Shuffler methods from GenShuffler.cs and Shuffler.cs using Generic Lists of type String and Float.
 */

namespace Exercise2_KM
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Create two generic List objects and populate them with three string elements each
            List<string> list1 = new List<string>
            {
                "Hello",
                "There",
                "General",
            };
            List<string> list2 = new List<string>
            {
                "Kenobi",
                "You are",
                "A Bold One",
            };

            //Create a new generic list to get the results out of invoking the generic method "Shuffle" from our Shuffler class
            List<string> list3 = Shuffler.Shuffle(list1, list2);

            //Print a title to display the elements and change the foreground text of the console for the strings
            Console.WriteLine("A shuffled list of string elements: ");
            Console.ForegroundColor = ConsoleColor.Yellow;

            //Use a foreach loop to display all the elements of list3
            foreach(string elementString in list3)
            {
                Console.WriteLine(elementString);
            }

            //Create two generic list objects and populate them with three float elements each
            List<float> lhsFloats = new List<float>
            {
                0.1234f,
                1.2345f,
                2.3456f,
            };
            List<float> rhsFloats = new List<float>
            {
                3.4567f,
                4.5678f,
                5.6789f,
            };

            //Generate a new GenShuffler object and pass the argument of float for Type T
            GenShuffler<float> floatShuffer = new();
            //Call the ShuffleValueTypes method from our generic GenShuffler class to populate a third list of floats
            List<float> floatList = floatShuffer.ShuffleValueTypes(lhsFloats, rhsFloats);

            //Print a title to display the elements and change the foreground text of the console for the floats
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\nA shuffled list of float elements: ");
            Console.ForegroundColor = ConsoleColor.Green;

            //Use a foreach loop to print each element to the console
            foreach(float floatElement in floatList)
            {
                Console.WriteLine(floatElement);
            }

            //Return the console foreground colour to white
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}