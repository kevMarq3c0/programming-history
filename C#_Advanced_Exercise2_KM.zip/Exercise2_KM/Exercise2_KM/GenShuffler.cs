﻿/*
 * Program: GenShuffler.cs
 * Date: 2024-01-27
 * Author: Kevin Marquez #1054838
 * Purpose: This is a generic class which only accepts value types as a result of the parameter T constraint "where T : struct".
 *          This class holds a non-generic method which will shuffle two generic lists and output one generic list using a while loop.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2_KM
{
    //The generic parameter T must be restricted to accept only value types
    public class GenShuffler<T> where T : struct
    {
        /*
         * Method Name: ShuffleValueTypes
         * Purpose: It will shuffle two generic lists and populate a generic list with their contents
         * Accepts: Two Lists of type T
         * Returns: A List of Type T
         */
        public List<T> ShuffleValueTypes(List<T> lhsList, List<T> rhsList)
        {
            //Declare a List that we will return
            List<T> outputList = new List<T>();

            //Calculate the number of items in the list by doubling the size of the inputted lists (we assume they are both the same size)
            int outputSize = lhsList.Count * 2;
            
            //Declare a Random object to help us shuffle items into the outputList
            Random randomChoice = new Random();

            //Use a while loop to keep populating the outputList even if either input list is empty
            while (outputSize > 0) {
                //Decrement the number of elements needed in the list as we add elements
                outputSize--;
                //Check if both input lists are not empty
                if(lhsList.Count != 0 && rhsList.Count != 0)
                {
                    //Generate 1 or 2 randomly and store the value in an int
                    int randomNum = randomChoice.Next(1, 3);
                    //Use the ternary conditional operator to assign a random index of either input list to an item of type T
                    T item = randomNum == 1
                        ? lhsList[randomChoice.Next(0, lhsList.Count)] //the Random object will generate a number between 0 and the current size of the list, which will shrink over time
                        : rhsList[randomChoice.Next(0, rhsList.Count)];

                    //Remove the item from the list that was chosen so it will eventually get empty
                    if(randomNum == 1)
                        lhsList.Remove(item);
                    else
                        rhsList.Remove(item);

                    //Add the item of type T to the outputList
                    outputList.Add(item);
                }
                else if (lhsList.Count != 0)
                {
                    //If the right hand input list is empty, then add a random item from the left hand list to the outputList
                    T item = lhsList[randomChoice.Next(0, lhsList.Count)];
                    //Ensure to remove the item from the input list 
                    lhsList.Remove(item);
                    outputList.Add(item);
                }
                else
                {
                    //If the left hand input list is empty, then add a random item from the right hand list to the outputList
                    T item = rhsList[randomChoice.Next(0, rhsList.Count)];
                    //Ensure to remove the item from the input list 
                    rhsList.Remove(item);
                    outputList.Add(item);
                }
            }
            //Once the outputList has all the contents of both input lists, return the outputList
            return outputList;
        }
    }
}
