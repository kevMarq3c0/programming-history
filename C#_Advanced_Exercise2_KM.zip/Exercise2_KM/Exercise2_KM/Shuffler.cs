﻿/*
 * Program: Shuffler.cs
 * Date: 2024-01-27
 * Author: Kevin Marquez #1054838
 * Purpose: This is a non-generic class that contains a static generic method called "Shuffle" which will combine two generic lists and shuffle their contents to initialize a single generic list using OrderBy() and AddRange.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2_KM
{
    public class Shuffler
    {
        /*
        * Method Name: Shuffle
        * Purpose: It will shuffle two generic lists and populate a generic list with their contents using OrderBy() and AddRange
        * Accepts: Two Lists of type T
        * Returns: A List of Type T
        */
        public static List<T> Shuffle<T>(List<T> lhsList, List<T> rhsList) 
        {
            //Declare a generic List that we will return
            List<T> outputList = new List<T>();

            //Concatenate the two Generic input Lists as we assume both lists are the same size, thus doubling the size of the generic lists for the outputList
            lhsList.AddRange(rhsList);

            //Using the OrderBy() method, sort the elements in the list in a random sequence using Random.Shared.Next() which will pass a random integer
            //and convert that to a list to initialize the output list with elements
            outputList = lhsList.OrderBy(item => Random.Shared.Next()).ToList();

            //Return the output list with the shuffled elements from both input lists
            return outputList;
        }
    }
}
