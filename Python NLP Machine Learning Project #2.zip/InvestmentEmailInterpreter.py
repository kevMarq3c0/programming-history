#   =============================================
#   Author(s)   Kevin Marquez, Tuvia Nacshonov
#   Date        November 28 2024
#   Function    spaCy + Python: Stock Buy/Sell Estimator
#   =============================================

# Import the necessary libraries
import spacy
import re
import os
# Load in the medium sized English pipeline from spaCy
nlp = spacy.load('en_core_web_md')

# Grab the current directory where the script is located
script_dir = os.path.dirname(os.path.abspath(__file__))

# Generate the file path of the EmailLog.txt and SummaryReport.txt relative to the current directory of the Python Script
email_file_path = os.path.join(script_dir, 'EmailLog.txt')
output_file_path = os.path.join(script_dir, 'SummaryReport.txt')

# Open the files for Reading and Writing respectively
foutput = open(output_file_path, mode='wt', encoding='utf-8')
femail = open(email_file_path, mode='r', encoding='utf-8')

# Global variables declared to be used during our document processing
emailstr = ''
totalRequests = {}
totalCount = 0

# Function get_investment_amount will be triggered once a dollar sign token has been found
def get_investment_amount(token, doc):
    # We will grab the current text of the token and the index of the next token
    phrase = token.text
    i = token.i+1
    # Loop through all subsequent tokens with the tag CD to locate our numeric values to get the investment amount
    while doc[i].tag_ == 'CD':
        # Grab the children of the current token to check if there is a compound number such as 50 thousand
        doc_children = doc[i].children
        compoundNum = False
        # Iterate through the children of the token to see if there is a compound number
        for child in doc_children:
            if child.dep_ == "compound" and child.pos_ == "NUM":
                # If there is a compound number, then remove the last character of the string and instead convert the written form to its numeric form
                compoundNum = True
                phrase = phrase[:-1]
                if doc[i].text == 'thousand':
                    phrase += ',000 '
                elif doc[i].text == 'hundred':
                    phrase += '00'
        # If no compound was found, then add the number
        if compoundNum == False:
            phrase += doc[i].text + ' '
        # Increment the index to continue to the next token
        i += 1
    # Return the full investment amount
    return phrase[:-1]

# Function get_organization will find the organizations described in the document
def get_organization(token, compoundFound):
    # Iterate through the children of the document in case an organization is a compound
    for child in token.children:
        # If a compound is found, return the actual name of the organization instead
        if child.dep_ == "compound":
            compoundFound = True
            return child.text
    # If no compound was found, return the organization name
    if compoundFound == False:
        return token.text

# Function format_currency will format numerical data to currency without decimal points
def format_currency(amount):
    return '${:,}'.format(amount)

# Function calculate_amount will calculate the total investment amount in one email
def calculate_amount(investments):
    amount = 0
    # Iterate through the dictionary object to get each investment amount and calculate the total
    for x in investments:
        amountStr = investments[x]
        # Strip the string of the dolalr sign and of its comma separators to convert to numerical data
        amountStr = amountStr.lstrip('$')
        amount += int(amountStr.replace(',', ''))
    # Return the total investment amount
    return amount

# Function calculate_total_requests will calculate the total of all the investment amounts in EmailLog
def calculate_total_requests(investmentAmounts):
    totalAmount = 0
    for x in investmentAmounts:
        totalAmount += investmentAmounts[x]
    # Return the total request amount as currency format with two decimal points
    return '${:,.2f}'.format(totalAmount)

# Function list_organizations will list all the organizations specified in an email in a singular string
def list_organizations(organizations):
    organizationList = ''
    # If there is only one organization specified in the email, return the email
    if len(organizations) == 1:
        return organizations[0]
    # If there are two organizations specified in the email, concatenate them with 'and' in between then return the string
    elif len(organizations) == 2:
        return organizations[0] + ' and ' + organizations[1]
    # if there are more than two organizations, concatenate all organizations in one string
    else:
        for x in organizations:
            if x == (len(organizations) - 1):
                organizationList += 'and ' + organizations[x]
            else:
                organizationList += organizations[x] + ', ' 
    # Return the full list of organizations
    return organizationList

# Loop through the EmailLog
for line in femail:
    # Strip all of the newline characters
    line = line.strip('\n')
    # Check to see if one of the words matches email format with regex, if there is one, print with a ':' for easier processing
    isEmail = re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', line)
    if isEmail :
        emailstr += line + ": "
    else :
        # If the document has reached an <<End>>, it is the end of the email entry and will begin processing
        if line == '<<End>>':
            # Create the sequence of tokens from the string we created reading in the email entry
            doc = nlp(emailstr)
            # Create the necessary dictionary objects to hold our investments and organizations within the entry
            investments = {}
            organizations = {}
            # Declare the email variable and the counters to hold our investments and organizations
            email = ''
            ic = 0
            oc = 0
            # Loop through the doc to get each Token object
            for token in doc:
                compoundFound = False
                # If a Token matches an email, then store it in our email variable and write to the Summary Rpoert
                if token.like_email:
                   foutput.write(token.text + ": ")
                   email = token.text
                # If a token is an entity and it is not a punctation, then process
                if token.ent_type != 0 or token.pos_ != "PUNCT":
                    # If a dollar sign tag is found on the token, begin processing the investment amount
                    if token.tag_ == '$':
                        # Store the investment in our dictionary object and increment the counter
                        investments.update({ic:get_investment_amount(token, doc)})
                        ic += 1
                    # If the token is an object of a preposition and isn't a MONEY entity type, then begin processing the organization
                    elif token.dep_ == 'pobj' and not token.ent_type_ == 'MONEY':
                        # Store the organization in our dictionary object and increment the counter
                        organizations.update({oc:get_organization(token, compoundFound)})
                        oc += 1
            # Calculate the total investment amount of the entry and store within our total requests dictionary object and increment the counter
            investmentAmount = calculate_amount(investments)
            totalRequests.update({totalCount:investmentAmount})
            totalCount += 1

            # Print the investment amounts and organizations of the entry to the Summary Report and the console
            foutput.write(format_currency(investmentAmount) + " to ")
            foutput.write(list_organizations(organizations) + '. ')
            print(email + ": " + format_currency(investmentAmount) + " to " + list_organizations(organizations) + ".", end=" ")

            # List the details for associating dollary amounts allocated for each company
            for x in investments:
                # Get the allocated amount for the respective company and convert it into numerical data to format later
                allocatedAmountStr = investments[x]
                allocatedAmountStr = allocatedAmountStr.lstrip('$')
                allocatedAmount = int(allocatedAmountStr.replace(',', ''))
                
                # If there is only one organization, then the prior print to console and file is sufficient, add a newline character
                if len(organizations) == 1:
                    foutput.write('\n')
                    print()
                # If there are two organizations specified in the email, print the dollar amounts allocated for each company
                if len(organizations) == 2:
                    if(x != (len(organizations) - 1)):
                        foutput.write(format_currency(allocatedAmount) + " to " + organizations[x] + " and ")
                        print(format_currency(allocatedAmount) + " to " + organizations[x] + " and", end=" ")
                    else:
                        foutput.write(format_currency(allocatedAmount) + " to " + organizations[x] + ".\n")
                        print(format_currency(allocatedAmount) + " to " + organizations[x] + ".")
                # if there are more than two organizations, concatenate print the dollar amounts allocated for each company
                elif len(organizations) > 2:
                    if x == (len(organizations) - 1):
                        foutput.write("and " + format_currency(allocatedAmount) + " to " + organizations[x] + ".\n")
                        print("and " + format_currency(allocatedAmount) + " to " + organizations[x] + ".")
                    else:
                        foutput.write(format_currency(allocatedAmount) + " to " + organizations[x] + ", ")
                        print(format_currency(allocatedAmount) + " to " + organizations[x] + ",", end=" ")
            # Empty our string to have a fresh start for the next Email Entry
            emailstr = ''
        # If the line of the Email Log is not <<End>>, keep adding to our string
        else :
            emailstr += line

# Calculate and print the total requests amount to the summary report and console
foutput.write('Total Requests: ' + calculate_total_requests(totalRequests))
print('Total Requests: ' + calculate_total_requests(totalRequests))

# Close the EmailLog and SummaryReport text files
femail.close()
foutput.close()