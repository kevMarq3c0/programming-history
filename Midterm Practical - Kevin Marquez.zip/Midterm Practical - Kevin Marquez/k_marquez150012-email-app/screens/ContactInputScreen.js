import React, {useState} from "react";
import {View, Text, TextInput, Button} from "react-native";
import {styles} from "../styles/styles";

const ContactInputScreen = ({navigation}) => {
    const [enteredContactName, setContactName] = useState();
    const [enteredContactLastName, setContactLastName] = useState();
    const [enteredContactEmail, setContactEmail] = useState();

    const contactNameInputHandler = (value) => {
        setContactName(value);
    };

    const contactLastNameInputHandler = (value) => {
        setContactLastName(value);
    };

    const contactEmailInputHandler = (value) => {
        setContactEmail(value);
    };

    const addContactHandler = () => {
        const state = {
            firstName: enteredContactName,
            lastName: enteredContactLastName,
            email: enteredContactEmail
        };
        
        setContactName('');
        setContactLastName('');
        setContactEmail('');

        navigation.navigate('MainScreen', {newContact: state}, {merge: true});
    };

    return (
        <View style={styles.inputContainer}>
            <Text style={styles.inputCaption}>First Name</Text>
            <TextInput 
                placeHolder="First Name" 
                style={styles.input} 
                onChangeText={contactNameInputHandler}
                value={enteredContactName}/>
            <Text style={styles.inputCaption}>Last Name</Text>
            <TextInput 
                placeHolder="Last Name"
                style={styles.input}
                onChangeText={contactLastNameInputHandler}
                value={enteredContactLastName}/>
            <Text style={styles.inputCaption}>Email</Text>
            <TextInput 
                placeHolder="Email Address"
                style={styles.input}
                onChangeText={contactEmailInputHandler}
                value={enteredContactEmail}/>
            <View style={styles.button}>
                <Button title="Save"
                color="blue"
                onPress={addContactHandler}/>
            </View>
        </View>
    )
};

export default ContactInputScreen;