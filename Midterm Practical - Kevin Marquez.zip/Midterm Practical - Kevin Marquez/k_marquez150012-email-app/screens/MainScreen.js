import React, {useState} from "react";
import {View, Text, FlatList} from "react-native";
import CustomHeaderButton from "../components/CustomHeaderButton";
import { styles } from "../styles/styles";
import ContactListItem from "../components/ContactListItem";

const MainScreen = ({navigation, route}) => {
    const [contactList, setContactList] = useState([]);

    const addContactItemHandler = (contactItem) => {
        setContactList(contactList => [...contactList, {key: Math.random().toString(), value: contactItem}]);
    }

    React.useLayoutEffect(() => {
        navigation.setOptions({
            headerRight: () => (
                <CustomHeaderButton
                    title="+"
                    onPress={() => navigation.navigate('ContactInputScreen')}
                />
            )
        })
    }, [navigation]);

    React.useEffect(() => {
        if(route.params?.newContact) {
            addContactItemHandler(route.params?.newContact);
        }
    }, [route.params?.newContact]);

    return (
        <View style={styles.screen}>
            <View style={styles.title}>
                <Text style={styles.titleText}>Midterm</Text>
                <Text style={styles.subtitleText}>k_marquez150012</Text>
            </View>
            <View style={styles.list}>
                <FlatList
                    data={contactList}
                    renderItem={
                        itemData => (
                            <ContactListItem
                                id={itemData.item.key}
                                item={itemData.item.value}
                            />
                        )
                    }
                />
            </View>
        </View>
    );
}

export default MainScreen;