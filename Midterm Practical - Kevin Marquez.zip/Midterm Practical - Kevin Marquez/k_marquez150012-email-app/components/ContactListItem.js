import React, {useState} from 'react';
import {View, Text, TouchableOpacity, Alert} from 'react-native';
import { styles } from '../styles/styles';
import * as MailComposer from "expo-mail-composer";

const ContactListItem = props => {
    const [message, setMessage] = useState('');

    const promptForSuccess = (status) => {
        Alert.alert(
            'Status',
            'Email was ' + status + ' to ' + props.item.email + '.',
            [
                {
                    text: 'close',
                }
            ],
            {cancelable: false},
        )
    };

    const promptForFailure = () => {
        Alert.alert(
            'Error!',
            'Email failed to send.',
            [
                {
                    text: 'close',
                },
                {cancelable: false},
            ]
        )
    }

    const sendMessageWithEmail = async () => {
        const isAvailable = await MailComposer.isAvailableAsync();

        setMessage('Dear ' + props.item.firstName + ' ' + props.item.lastName + ',');

        if(isAvailable) {
            const options = {
                recipients: [props.item.email],
                subject: 'MailComposer',
                body: message,
            }

            MailComposer.composeAsync(options)
                .then((result) => promptForSuccess(result.status));
        } else {
            promptForFailure();
        }
    };

    return (
        <TouchableOpacity activeOpacity={0.8} onPress={sendMessageWithEmail}>
            <View style={styles.listItem}>
                <Text>{props.item.firstName} {props.item.lastName} - {props.item.email}</Text>
            </View>
        </TouchableOpacity>
    );
};

export default ContactListItem;