import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import MainScreen from '../screens/MainScreen';
import ContactInputScreen from '../screens/ContactInputScreen';

const Stack = createNativeStackNavigator();

function AppNavigator() {
    return (
        <NavigationContainer>
            <Stack.Navigator
                initialRouteName="MainScreen"
                screenOptions={{
                    headerTintColor: 'white',
                    headerStyle: {backgroundColor: '#027148'},
                    headerTitleStyle: {fontWeight: 'bold'},
                    headerTitleAlign: 'center',
                }}
            >
                <Stack.Screen name="MainScreen" component={MainScreen} options={{title: 'Main Screen'}} />
                <Stack.Screen name="ContactInputScreen" component={ContactInputScreen} options={{title: 'Add Contact'}}/>
            </Stack.Navigator>
        </NavigationContainer>
    );
};

export default AppNavigator;