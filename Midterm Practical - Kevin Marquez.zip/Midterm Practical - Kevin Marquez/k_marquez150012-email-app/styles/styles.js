import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
    screen: {
        flex: 1,
        padding: 50,
        backgroundColor: '#152238'
    },
    title: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    titleText: {
        color: 'white',
        fontSize: 35,
        fontWeight: 'bold',
    },
    subtitleText: {
        color: 'white',
        fontSize: 25,
    },
    list: {
        flex: 1,
        margin: 5,
        height: 100,
        justifyContent: 'space-around',
        elevation: 1
    },
    inputCaption: {
        color: 'white',
        alignItems: 'flex-start',
        marginLeft: 30,
    },
    listItem: {
        padding: 10,
        marginVertical: 10,
        backgroundColor: '#ccc',
        borderColor: 'gray',
        borderWidth: 1,
        alignItems: 'center'
    }, 
    inputContainer: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        backgroundColor: '#152238',
    },
    input: {
        width: '80%',
        borderColor: 'grey',
        borderWidth: 1,
        backgroundColor: 'white',
        padding: 10,
        marginBottom: 15,
        marginLeft: 30,
    },
    button: {
        width: '100%',
        paddingLeft: 10,
        paddingRight: 10,
        paddingTop: -2,
        paddingBottom: -2,
        alignItems: 'center', 
    },
    navButton: {
        padding: 10,
        borderColor: 'grey',
        borderWidth: 1,
    },
    headerButtonText: {
       color: 'white',
       fontSize: 20,
    }, 
    text: {
        color: 'white',
    },
});