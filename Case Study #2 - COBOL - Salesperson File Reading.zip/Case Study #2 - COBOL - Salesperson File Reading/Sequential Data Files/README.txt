SLSPKSDS, an Essential file necessary to compile and execute JCS2LDRN, is a VSAM file created by using a Remote Connection Emulator in IBM Developer for z/OS.

As such, I cannot supply SLSPKSDS as part of the Sequential Data Files but I can provide the steps necessary to create this VSAM file.  

Log in to the TSO using the command -use command l tso.

Once inside the TSO/ISPF Environment and the ISPF menu enter the following commands.

	3 - To go to Utilities 

	2 - To create source data 
		Enter the VSAM Data Set: 
		Name - SLSPKSDS

	Press v to access VSAM Utilities 
		Enter 1 to define a process request 

		Enter 3 to give a Data Type Alias for our Cluster 

	DEFINE CLUSTER commands 
		Enter 3 into Space Units, enter 50 to the Primary Quantity, and enter 5 into Secondary Quantity  

	Press ENTER to get into the editor 

	Go 000003 and type over it using the command "I" representing Insert 
		Type in:
			INDEXED - 
			RECORDSIZE (52 52) -
			KEYS (5 0) - 

	Enter EXECUTE into the command area 

This VSAM file will be empty prior to running JCS2LDRN which will upload CS2SLSPS to the SLSPKSDS for use inside of the Case Study.