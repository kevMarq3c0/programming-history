﻿/*
 * Program: Program.cs
 * Date: 2024-03-28
 * Author: Tuvia Nacshonov, Hameedullah Sakhizada, and Kevin Marquez 
 * Purpose: This is the client which will connect to the WordleGameServer's DailyWordle service to play the daily word game via the Play RPC and retreive and display user-statistics at the end of the game
 *          via the GetStats RPC.
*/

using Google.Protobuf.Collections;
using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using Grpc.Net.Client;
using System;
using System.Text.RegularExpressions;
using System.Xml;
using WordleGameServer.Protos;

try
{
    // Connect to the server
    var channel = GrpcChannel.ForAddress("https://localhost:7052");
    var words = new DailyWordle.DailyWordleClient(channel);

    // Begin the game
    using (var call = words.Play()) 
    {
        WordGuess request = new()
        { Word = "" };

        int count = 0;
        bool win = false;
        bool validWord = false;
        bool serverDown = false;

        Console.WriteLine("+---------------------+");
        Console.WriteLine("|    W O R D L E D    |");
        Console.WriteLine("+---------------------+");
        Console.WriteLine("\nYou have 6 chances to guess a 5-letter word.");
        Console.WriteLine("Each guess must be a 'playable' 5 letter word.");
        Console.WriteLine("After a guess the game will display a series of");
        Console.WriteLine("characters to show you how good your guess was.");
        Console.WriteLine("x - means the letter above is not in the word.");
        Console.WriteLine("? - means the letter should be in another spot.");
        Console.WriteLine("* - means the letter is correct in this spot.");

        Console.WriteLine("\n     Available: a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z\n");

        do
        {
            // Get user input
            count++;
            string input = getUserInput(count);

            // Validate user input
            do
            {
                request.Word = input;
                await call.RequestStream.WriteAsync(request);

                await call.ResponseStream.MoveNext();
                WordResponse res = call.ResponseStream.Current;

                if (res.Word == "WordServer not available")
                {
                    Console.WriteLine("\nERROR: The word service is not currently available.");
                    Console.ReadKey();
                    serverDown = true;
                    break;
                }

                // Make sure the entered word is a valid word that exists in the JSON file
                if (!(validWord = res.ValidWord)) 
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\nError: The entered word is not a valid word. Please enter a valid 5 letter word.\n");
                    Console.ResetColor();

                    input = getUserInput(count);
                }

            } while (!validWord);

            if (serverDown)
                break;

            WordResponse response = call.ResponseStream.Current;

            // Print the result of the guess
            Console.Write("     ");
            printColouredGuess(response.Word);

            // Print info about the included, availabled and excluded letters
            printLetterInfo(response.GuessInfo);

            // Check if the user guessed correctly
            win = response.GuessCorrect;

            // Check if the game is over
            if (response.GameOver)
            {
                break;
            }

        } while (count < 6);

        if(!serverDown)
        {
            // Print win or lose
            if (win)
            {
                Console.WriteLine("\nYou win!\n");
            }
            else
            {
                Console.WriteLine("\nYou lose.\n");
            }

            // Print statistics
            Console.WriteLine("Statistics");
            Console.WriteLine("----------\n");

            Empty emptyRequest = new();
            var results = words.GetStats(emptyRequest);
            Console.WriteLine(results.Result);
        }

        Console.ReadKey();
    }

}
catch (RpcException)
{
    Console.WriteLine("\nERROR: The wordle game service is not currently available.");
}


/*
* Method Name: printLetterInfo
* Purpose: This method will print the letter information to the console of letters that are in the word from word guesses and those that aren't, as well as the remaining available letters
* Accepts: A RepeatedField of type int 
* Returns: Nothing
*/
static void printLetterInfo(RepeatedField<int> letterInfo) 
{
    // Stores the letter information
    List<char> includedLetters = new List<char>();
    List<char> availableLetters = new List<char>();
    List<char> excludedLetters = new List<char>();

    // Sorting the letters into their proper lists
    for (int i = 0; i < letterInfo.Count; i++)
    {
        if (letterInfo[i] == 1 || letterInfo[i] == 2)
        {
            includedLetters.Add(Convert.ToChar('a' + i));
        }
        else if (letterInfo[i] == 3)
        {
            excludedLetters.Add(Convert.ToChar('a' + i));
        }
        else 
        {
            availableLetters.Add(Convert.ToChar('a' + i));
        }
    }

    // Printing the letter info
    Console.ForegroundColor = ConsoleColor.Green;
    Console.WriteLine($"\n\n     Included:  {string.Join(",", includedLetters)}");
    Console.ResetColor();

    Console.WriteLine($"     Available: {string.Join(",", availableLetters)}");

    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine($"     Excluded:  {string.Join(",", excludedLetters)}\n");
    Console.ResetColor();
}

/*
* Method Name: IsValidInput
* Purpose: This method will check if the input is only letters and is 5 characters long
* Accepts: A string 
* Returns: A boolean
*/
static bool IsValidInput(string input)
{
    // Checking if input contains only letters and is 5 characters long
    return Regex.IsMatch(input, "^[a-zA-Z]+$") && input.Length == 5;
}


/*
* Method Name: getUserInput
* Purpose: This method will keep prompting the user for input until valid input is passed
* Accepts: An int
* Returns: A string
*/
static string getUserInput(int count) 
{
    string input = "";
    do
    {
        // Getting and validating user input (does not include the Valid word validation)
        Console.Write($"({count}). ");
        Console.ForegroundColor = ConsoleColor.DarkYellow;
        input = Console.ReadLine() ?? "";
        Console.ResetColor();

        // Validate the input
        if (!IsValidInput(input))
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\nError: Input should contain only letters and be exactly 5 letters long.\n");
            Console.ResetColor();
        }

    } while (!IsValidInput(input));

    return input;
}

/*
* Method Name: printColouredGuess
* Purpose: This method will print the letters that have been guessed and give them a colour based on if it is the right letter and if it is in the right spot or not
* Accepts: A string 
* Returns: Nothing
*/
static void printColouredGuess(string guess) 
{
    for (int i = 0; i < guess.Length; i++)
    {
        if (guess[i] == 'x')
        {
            // Prints the 'x' as plain white
            Console.Write(guess[i]);
        }
        else if (guess[i] == '*')
        {
            // Prints the '*' as green
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write(guess[i]);
            Console.ResetColor();
        }
        else if (guess[i] == '?')
        {
            // Prints the '?' as dark yellow
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.Write(guess[i]);
            Console.ResetColor();
        }
    }
}
