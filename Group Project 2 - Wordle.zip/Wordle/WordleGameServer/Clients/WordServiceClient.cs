﻿/*
 * Program: WordServiceClient.cs
 * Date: 2024-03-28
 * Author: Tuvia Nacshonov, Hameedullah Sakhizada, and Kevin Marquez 
 * Purpose: This module represents the client code for the WordServer's DailyWordService. This class is static in order to maintain the same connetion to the service
 *          as long as the WordleGameServer is running. It will expose the DailyWordService's rpc methods for the DailyWordleService to use and interact with the WordServer.
*/

using Grpc.Net.Client;
using WordServer.Protos;
using Google.Protobuf.WellKnownTypes;
using Grpc.Core;

namespace WordleGameServer.Clients
{
    public static class WordServiceClient
    {
        // Maintain a connection to the DailyWordService
        public static DailyWord.DailyWordClient? _wordServer = null;

        /*
        * Method Name: GetWordOfTheDay
        * Purpose: This static method will get the Word of the Day from the WordServer
        * Accepts: Nothing
        * Returns: A string
        */
        public static string GetWordOfTheDay()
        {
            ConnectToService();

            WordResponse? response = _wordServer?.GetWord(new Empty());

            return response?.Word ?? "";
        }

        /*
        * Method Name: ValidateWordInput
        * Purpose: This static method will validate incoming word guesses to see if they are a valid word in the wordle.json file from the WordServer
        * Accepts: A string
        * Returns: A boolean
        */
        public static bool ValidateWordInput(string word)
        {
            ConnectToService();

            ValidationResult? result = _wordServer?.ValidateWord(new ValidationRequest { Word = word });

            return result?.Valid ?? false;
        }

        /*
        * Method Name: ConnectToService
        * Purpose: This static method will check if the connection to the DailyWordService is null or not, and then connect to the service if it is null
        * Accepts: Nothing
        * Returns: Nothing
        */
        private static void ConnectToService()
        {
            if(_wordServer == null )
            {
                var channel = GrpcChannel.ForAddress("https://localhost:7277");
                _wordServer = new DailyWord.DailyWordClient(channel);
            }
        }
    }
}
