import React, { useReducer, useState } from "react";
import { Routes, Route, NavLink } from "react-router-dom";
import MenuIcon from "@mui/icons-material/Menu";
import { ThemeProvider } from "@mui/material/styles";
import theme from "./week7/class1/theme";
import {
    Toolbar,
    AppBar,
    Menu,
    MenuItem,
    IconButton,
    Typography,
    Snackbar
} from "@mui/material";
import HomeComponent from "./project1/project1component";
import AlertComponent from "./project1/alertcomponent";
import AddAdvisoryComponent from "./project1/advisoryaddcomponent";
import AdvisoryListComponent from "./project1/advisorylistcomponent";

const App = () => {
    const initialState = {
        snackBarMsg: "",
        msgFromParent: "",
        gotData: false,
    };
    const reducer = (state, newState) => ({...state, ...newState});
    const [state, setState] = useReducer(reducer, initialState);
    const snackbarClose = (event, reason) => {
        if(reason === "clickaway") {
            return;
        }
        setState({gotData: false});
    };

    const msgFromChild = (msg) => {
        setState({ snackbarMsg: msg, gotData: true});
    };

    const [anchorEl, setAnchorEl] = useState(null);
    const handleClose = () => {
        setAnchorEl(null);
    };
    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };
    return (
        <ThemeProvider theme={theme}>
            <AppBar>
                <Toolbar>
                    <Typography variant="h6" color="inherit">
                        INFO3139 - MaterialUI
                    </Typography>
                    <IconButton
                        id="menubtn"
                        onClick={handleClick}
                        color="inherit"
                        style={{ marginLeft: "auto", paddingRight: "1vh" }}
                    >
                        <MenuIcon />
                    </IconButton>
                    <Menu
                        id="simple-menu"
                        anchorEl={anchorEl}
                        open={Boolean(anchorEl)}
                        onClose={handleClose}
                    >
                        <MenuItem component={NavLink} to="/home" onClick={handleClose}>
                            Home
                        </MenuItem>
                        <MenuItem component={NavLink} to="/reset" onClick={handleClose}>
                            Reset Data
                        </MenuItem>
                        <MenuItem component={NavLink} to="/add" onClick={handleClose}>
                            Add Advisory
                        </MenuItem>
                        <MenuItem component={NavLink} to="/list" onClick={handleClose}>
                            List Advisories
                        </MenuItem>
                    </Menu>
                </Toolbar>
            </AppBar>
            <Routes>
                <Route path="/" element={<HomeComponent />} />
                <Route path="/home" element={<HomeComponent />} />
                <Route path="/reset" element={<AlertComponent dataFromChild={msgFromChild}/>} />
                <Route path="/add" element={<AddAdvisoryComponent dataFromChild={msgFromChild}/>}/>
                <Route path="/list" element={<AdvisoryListComponent dataFromChild={msgFromChild} />}/>
            </Routes>
            <Snackbar
                open={state.gotData}
                message={state.snackbarMsg}
                autoHideDuration={4000}
                onClose={snackbarClose}
            />
        </ThemeProvider>
    );
};
export default App;
