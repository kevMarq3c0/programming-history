import React, { useState } from "react";
import { ThemeProvider } from "@mui/material/styles";
import FlightTakeOffIcon from '@mui/icons-material/FlightTakeoff';
import {
    Card,
    CardContent,
    Typography,
} from "@mui/material";
import theme from "./theme";
import "../App.css";

const HomeComponent = () => {
    return (
        <ThemeProvider theme={theme}>
            <Card className="card">
                <CardContent>
                    <Typography 
                        variant="h6" 
                        color="primary" 
                        style={{textAlign: "center"}}>

                        <FlightTakeOffIcon className="svg_icons"/>

                        <p>World Wide Travel Alerts</p>
                    </Typography>
                    <Typography
                        color="primary" 
                        className="footer"
                    >
                        &copy;@INFO3139 - 2023
                    </Typography>
                </CardContent>
            </Card>
        </ThemeProvider>
    );
};

export default HomeComponent;