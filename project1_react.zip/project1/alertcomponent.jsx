import React, {useReducer, useState, useEffect} from "react";
import {ThemeProvider} from "@mui/material/styles";
import FlightTakeOffIcon from '@mui/icons-material/FlightTakeoff';
import {
    Card,
    CardContent,
    Table,
    TableHead,
    TableBody,
    TableCell,
    TableContainer,
    TableRow,
    Paper,
    Typography
} from "@mui/material";
import theme from "./theme";
import "../App.css";

const AlertComponent = (props) => {
    const initialState = {
        alerts: [],
    };

    const reducer = (state, newState) => ({ ...state, ...newState});
    const [state, setState] = useReducer(reducer, initialState);
    
    const sendParentSomeData = (msg) => {
        props.dataFromChild(msg);
    }

    useEffect(() => {
        fetchAlerts();
    }, []);

    const fetchAlerts = async () => {
        try {
            sendParentSomeData("running setup...");
            //http://localhost:5000/graphql
            let response = await fetch("/graphql", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json; charset=utf-8",
                },
                body: JSON.stringify({query: "query {project1_setup{results} }"}),
            });
            let payload = await response.json();
            let resArr = [];
            resArr = payload.data.project1_setup.results
            .replace(/([.])\s*(?=[A-Z])/g, "$1|")
            .split("|");
            sendParentSomeData("alerts collection setup completed");
            setState({
                alerts: resArr,
            });
        } catch (error) {
            console.log(error);
            sendParentSomeData(`Problem loading alerts data - ${error.message}`);
        }
    };

    return (
        <ThemeProvider theme={theme}>
            <Card className="card">
                <CardContent>
                    <Typography 
                        variant="h6" 
                        color="primary" 
                        style={{textAlign: "center"}}>

                        <FlightTakeOffIcon className="svg_icons"/>

                        <p>World Wide Travel Alerts</p>
                    </Typography>
                    <TableContainer component={Paper}>
                        <Table sx={{width: "100%"}} size="small">
                            <TableHead style={{textAlign: "center"}}>
                                <TableRow>
                                    <Typography
                                        variant="h6" 
                                        color="text" 
                                    >
                                        Alert Setup - Details
                                    </Typography>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {
                                    state.alerts.map((alert) => (
                                        <TableRow
                                            key={alert}
                                            sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                                        >
                                            <TableCell component="th" scope="row">
                                                {alert}
                                            </TableCell>
                                        </TableRow>
                                    ))
                                }
                            </TableBody>
                        </Table>
                    </TableContainer>
                </CardContent>
            </Card>
        </ThemeProvider>
    );
};

export default AlertComponent;