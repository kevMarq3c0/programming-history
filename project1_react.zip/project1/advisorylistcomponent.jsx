import React, {useReducer, useState, useEffect} from "react";
import {ThemeProvider} from "@mui/material/styles";
import {
    Autocomplete,
    Card,
    CardContent,
    Radio,
    RadioGroup,
    FormControlLabel,
    FormControl,
    FormLabel,
    TextField,
    Typography,
    Table,
    TableHead,
    TableBody,
    TableCell,
    TableContainer,
    TableRow,
    Paper,
} from "@mui/material";
import theme from "./theme";
import "../App.css";
import FlightTakeOffIcon from '@mui/icons-material/FlightTakeoff';

const AdvisoryListComponent = (props) => {
    const initialState = {
        radioChoice: "Traveler",
        autocomplete: [],
        advisories: [],
        currentSelection: null,
        currentDropdown: "travelers",
        results: [],
    };

    const reducer = (state, newState) => ({...state, ...newState});
    const [state, setState] = useReducer(reducer, initialState);

    useEffect(() => {
        fetchAdvisoryData(state.radioChoice);
    }, []);

    const fetchAdvisoryData = async (radioChoice) => {
        try {
            let query;
            if(radioChoice === "Traveler")
            {
                query = JSON.stringify({query: "query {advisories{name,country,text,date}}"});
            }
            else if(radioChoice === "Region")
            {
                query = JSON.stringify({query: "query {regions}"});
            }
            else
            {
                query = JSON.stringify({query: "query {subregions}"});
            }
            //http://localhost:5000/graphql
            let response = await fetch("/graphql", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json; charset=utf-8",
                },
                body: query
            });
            let json = await response.json();
            console.log(json);
            
            if(radioChoice === "Traveler")
            {
                sendParentSomeData(`found ${json.data.advisories.length} travelers`);
                setState({
                    advisories: json.data.advisories,
                    autocomplete: json.data.advisories.map((advisory) => advisory.name),
                    currentDropdown: "travelers"
                });
            }
            else if(radioChoice === "Region")
            {
                sendParentSomeData(`found ${json.data.regions.length} regions`);
                setState({
                    autocomplete: json.data.regions,
                    currentDropdown: "regions"
                });
            }
            else
            {
                sendParentSomeData(`found ${json.data.subregions.length} subregions`);
                setState({
                    autocomplete: json.data.subregions,
                    currentDropdown: "subregions"
                });
            }
        } catch (error) {
            console.log(error);
            sendParentSomeData(`Problem loading server data - ${error.message}`);
        }
    };

    const FetchAlertsData = async(filterChoice) => {
        try {
            let query;
            if(state.radioChoice === "Traveler")
            {
                query = JSON.stringify({query: `query {advisoriesforname(name: "${filterChoice}") {country,text,date}}`});
            }
            else if(state.radioChoice === "Region")
            {
                query = JSON.stringify({query: `query {alertsforregion(region: "${filterChoice}") {name,text,date}}`});
            }
            else
            {
                query = JSON.stringify({query: `query {alertsforsubregion(subregion: "${filterChoice}") {name,text,date}}`});
            }
            //http://localhost:5000/graphql
            let response = await fetch("/graphql", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json; charset=utf-8",
                },
                body: query
            });
            let json = await response.json();
            console.log(json);

            if(state.radioChoice === "Traveler")
            {
                sendParentSomeData(`found ${json.data.advisoriesforname.length} alerts for ${filterChoice}`);
                let advisoriesAlerts = json.data.advisoriesforname.map((advisory) => {
                    const alertObj = {name: advisory.country,
                                      text: advisory.text,
                                      date: advisory.date};
                    return alertObj;
                });
                setState({
                    results: advisoriesAlerts,
                    currentSelection: filterChoice
                })
            }
            else if(state.radioChoice === "Region")
            {
                sendParentSomeData(`found ${json.data.alertsforregion.length} alerts for ${filterChoice}`);
                setState({
                    results: json.data.alertsforregion,
                    currentSelection: filterChoice
                });
            }
            else
            {
                sendParentSomeData(`found ${json.data.alertsforsubregion.length} alerts for ${filterChoice}`);
                setState({
                    results: json.data.alertsforsubregion,
                    currentSelection: filterChoice
                });
            }

        } catch (error) {
            console.log(error);
            sendParentSomeData(`Problem loading server data - ${error.message}`);
        }
    }

    const handleChange = (e) => {
        setState({radioChoice: e.target.value});
        fetchAdvisoryData(e.target.value);
    };

    const onChange = (e, selectedOption) => {
        if(selectedOption) 
        {
            FetchAlertsData(selectedOption);
        }
        else
        {
            setState({
                currentSelection: ""
            });
        }
    };

    const sendParentSomeData = (msg) => {
        props.dataFromChild(msg);
    };

    return (
        <ThemeProvider theme={theme}>
            <Card className="card">
                <CardContent>
                    <Typography 
                        variant="h6" 
                        color="primary" 
                        style={{textAlign: "center"}}>

                        <FlightTakeOffIcon className="svg_icons"/>

                        <p>World Wide Travel Alerts</p>
                    </Typography>
                    <Typography
                        variant="h6"
                        color="primary"
                        style={{textAlign: "center", marginTop: 10}}
                        >
            
                        <FormControl>
                            <FormLabel id="demo-row-radio-buttons-group-label">List Advisories By:</FormLabel>
                            <RadioGroup
                                row
                                aria-labelledby="demo-row-radio-buttons-group-label"
                                name="row-radio-buttons-group"
                                value={state.radioChoice}
                                onChange={handleChange}
                            >
                                <FormControlLabel value="Traveler" control={<Radio />} label="Traveler" />
                                <FormControlLabel value="Region" control={<Radio />} label="Region" />
                                <FormControlLabel value="Subregion" control={<Radio />} label="Sub-Region" />
                            </RadioGroup>
                        </FormControl>
                    </Typography>

                    <Autocomplete
                        id="advisories"
                        options={state.autocomplete}
                        getOptionLabel={(option) => option}
                        style={{width: 300, marginTop: 10}}
                        onChange={onChange}
                        value={state.currentSelection}
                        renderInput={(params) => (
                            <TextField
                                {...params}
                                label={state.currentDropdown}
                                variant="outlined"
                                fullWidth
                            />
                        )}
                    />

                    <TableContainer component={Paper} style={{marginTop: 20}}>
                        <Table sx={{width: "100%"}} size="small">
                            <TableHead>
                                <TableRow>
                                    <TableCell align="left">Country</TableCell>
                                    <TableCell align="left">Alert Information</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {
                                    state.results.map((alert) => (
                                        <TableRow
                                            key={alert.name}
                                            sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                                        >
                                            <TableCell component="th" scope="row">
                                                {alert.name}
                                            </TableCell>
                                            <TableCell component="th" scope="row">
                                                {alert.text}
                                                <br/>
                                                {alert.date}
                                            </TableCell>
                                        </TableRow>
                                    ))
                                }
                            </TableBody>
                        </Table>
                    </TableContainer>
                </CardContent>
            </Card>
        </ThemeProvider>
    );
};

export default AdvisoryListComponent;

/*
<TableContainer component={Paper}>
    <Table sx={{width: "100%"}} size="small">
        <TableHead>
            <TableRow>
                <TableCell align="right">Country</TableCell>
                <TableCell align="right">Alert Information</TableCell>
            </TableRow>
        </TableHead>
        <TableBody>
            {
                state.autocomplete.map((alert) => (
                    <TableRow
                        key={alert.country}
                        sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                    >
                        <TableCell component="th" scope="row">
                            {alert.country}
                        </TableCell>
                        <TableCell component="th" scope="row">
                            {alert.date}
                        </TableCell>
                    </TableRow>
                ))
            }
        </TableBody>
    </Table>
</TableContainer>
*/