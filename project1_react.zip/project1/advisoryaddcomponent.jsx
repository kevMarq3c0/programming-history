import React, {useReducer, useEffect} from "react";
import {ThemeProvider} from "@mui/material/styles";
import {
    Autocomplete,
    Card,
    CardContent,
    Button,
    TextField,
    Typography,
} from "@mui/material";
import theme from "./theme";
import "../App.css";
import FlightTakeOffIcon from '@mui/icons-material/FlightTakeoff';

const AddAdvisoryComponent = (props) => {
    const initialState = {
        name: "",
        country: "",
        text: "",
        date: "",
        currentCountry: null
    };

    const reducer = (state, newState) => ({...state, ...newState});
    const [state, setState] = useReducer(reducer, initialState);

    const sendParentSomeData = (msg) => {
        props.dataFromChild(msg);
    }

    useEffect(() => {
        fetchCountries();
    }, []);

    const fetchCountries = async () => {
        try {
            //http://localhost:5000/graphql
            let response = await fetch("/graphql", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json; charset=utf-8",
                },
                body: JSON.stringify({query: "query {alerts{country,name,text,date,region,subregion}}"}),
            });
            let json = await response.json();
            console.log(json);
            
            sendParentSomeData(`countries loaded`);
            setState({
                countries: json.data.alerts,
                countryNames: json.data.alerts.map((country) => country.name),
            });
        } catch (error) {
            console.log(error);
            sendParentSomeData(`Problem loading server data - ${error.message}`);
        }
    };
    
    const onAddClicked = async () => {
        let advisory = {
            name: state.name,
            country: state.country,
            text: state.text,
            date: (() => {
                const today = new Date();
                return `${today.getFullYear()}-${("0" + (today.getMonth() + 1)).slice(-2)}-${("0" + today.getDate()).slice(-2)} ${today.toLocaleTimeString("en-GB")}`
            })(),
        };
        let myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");
        try {
            let query = JSON.stringify({
               query: `mutation {addadvisory(name: "${advisory.name}",country: "${advisory.country}",text: "${advisory.text}", date: "${advisory.date}")
                { name, country, text, date }}`, 
            });
            console.log(query);
            //http://localhost:5000/graphql
            let response = await fetch("/graphql", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json; charset=utf-8",
                },
                body: query,
            });
            let json = await response.json();
            sendParentSomeData(`Added advisory on ${json.data.addadvisory.date}`);
            setState({
                name: "",
                country: "",
                text: "",
                date: "",
                currentCountry: null,
            });
        } catch (error) {
            sendParentSomeData(`${error.message} - advisory not added`);
        }
    };

    const handleNameInput = (e) => {
        setState({name: e.target.value});
    };

    const onChange =(e, selectedOption) => {
        if(selectedOption)
        {
            const countries = state.countries;
            const countryFound = countries.find(({name}) => name === selectedOption);
            setState({
                country: countryFound.name,
                text: countryFound.text,
                currentCountry: countryFound.name,
            });
        }
    };

    const emptyorundefined =
        state.name === undefined ||
        state.name === "" ||
        state.country === undefined ||
        state.country === "";

    return (
        <ThemeProvider theme={theme}>
            <Card className="card">
                <CardContent>
                    <Typography 
                            variant="h6" 
                            color="primary" 
                            style={{textAlign: "center"}}>

                            <FlightTakeOffIcon className="svg_icons"/>

                            <p>World Wide Travel Alerts</p>
                    </Typography>

                    <Typography 
                        variant="h5"
                        color="primary"
                        style={{textAlign: "center", marginTop: 50}}>
                        
                        <p>Add Advisory</p>
                    </Typography>

                    <TextField
                        onChange={handleNameInput}
                        placholder="Traveler's name"
                        value={state.name}
                    />
                
                    <Autocomplete
                        id="countries"
                        options={state.countryNames}
                        getOptionLabel={(option) => option}
                        style={{width: 300, marginTop: 10}}
                        onChange={onChange}
                        value={state.currentCountry}
                        renderInput={(params) => (
                            <TextField
                                {...params}
                                label="Countries"
                                variant="outlined"
                                fullWidth
                            />
                        )}
                    />
                    <p></p>
                    <Typography 
                        variant="h5"
                        color="primary"
                        style={{textAlign: "center", marginTop: 50}}
                    >
                        <Button
                            color="secondary"
                            style={{ justifyContent: "center", alignItems: "center" }}
                            onClick={onAddClicked}
                            variant="contained"
                            disabled={emptyorundefined}
                        >
                            <p>Add Advisory</p>
                        </Button>
                    </Typography>
                </CardContent>
            </Card>
        </ThemeProvider>
    );
};

export default AddAdvisoryComponent;