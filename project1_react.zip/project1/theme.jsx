import { createTheme } from "@mui/material/styles";

export default createTheme({
 typography: {
    useNextVariants: true,
 },
 palette: {
    common: {
      black: "rgba(245, 166, 35, 1)",
      white: "rgba(230, 228, 115, 1)"
    },
    background: {
      paper: "rgba(63, 65, 125, 1)",
      default: "rgba(68, 82, 133, 1)"
    },
    primary: {
      light: "rgba(80, 227, 194, 1)",
      main: "rgba(63, 181, 115, 1)",
      dark: "rgba(70, 123, 18, 1)",
      contrastText: "#fff"
    },
    secondary: {
      light: "rgba(189, 16, 224, 0.4)",
      main: "rgba(189, 16, 224, 1)",
      dark: "rgba(77, 6, 138, 1)",
      contrastText: "#fff"
    },
    error: {
      light: "rgba(249, 163, 163, 1)",
      main: "rgba(226, 28, 11, 1)",
      dark: "rgba(148, 10, 10, 1)",
      contrastText: "rgba(255, 255, 255, 1)"
    },
    text: {
      primary: "rgba(235, 149, 9, 1)",
      secondary: "rgba(224, 172, 79, 1)",
      disabled: "rgba(230, 171, 81, 1)",
      hint: "rgba(228, 155, 33, 1)"
    }
  }
});