﻿/**
 *  Class Name: Program.cs
 *  Purpose: Part of the Director project, which inherits from the DocumentFactory namespace to script how the HTML and Markdown documents will be created by reading in the input file 
 *           "CreateDocumentScript.txt", subseuqntly create the factories, documents and elements needed to assemble these files and then output them to an appropriate directory to later run the project 
 *           in Chrome.
 *  Coder: Kevin Marquez (#1054838)
 *  Date: 2023-05-28
*/
using DocumentFactory;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Director
{
    class Program
    {
        //The main method which will be called and execute our program  
        static void Main(string[] args)
        {
            //Create an array that will hold in the list of commands as well as the list from reading in the input script file - Then split this list by "#" into the array of strings
            string[] commands;
            var list = File.ReadAllText("CreateDocumentScript.txt");
            commands = list.Split('#');

            //These are local variables that will store important values such as the IDocument and IElement references needed to accomplish the commands below 
            string documentName = "";
            IDocument document = null;
            IElement element;
            string fileName = "";
            
            //This is a foreach loop that will iterate through the list of commands and break them down line by line, word by word so we know which objects to create
            foreach (var command in commands)
            {
                var strippedCommand = Regex.Replace(command, @"\t|\n|\r", "");
                var commandList = strippedCommand.Split(':');

                //If the first word of the line begins with a particular word, you will have to create a new object
                switch (commandList[0])
                {
                    case "Document":
                        // Split the commandlist by ";" then check if the document is meant to be a Markdown or a HTML document, then create accordingly 
                        var documentType = commandList[1].Split(';');
                        document = (documentType[0] == "Markdown") ? MarkdownFactory.GetInstance().CreateDocument(documentType[1]) : HTMLFactory.GetInstance().CreateDocument(documentType[1]);

                        //Store the document type name for use with the element to know which elements to create, and store the file name so we can use it for the absolute path
                        documentName = documentType[0];
                        fileName = documentType[1];
                        break;

                    case "Element":
                        // Check the document type name to determine whether we are supposed to be creating HTML elements or Markdown elements, then send the elements to the document
                        element = (documentName == "Markdown") ? MarkdownFactory.GetInstance().CreateElement(commandList[1], commandList[2]) : HTMLFactory.GetInstance().CreateElement(commandList[1], commandList[2]);
                        document.AddElement(element);
                        break;

                    case "Run":
                        // The file will run here 
                        document.RunDocument();
                        //Get the absolute path and pass that to System diagnostics so it knows to open these files in the proper directory into Chrome
                        string filePath = "file:///" + Path.GetFullPath(fileName).Replace(" ", "%20");
                        System.Diagnostics.Process.Start("chrome.exe", filePath);
                        break;

                    default:
                        break;
                } 
            }
            
        }
    }
}
