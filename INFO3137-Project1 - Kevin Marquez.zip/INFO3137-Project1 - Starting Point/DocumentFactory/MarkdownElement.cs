﻿/**
 *  Class Name: MarkdownElement.cs
 *  Purpose: A product that is a child of IElement. This is a Superclass of various MarkdownElements based on their element type
 *           to allow us to use within a MarkdownDocument to create the file from input of the CreateDocumentScript lines.
 *  Coder: Kevin Marquez (#1054838)
 *  Date: 2023-05-28
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocumentFactory
{
    public class MarkdownElement : IElement
    {
        /*
        * Method Name: toString()
        * Purpose: This will print out a Markdown formatted string based on the element type, though this is to be overrided by each child class
        * Accepts: Nothing
        * Returns: A string representing the Markdown formatted output
        */
        public virtual string toString()
        {
            return "";
        }
    }
    /**
    *  Class Name: MarkdownImage
    *  Purpose: A product that is a child of IElement. This is a child of the MarkdownElement class, and prints out a 
    *           Markdown formatted string for images
    *  Coder: Kevin Marquez (#1054838)
    *  Date: 2023-05-28
    */
    public class MarkdownImage : MarkdownElement
    {
        string props;
        public MarkdownImage(string props) 
        {
            this.props = props;
        }
        /*
         * Class Name: toString
         * Purpose: Prints out an Markdown formatted string in the style of an MarkdownImage
         * Accepts: Nothing
         * Returns: A string representing the output
         */
        public override string toString()
        {
            var markdownSyntax = props.Split(';');
            return "![" + markdownSyntax[1] + "]" + "(" + markdownSyntax[0] + " \"" + markdownSyntax[2] + "\"" + ")\n";
        }
    }
    /**
    *  Class Name: MarkdownHeader
    *  Purpose: A product that is a child of IElement. This is a child of the MarkdownElement class, and prints out a 
    *           Markdown formatted string for headers
    *  Coder: Kevin Marquez (#1054838)
    *  Date: 2023-05-28
    */
    public class MarkdownHeader : MarkdownElement 
    {
        string props;
        public MarkdownHeader(string props) 
        {
            this.props = props;
        }
        /*
         * Class Name: toString
         * Purpose: Prints out a Markdown formatted string in the style of an MarkdownHeader, it will determine what size header to print by
         *          the number provided in the properties
         * Accepts: Nothing
         * Returns: A string representing the output
         */
        public override string toString() 
        {
            var markdownProp = props.Split(';');
            string markdownSyntax;
            switch (props[0])
            {
                case '1':
                    markdownSyntax = "# " + markdownProp[1];
                    break;
                case '2':
                    markdownSyntax = "## " + markdownProp[1];
                    break;
                case '3':
                    markdownSyntax = "### " + markdownProp[1];
                    break;
                default:
                    markdownSyntax = "";
                    break;
            }
            return markdownSyntax + "\n";
        }
    }
    /**
    *  Class Name: MarkdownList
    *  Purpose: A product that is a child of IElement. This is a child of the MarkdownElement class, and prints out a 
    *           Markdown formatted string for Lists
    *  Coder: Kevin Marquez (#1054838)
    *  Date: 2023-05-28
    */
    public class MarkdownList : MarkdownElement
    {
        string props;
        public MarkdownList(string props) 
        {
            this.props = props;
        }
        /*
         * Class Name: toString
         * Purpose: Prints out a Markdown formatted string in the style of an MarkdownList, it will determine whether to print an 
         *          ordered or unordered list based on what is provided in the properties 
         * Accepts: Nothing
         * Returns: A string representing the output
         */
        public override string toString()
        {
            string[] listProps = props.Split(';');
            string markdownSyntax = "";
            bool isOrdered = false;
            if (listProps[0] == "Ordered")
            {
                isOrdered = true;
            }
            for (int i = 1; i < listProps.Length; i++)
            {
                markdownSyntax += (isOrdered == true) ? i + ". " + listProps[i] + "\n" : "* " + listProps[i] + "\n";
            }
            return markdownSyntax;
        }
    }
    /**
    *  Class Name: MarkdownTable
    *  Purpose: A product that is a child of IElement. This is a child of the MarkdownElement class, and prints out 
    *           a Markdown formatted string for Tables
    *  Coder: Kevin Marquez (#1054838)
    *  Date: 2023-05-28
    */
    public class MarkdownTable : MarkdownElement
    {
        string props;
        public MarkdownTable(string props)
        {
            this.props = props;
        }
        /*
         * Class Name: toString
         * Purpose: Prints out a Markdown formatted string in the style of an MarkdownTable, it will check if there are headers to print 
         *          and then if there is a body to print and return that output
         * Accepts: Nothing
         * Returns: A string representing the output
         */
        public override string toString()
        {
            string[] tableProps = props.Split(';');
            string markdownSyntax = "";

            for(int i = 0; i < tableProps.Length; i++)
            {
                string[] tableProp = tableProps[i].Split('$');
                if (tableProp[0] == "Head")
                {
                    string tableHeaderSplit = "";
                    for (int j = 1; j < tableProp.Length; j++)
                    {
                        markdownSyntax += "| " + tableProp[j] + " ";
                        tableHeaderSplit += "| --- ";
                    }
                    markdownSyntax += "|\n";
                    tableHeaderSplit += "|\n";
                    markdownSyntax += tableHeaderSplit;
                }
                else
                {
                    for(int j = 1; j < tableProp.Length; j++)
                    {
                        markdownSyntax += "| " + tableProp[j] + " ";
                    }
                    markdownSyntax += "|\n";
                }
            }
            return markdownSyntax;
        }
    }
}
