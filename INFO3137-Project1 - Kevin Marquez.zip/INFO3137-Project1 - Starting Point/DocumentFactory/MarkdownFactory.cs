﻿/**
 *  Class Name: MarkdownFactory.cs
 *  Purpose: This is a Concrete Factory that extends the IDocumentFactory, our Abstract Factory, to create Markdown Documents and Elements. It is 
 *           designed to be a Singleton so that only one instance of this Factory may exist and that it is easily accessible. 
 *  Coder: Kevin Marquez (#1054838)
 *  Date: 2023-05-28
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocumentFactory
{
    public class MarkdownFactory : IDocumentFactory
    {
        //A private static MarkdownFactory variable that acts as our main instance throughout the class
        private static MarkdownFactory instance;

        /*
         * Method Name: MarkdownFactory
         * Purpose: A private constructor for MarkdownFactory so that it can only be called by GetInstance()
         * Accepts: None
         * Returns: Creates an MarkdownFactory object
         */
        private MarkdownFactory() { }
        /*
         * Method Name: GetInstance()
         * Purpose: This gives the client access to our instance. It will first check to see if any instance of MarkdownFactory has been created, if not
         *          it will create one but if one exists, it will return that instance. This makes sure there is only one instance existing.
         * Accepts: Nothing, it is void 
         * Returns: A MarkdownFactory object, our instance 
         */
        public static MarkdownFactory GetInstance()
        {
            if(instance == null)
            {
                instance = new MarkdownFactory();
            }

            return instance;
        }
        /*
         * Method Name: CreateDocument 
         * Purpose: This will create and return an MarkdownDocument 
         * Accepts: A string representing the file name of the Markdown document we are creating
         * Returns: An IDocument object representing our MarkdownDocument
         */
        public IDocument CreateDocument(string fileName)
        {
            return new MarkdownDocument(fileName);
        }
        /*
         * Method Name: CreateElement
         * Purpose: This will create an MarkdownElement based on the elementType, it acts like a Factory Method in order to determine which 
         *          MarkdownElement to create and then return the newly made MarkdownElement
         * Accepts: Two strings, one representing the Markdown Element type to create, the second representing the properties and data of 
         *          this Markdown Element
         * Returns: An IElement object 
         */
        public IElement CreateElement(string elementType, string props)
        {
            switch(elementType)
            {
                case "Image":
                    return new MarkdownImage(props);
                case "Header":
                    return new MarkdownHeader(props);
                case "List":
                    return new MarkdownList(props);
                case "Table":
                    return new MarkdownTable(props);
                default:
                    return null;
            }
        }
    }
}
