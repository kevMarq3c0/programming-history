﻿/**
 *  Class Name: HTMLDocument.cs
 *  Purpose: This class represents one of our products. It extends the IDocument interface to create and run HTMLDocuments, adding HTMLElements
 *           to the Document by saving it a List of IElements and then running the Document by creating a file and adding all the Elements to it.
 *  Coder: Kevin Marquez (#1054838)
 *  Date: 2023-05-28
 */
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocumentFactory
{
    public class HTMLDocument : IDocument
    {
        //This is the List that will accept IElement parameters to store our HTMLElements which will be use when we run the document
        List<IElement> HTMLelementList = new List<IElement>();
        //These variables store the fileName and help us create the File document 
        string fileName;
        FileStream htmlFile;
        /*
         * Method Name: HTMLDocument
         * Purpose: This is a constructor for our HTMLDocument object, it will save the fileName to create a file of this HTMLDocument
         * Accepts: A string representing a fileName
         * Returns: Creates a HTMLDocument object
         */
        public HTMLDocument(string fileName)
        {
            this.fileName = fileName;
        }
        /*
         * Method Name: AddElement
         * Purpose: Adds the passed HTML Element to our list of HTMLElements for this Document
         * Accepts: An IElement object that is the HTMLElement 
         * Returns: Nothing, it only adds the element to our list 
         */
        public void AddElement(IElement element)
        {
            HTMLelementList.Add(element);
        }
        /*
         * Method Name: RunDocument
         * Purpose: Creates a file with our fileName and then loops through our list of HTMLElements, calling their toString methods and writing them to
         *          our file to generate our HTMLDocument file
         * Accepts: Nothing, it is void
         * Returns: Nothing 
         */
        public void RunDocument()
        {
            htmlFile = File.Create(fileName);
            htmlFile.Close();
            if (File.Exists(fileName))
            {
                using(TextWriter writeStream = new StreamWriter(fileName))
                {
                    writeStream.WriteLine("<!DOCTYPE html><html><head></head><body>");
                    foreach (IElement element in HTMLelementList)
                    {
                        writeStream.WriteLine(element.toString());
                    }
                    writeStream.WriteLine("</body></html>");
                }
            }
            else
            {
                Console.WriteLine("File was not created.");
            } 
        }
    }
}
