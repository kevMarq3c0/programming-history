﻿/**
 *  Class Name: MarkdownDocument.cs
 *  Purpose: This class represents one of our products. It extends the IDocument interface to create and run MarkdownDocuments, adding MarkdownElements
 *           to the Document by saving it a List of IElements and then running the Document by creating a file and adding all the Elements to it.
 *  Coder: Kevin Marquez (#1054838)
 *  Date: 2023-05-28
 */
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocumentFactory
{
    public class MarkdownDocument : IDocument
    {
        //This is the List that will accept IElement parameters to store our MarkdownElements which will be use when we run the document
        List<IElement> markdownElementList = new List<IElement>();
        //These variables store the fileName and help us create the File document 
        FileStream markdownFile;
        string fileName;
        /*
        * Method Name: MarkdownDocument
        * Purpose: This is a constructor for our MarkdownDocument object, it will save the fileName to create a file of this MarkdownDocument
        * Accepts: A string representing a fileName
        * Returns: Creates a MarkdownDocument object
        */
        public MarkdownDocument(string fileName)
        {
            this.fileName = fileName;
        }
        /*
         * Method Name: AddElement
         * Purpose: Adds the passed Markdown Element to our list of MarkdownElements for this Document
         * Accepts: An IElement object that is the MarkdownElement 
         * Returns: Nothing, it only adds the element to our list 
         */
        public void AddElement(IElement element)
        {
            markdownElementList.Add(element);
        }
        /*
         * Method Name: RunDocument
         * Purpose: Creates a file with our fileName and then loops through our list of MarkdownElements, calling their toString methods and writing 
         *          them to our file to generate our MarkdownDocument file
         * Accepts: Nothing, it is void
         * Returns: Nothing 
         */
        public void RunDocument()
        {
            markdownFile = File.Create(fileName);
            markdownFile.Close();
            if (File.Exists(fileName))
            {
                using (TextWriter writeStream = new StreamWriter(fileName))
                {
                    foreach (IElement element in markdownElementList)
                    {
                        writeStream.WriteLine(element.toString());
                    }
                }
            }
            else
            {
                Console.WriteLine("File was not created.");
            }
        }
    }
}
