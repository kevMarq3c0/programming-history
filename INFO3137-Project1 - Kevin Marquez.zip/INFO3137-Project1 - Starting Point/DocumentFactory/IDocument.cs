﻿/**
 *  Class Name: IDocument.cs 
 *  Purpose: Acts as our Abstract Product and the parent to our HTML and Markdown document objects
 *  Coder: Kevin Marquez (#1054838)
 *  Date: 2023-05-28
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocumentFactory
{
    public interface IDocument
    {
        /*
         * Method Name: AddElement
         * Purpose: Adds an element to a list in a Document object, currently empty that will be defined in child class 
         * Accepts: An IElement object 
         * Returns: Nothing, it is a void method 
         */
        void AddElement(IElement element);
        /*
         * Method Name: RunDocument
         * Purpose: Will execute and run a File and fill it with elements, currently empty that will be defined in child class
         * Accepts: Nothing
         * Returns: Nothing
         */
        void RunDocument();
    }
}
