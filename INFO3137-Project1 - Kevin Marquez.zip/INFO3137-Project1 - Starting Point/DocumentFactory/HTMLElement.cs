﻿/**
 *  Class Name: HTMLElement.cs
 *  Purpose: A product that is a child of IElement. This is a Superclass of various HTMLElements based on their element type
 *           to allow us to use within a HTMLDocument to create the file from input of the CreateDocumentScript lines.
 *  Coder: Kevin Marquez (#1054838)
 *  Date: 2023-05-28
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocumentFactory
{
    public class HTMLElement : IElement
    {
        /*
         * Method Name: toString()
         * Purpose: This will print out a HTML formatted string based on the element type, though this is to be overrided by each child class
         * Accepts: Nothing
         * Returns: A string representing the HTML formatted output
         */
        public virtual string toString()
        {
            return "";
        }
    }

    /**
     *  Class Name: HTMLImage
     *  Purpose: A product that is a child of IElement. This is a child of the HTMLElement class, and prints out a HTML formatted string for images
     *  Coder: Kevin Marquez (#1054838)
     *  Date: 2023-05-28
     */
    public class HTMLImage : HTMLElement
    {
        string props;
        public HTMLImage(string props)
        {
            this.props = props;
        }
        /*
         * Class Name: toString
         * Purpose: Prints out an HTMl formatted string in the style of an HTMLImage
         * Accepts: Nothing
         * Returns: A string representing the output
         */
        public override string toString()
        {
            var htmlSyntax = props.Split(';');

            return "<img src=\"" + htmlSyntax[0] + "\" alt=\"" + htmlSyntax[1] + "\" title=\"" + htmlSyntax[2] + "\" /><br />";
        }
    }
    /**
     *  Class Name: HTMLHeader
     *  Purpose: A product that is a child of IElement. This is a child of the HTMLElement class, and prints out a HTML formatted string for headers
     *  Coder: Kevin Marquez (#1054838)
     *  Date: 2023-05-28
     */
    public class HTMLHeader : HTMLElement
    {
        string props;
        public HTMLHeader(string props)
        {
            this.props = props;
        }
        /*
         * Class Name: toString
         * Purpose: Prints out an HTMl formatted string in the style of an HTMLHeader, depending on if it is h1, h2, or h3
         * Accepts: Nothing
         * Returns: A string representing the output
         */
        public override string toString()
        {
            var htmlProp = props.Split(';');
            string htmlSyntax;
            switch (props[0])
            {
                case '1':
                    htmlSyntax = "<h1>" + htmlProp[1] + "</h1>";
                    break;
                case '2':
                    htmlSyntax = "<h2>" + htmlProp[1] + "</h2>";
                    break;
                case '3':
                    htmlSyntax = "<h3>" + htmlProp[1] + "</h3>";
                    break;
                default:
                    htmlSyntax = "";
                    break;
            }
            return htmlSyntax;
        }
    }
    /**
     *  Class Name: HTMLList
     *  Purpose: A product that is a child of IElement. This is a child of the HTMLElement class, and prints out a HTML formatted string for lists
     *  Coder: Kevin Marquez (#1054838)
     *  Date: 2023-05-28
     */
    public class HTMLList : HTMLElement
    {
        string props;
        public HTMLList(string props) 
        {
            this.props = props;
        }
        /*
         * Class Name: toString
         * Purpose: Prints out an HTMl formatted string in the style of an HTMLList, it will determine whether to print out an ordered or unordered list
         * Accepts: Nothing
         * Returns: A string representing the output
         */
        public override string toString()
        {
            string[] listProps = props.Split(';');
            string htmlSyntax;
            bool isOrdered = false;
            if (listProps[0] == "Ordered")
            {
                htmlSyntax = "<ol>";
                isOrdered = true;
            }
            else
            {
                htmlSyntax = "<ul>";
            }

            for (int i = 1; i < listProps.Length; i++) 
            {
                htmlSyntax += "<li>" + listProps[i] + "</li>";
            }

            htmlSyntax += (isOrdered == true) ? "</ol>" : "</ul>";

            return htmlSyntax;
        }
    }
    /**
     *  Class Name: HTMLTable
     *  Purpose: A product that is a child of IElement. This is a child of the HTMLElement class, and prints out a HTML formatted string for tables
     *  Coder: Kevin Marquez (#1054838)
     *  Date: 2023-05-28
     */
    public class HTMLTable : HTMLElement
    {
        string props;
        public HTMLTable(string props)
        {
            this.props = props;
        }
        /*
         * Class Name: toString
         * Purpose: Prints out an HTMl formatted string in the style of an HTMLTable, it will check if it has headers and then the body
         * Accepts: Nothing
         * Returns: A string representing the output
         */
        public override string toString()
        {
            string[] tableProps = props.Split(';');
            string htmlSyntax = "<table>";

            for (int i = 0; i < tableProps.Length; i++)
            {
                string[] tableProp = tableProps[i].Split('$');
                if (tableProp[0] == "Head")
                {
                    htmlSyntax += "<thead><tr>";
                    for (int j = 1; j < tableProp.Length; j++)
                    {
                        htmlSyntax += "<th>" + tableProp[j] + "</th>";
                    }
                    htmlSyntax += "</tr></thead>";
                }
                else
                {
                    htmlSyntax += "<tr>";
                    for (int j = 1;j < tableProp.Length; j++)
                    {
                        htmlSyntax += "<td>" + tableProp[j] + "</td>";
                    }
                    htmlSyntax += "</tr>";
                }
            }
            htmlSyntax += "</table>";

            return htmlSyntax;
        }
    } 
}
