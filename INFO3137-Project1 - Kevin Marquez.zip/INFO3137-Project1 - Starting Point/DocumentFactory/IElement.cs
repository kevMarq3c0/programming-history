﻿/**
 *  Class Name: IElement.cs
 *  Purpose: Acts an Abstract Product and parent to our HTML and Markdown Element objects, which allows us to add concrete elements to IDocument objects
 *  Coder: Kevin Marquez (#1054838)
 *  Date: 2023-05-28
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocumentFactory
{
    public interface IElement
    {
        /*
         * Method Name: toString
         * Purpose: Acts an empty method that will be defined in our child classes to print formatted HTML and Markdown elements, this will allow us to
         *          call this method without having to cast specifically to an HTMLElement or MarkdownElement
         * Accepts: Nothing, it is void 
         * Returns: A string representing the formatted output
         */
        string toString();
    }
}
