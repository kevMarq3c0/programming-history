﻿/**
 *  Class Name: HTMLFactory.cs
 *  Purpose: This is a Concrete Factory that extends the IDocumentFactory, our Abstract Factory, to create HTML Documents and Elements. It is designed 
 *           to be a Singleton so that only one instance of this Factory may exist and that it is easily accessible 
 *  Coder: Kevin Marquez (#1054838)
 *  Date: 2023-05-28
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocumentFactory
{
    public class HTMLFactory : IDocumentFactory
    {
        //A private static HTMLFactory variable that acts as our main instance throughout the class
        private static HTMLFactory instance;

        /*
         * Method Name: HTMLFactory
         * Purpose: A private constructor for MarkdownFactory so that it can only be called by GetInstance()
         * Accepts: None
         * Returns: Creates a HTMLFactory object
         */
        private HTMLFactory() { }
        /*
         * Method Name: GetInstance()
         * Purpose: This gives the client access to our instance. It will first check to see if any instance of HTMLFactory has been created, if not
         *          it will create one but if one exists, it will return that instance. This makes sure there is only one instance existing.
         * Accepts: Nothing, it is void 
         * Returns: An HTMLFactory object, our instance 
         */
        public static HTMLFactory GetInstance()
        {
            if(instance == null)
            {
                instance = new HTMLFactory();
            }

            return instance;
        }

        /*
         * Method Name: CreateDocument 
         * Purpose: This will create and return an HTMLDocument 
         * Accepts: A string representing the file name of the HTML document we are creating
         * Returns: An IDocument object representing our HTMLDocument
         */
        public IDocument CreateDocument(string fileName)
        {
            return new HTMLDocument(fileName);
        }
        /*
         * Method Name: CreateElement
         * Purpose: This will create an HTMLElement based on the elementType, it acts like a Factory Method in order to determine which HTMLElement
         *          to create and then return the newly made HTMLElement
         * Accepts: Two strings, one representing the HTML Element type to create, the second representing the properties and data of this HTML Element
         * Returns: An IElement object 
         */
        public IElement CreateElement(string elementType, string props)
        {
            switch(elementType)
            {
                case "Image":
                    return new HTMLImage(props);
                case "Header":
                    return new HTMLHeader(props);
                case "List":
                    return new HTMLList(props);
                case "Table":
                    return new HTMLTable(props);
                default:
                    return null;
            }
        }
    }
}
