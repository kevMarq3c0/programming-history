﻿/** 
 *  Class Name: IDocumentFactory.cs
 *  Purpose: This is the interface that will facilitate our factory implementation, acting as our Abstract Factory that will be the parent of our Concrete Factories and allow us to create our 
 *           abstract products IDocument and IElement.
 *  Coder: Kevin Marquez (#1054838)
 *  Date: 2023-05-28
 */
using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentFactory
{
    //This is our Abstract Factory, we need to extend the structure though
    public interface IDocumentFactory
    {
        /*
         * Method Name: CreateDocument
         * Purpose: Acts as our Abstract Product A which will create Document(HTML or Markdown) objects
         * Accepts: a string that is our file name
         * Returns: An IDocument object
         */
        IDocument CreateDocument(string fileName);
        /*
         * Method Name: CreateElement
         * Purpose: Acts as our Abstract Product B which will create HTML or Markdown element objects to send to our Document object
         * Accepts: Two strings, one representing the type of element we are creating, and a second which represents the properties and data of the element
         * Returns: An IElement object
         */
        //Abstract Product B
        IElement CreateElement(string elementType, string props);
    }
}
