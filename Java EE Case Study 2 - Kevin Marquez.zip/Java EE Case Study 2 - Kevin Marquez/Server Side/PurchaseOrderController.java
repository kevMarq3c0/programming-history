package com.info3039case.casestudyserver.purchase;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.info3039case.casestudyserver.product.ProductRepository;
import com.info3039case.casestudyserver.product.QRCodeGenerator;
import com.info3039case.casestudyserver.vendor.VendorRepository;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.http.HttpHeaders;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import jakarta.servlet.http.HttpServletRequest;

@CrossOrigin
@RestController
public class PurchaseOrderController {
    @Autowired
    private PurchaseOrderDAO purchaseDAO;

    @Autowired
    private PurchaseOrderRepository purchaseOrderRepository;

    @Autowired
    private VendorRepository vendorRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private QRCodeGenerator qrCodeGenerator;

    @PostMapping("/api/purchaseorders")
    public ResponseEntity<PurchaseOrder> addOne(@RequestBody PurchaseOrder purchaseOrder) {
        return new ResponseEntity<PurchaseOrder>(purchaseDAO.create(purchaseOrder), HttpStatus.OK);
    }

    @GetMapping("/api/purchaseorders/{vendorid}")
    public ResponseEntity<Iterable<PurchaseOrder>> findByVendor(@PathVariable Long vendorid) {
        Iterable<PurchaseOrder> purchaseOrders = purchaseOrderRepository.findByVendorid(vendorid);
        return new ResponseEntity<Iterable<PurchaseOrder>>(purchaseOrders, HttpStatus.OK);
    }

    @GetMapping(value = "/PurchaseOrderPDF", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<InputStreamResource> streamPDF(HttpServletRequest request) throws IOException {
        String poid = request.getParameter("poid");
        ByteArrayInputStream bis = PurchaseOrderPDFGenerator.generatePurchaseOrder(
                poid,
                vendorRepository,
                productRepository,
                purchaseOrderRepository,
                qrCodeGenerator);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "inline; filename=purchaseorder-" + poid + ".pdf");

        return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF)
                .body(new InputStreamResource(bis));
    }
}
