package com.info3039case.casestudyserver.purchase;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.info3039case.casestudyserver.product.Product;
import com.info3039case.casestudyserver.product.ProductRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.time.LocalDateTime;

@Component
public class PurchaseOrderDAO {
    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private ProductRepository productRepository;

    @Transactional
    public PurchaseOrder create(PurchaseOrder purchaseFromClient) {
        PurchaseOrder realPurchase = new PurchaseOrder();
        realPurchase.setPodate(LocalDateTime.now());
        realPurchase.setVendorid(purchaseFromClient.getVendorid());
        realPurchase.setAmount(purchaseFromClient.getAmount());
        entityManager.persist(realPurchase);

        for (PurchaseOrderLineItem item : purchaseFromClient.getItems()) {
            PurchaseOrderLineItem realItem = new PurchaseOrderLineItem();
            realItem.setPoid(realPurchase.getId());
            realItem.setProductid(item.getProductid());
            realItem.setQty(item.getQty());
            realItem.setPrice(item.getPrice());

            // we also need to update the QOO on the product table
            Product prod = productRepository.getReferenceById(item.getProductid());
            prod.setQoo(prod.getQoo() + item.getQty());
            productRepository.saveAndFlush(prod);

            entityManager.persist(realItem);
        }

        entityManager.flush();
        entityManager.refresh(realPurchase);
        return realPurchase;
    }
}
