import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatComponentsModule } from '@app/mat-components/mat-components.module';
import { Purchaseorder } from '@app/purchaseorder/purchaseorder';
import { PurchaseorderLineitem } from '@app/purchaseorder/purchaseorder-lineitem';
import { PurchaseorderService } from '@app/purchaseorder/purchaseorder.service';
import { Vendor } from '@app/vendor/vendor';
import { VendorService } from '@app/vendor/vendor.service';
import { Product } from '@app/product/product';
import { ProductService } from '@app/product/product.service';
import { PDF_URL } from '@app/constants';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  ReactiveFormsModule
} from '@angular/forms';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-viewer',
  standalone: true,
  imports: [CommonModule, MatComponentsModule, ReactiveFormsModule],
  templateUrl: './viewer.component.html',
})
export class ViewerComponent implements OnInit, OnDestroy {
  // form
  generatorForm: FormGroup;
  vendorid: FormControl;
  purchaseorderid: FormControl;

  // data
  formSubscription?: Subscription;
  products: Product[] = [];
  vendors: Vendor[] = [];
  vendorProducts?: Product[] = [];
  vendorPurchaseorders: Purchaseorder[] = [];
  items: PurchaseorderLineitem[] = [];
  selectedproducts: Product[] = [];
  selectedPurchaseorder: Purchaseorder;
  selectedVendor: Vendor;

  // misc 
  pickedPurchaseorder: boolean;
  pickedVendor: boolean;
  generated: boolean;
  msg: string;
  subtotal: number;
  tax: number;
  total: number;

  constructor(
    private builder: FormBuilder,
    private vendorService: VendorService,
    private productService: ProductService,
    private purchaseorderService: PurchaseorderService
  ) {
    this.pickedVendor = false;
    this.pickedPurchaseorder = false;
    this.generated = false;
    this.msg = '';
    this.vendorid = new FormControl('');
    this.purchaseorderid = new FormControl('');
    this.generatorForm = this.builder.group({
      purchaseorderid: this.purchaseorderid,
      vendorid: this.vendorid,
    });
    this.selectedPurchaseorder = {
      id: 0,
      vendorid: 0,
      amount: 0.0,
      items: [],
      podate: '',
    };
    this.selectedVendor = {
      id: 0,
      name: '',
      address1: '',
      city: '',
      province: '',
      postalcode: '',
      phone: '',
      type: '',
      email: '',
    };
    this.pickedPurchaseorder = false;
    this.subtotal = 0.0;
    this.tax = 0.0;
    this.total = 0.0;
  }

  ngOnInit(): void {
    this.onPickVendor();
    this.onPickPurchaseorder();
    this.msg = 'loading vendor\'s purchase orders from server...';
    this.getAllVendors();
  } // ngOnInit

  ngOnDestroy(): void {
      if(this.formSubscription !== undefined) {
        this.formSubscription.unsubscribe();
      }
  } // ngOnDestroy

  getAllVendors(passedMsg: string = ''): void {
    this.vendorService.getAll().subscribe({
      next: (vendors: Vendor[]) => {
        this.vendors = vendors;
      },
      error: (err: Error) => 
        (this.msg = `Couldn't get vendors - ${err.message}`),
      complete: () => 
        passedMsg ? (this.msg = passedMsg) : (this.msg = `Vendors loaded!`),
    });
  }

  loadVendorProducts(id: number): void {
    this.msg = 'loading products...';
    this.productService
      .getSome(id)
      .subscribe((products) => (this.vendorProducts = products));
  }

  onPickVendor(): void {
    this.formSubscription = this.generatorForm
      .get('vendorid')
      ?.valueChanges.subscribe((val) => {
        this.selectedVendor = val;
        this.pickedPurchaseorder = false;
        this.purchaseorderService.getSome(this.selectedVendor.id).subscribe({
          next: (purchaseorders: Purchaseorder[]) => this.vendorPurchaseorders = purchaseorders,
          error: (err: Error) => this.msg = `Failed to load purchase orders from vendor - ${this.selectedVendor.name}: ${err.message}`,
          complete: () => this.msg = `Vendor ${this.selectedVendor.name}\'s Purchase Orders Loaded!`
        });
        this.pickedVendor = true;
        this.generated = false;
        this.items = [];
        this.loadVendorProducts(this.selectedVendor.id);
      });
  }

  onPickPurchaseorder(): void {
    const purchaseorderSubscription = this.generatorForm
      .get('purchaseorderid')
      ?.valueChanges.subscribe((val) => {
        this.selectedPurchaseorder = val;
        this.selectedproducts = this.purchaseorderProducts();
        this.pickedPurchaseorder = true;
        this.total = this.getTotal();
      });
      this.formSubscription?.add(purchaseorderSubscription);
  }

  purchaseorderProducts(): Product[] {
    return this.vendorProducts!.filter(product => 
      this.selectedPurchaseorder.items.some(item => item.productid === product.id)
    );
  }

  getTotal() : number {
    let sum: number = 0;
    this.purchaseorderProducts().forEach(product => sum += product.costprice * product.qoo);
    this.subtotal = sum;
    this.tax = this.subtotal * 0.13;
    return this.subtotal + this.tax;
  }

  viewPdf(): void {
    window.open(`${PDF_URL}${this.selectedPurchaseorder.id}`);
  }
}
