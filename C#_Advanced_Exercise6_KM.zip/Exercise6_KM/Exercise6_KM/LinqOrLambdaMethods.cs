﻿/*
 * Program: LinqOrLambdaMethods.cs
 * Date: 2024-03-25
 * Author: Kevin Marquez #1054838
 * Purpose: This static class will hold eight static methods that will use LINQ query expression notation and LINQ lambda expressions to query an array of strings and return their respective results as strings.
 */

using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise6_KM
{
    public static class LinqOrLambdaMethods
    {
        /*
        * Method Name: LinqFirstCharacter
        * Purpose: This method will create a query using query expression notation to get a string composed of the first character of every word in an array of strings
        * Accepts: An array of strings
        * Returns: A string
        */
        public static string LinqFirstCharacter(string[] words)
        {
            var firstCharacterQuery = from word in words
                                      select string.Format("{0}, ", word.Substring(0, 1));
            
            return FormQueryString(firstCharacterQuery);
        }

        /*
        * Method Name: LambdaFirstCharacter
        * Purpose: This method will create a query using LINQ lambda notation to get a string composed of the first character of every word in an array of strings
        * Accepts: An array of strings
        * Returns: A string
        */
        public static string LambdaFirstCharacter(string[] words)
        {
            var firstCharacterQuery = words.Select(word => string.Format("{0}, ", word.Substring(0,1)));

            return FormQueryString(firstCharacterQuery);
        }

        /*
        * Method Name: LinqLongestWord
        * Purpose: This method will create a query using query expression notation to find out the longest word(s) in an array of strings
        * Accepts: An array of strings
        * Returns: A string
        */
        public static string LinqLongestWord(string[] words)
        {
            var longestWordQuery = from word in words
                                   let wordLength = (from characters in words select characters.Length).Max()
                                   where word.Length == wordLength
                                   select string.Format("{0}, ", word);

            return FormQueryString(longestWordQuery);
        }

        /*
        * Method Name: LambdaLongestWord
        * Purpose: This method will create a query using LINQ lambda notation to find out the longest word(s) in an array of strings
        * Accepts: An array of strings
        * Returns: A string
        */
        public static string LambdaLongestWord(string[] words)
        {
            var longestWordQuery = words.Where(word => word.Length == words.Max(character => character.Length)).Select(word => string.Format("{0}, ", word));
            
            return FormQueryString(longestWordQuery);
        }

        /*
        * Method Name: LinqShortestWord
        * Purpose: This method will create a query using query expression notation to find out the shortest word(s) in an array of strings
        * Accepts: An array of strings
        * Returns: A string
        */
        public static string LinqShortestWord(string[] words)
        {
            var shortestWordQuery = from word in words
                                    let wordLength = (from characters in words select characters.Length).Min()
                                    where word.Length == wordLength
                                    select string.Format("{0}, ", word);

            return FormQueryString(shortestWordQuery);
        }

        /*
        * Method Name: LambdaShortestWord
        * Purpose: This method will create a query using LINQ lambda notation to find out the shortest word(s) in an array of strings
        * Accepts: An array of strings
        * Returns: A string
        */
        public static string LambdaShortestWord(string[] words)
        {
            var shortestWordQuery = words.Where(word => word.Length == words.Min(character => character.Length)).Select(word => string.Format("{0}, ", word));

            return FormQueryString(shortestWordQuery);
        }

        /*
        * Method Name: LinqWordsCount
        * Purpose: This method will create a query using query expression notation to count the words in an array of strings
        * Accepts: An array of strings
        * Returns: A string
        */
        public static string LinqWordsCount(string[] words)
        {
            var wordCount = (from word in words
                            select word).Count();

            return wordCount.ToString();
        }

        /*
        * Method Name: LambdaWordsCount
        * Purpose: This method will create a query using LINQ lambda notation to count the words in an array of strings
        * Accepts: An array of strings
        * Returns: A string
        */
        public static string LambdaWordsCount(string[] words)
        {
            int wordCount = words.Count();

            return wordCount.ToString();
        }

        /*
        * Method Name: FormQueryString
        * Purpose: This method will take the results of a query and form its contents into one string
        * Accepts: An IEnumerator of type string
        * Returns: A string
        */
        private static string FormQueryString(IEnumerable<string> query)
        {
            string queryString = "";
            foreach (var word in query)
            {
                queryString += word;
            }

            return queryString.Remove(queryString.Length - 2);
        }
    }
}
