﻿/*
 * Program: CityStatistics.cs
 * Date: 2024-03-25
 * Author: Kevin Marquez #1054838
 * Purpose: This static class will hold methods of LINQ query expression notation that will make queries on a List of City objects and return the query to use in the Main method.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise6_KM
{
    public static class CityStatistics
    {
        /*
        * Method Name: SortedCities
        * Purpose: This method will return a sorted list of cities 
        * Accepts: A List of City Object
        * Returns: An IEnumerable<City> object
        */
        public static IEnumerable<City> SortedCities(List<City> cities)
        {
            var sortedCities = from city in cities
                               orderby city.Name
                               select city;

            return sortedCities;
        }

        /*
        * Method Name: CitiesByProvince
        * Purpose: This method will return all cities in each province of a list
        * Accepts: A List of City objects
        * Returns: An IEnumerable<IGrouping<string, City>> object
        */
        public static IEnumerable<IGrouping<string, City>> CitiesByProvince(List<City> cities)
        {
            var citiesGroups = from city in cities
                               group city by city.Province into CityNameGroups
                               orderby CityNameGroups.Key
                               select CityNameGroups;
            return citiesGroups;
        }

        /*
        * Method Name: ProvincesPopulation
        * Purpose: This method will calculate the total population in each province and return the Array type containing the Province name and its total population
        * Accepts: A List of City objects
        * Returns: An Array object
        */
        public static Array ProvincesPopulation(List<City> cities)
        {
            var empCollection = from city in cities
                                group city by city.Province into CityProvinceGroups
                                select new
                                {
                                    Province = CityProvinceGroups.Key,
                                    TotalPopulation = (from city in CityProvinceGroups select city.Population).Aggregate((n1, n2) => n1 + n2)
                                };

            return empCollection.ToArray();
        }
    }
}
