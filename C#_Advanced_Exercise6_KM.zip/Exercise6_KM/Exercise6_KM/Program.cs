﻿/*
 * Program: Program.cs
 * Date: 2024-03-25
 * Author: Kevin Marquez #1054838
 * Purpose: This is the main method of the Exercise where we will test our defined LINQ query expression and lambda dot notation methods on an array of Strings and using the 
 *          CityStatistics LINQ query expression defined methods using a list of City objects.
 */

namespace Exercise6_KM
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Create the following array of strings to test all the defined methods in the LinqOrLambdaMethods class
            string[] words = { "Hi", "Canada", "Please", "Stay", "Safe" };

            //Test out the FirstCharacter methods and print the result of each test with meaningful statements
            Console.WriteLine("The word of the first character of every word in an array of strings using LINQ query:\t\t{0}", LinqOrLambdaMethods.LinqFirstCharacter(words));
            Console.WriteLine("The word of the first character of every word in an array of strings using LINQ dot notation:\t{0}", LinqOrLambdaMethods.LambdaFirstCharacter(words));

            PrintLineDividers("-");

            //Test out the LongestWord methods and print the result of each test with meaningful statements
            Console.WriteLine("The longest word(s) using LINQ query is:\t\t{0}", LinqOrLambdaMethods.LinqLongestWord(words));
            Console.WriteLine("The longest word(s) using LINQ dot notation is:\t\t{0}", LinqOrLambdaMethods.LambdaLongestWord(words));

            PrintLineDividers("-");

            //Test out the ShortestWord methods and print the result of each test with meaningful statements
            Console.WriteLine("The shortest word(s) using LINQ query is:\t\t{0}", LinqOrLambdaMethods.LinqShortestWord(words));
            Console.WriteLine("The shortest word(s) using LINQ dot notation is:\t{0}", LinqOrLambdaMethods.LambdaShortestWord(words));

            PrintLineDividers("-");

            //Test out the WordsCount methods and print the result of each test with meaningful statements
            Console.WriteLine("The number of the words in an array of strings:\t\t{0}", LinqOrLambdaMethods.LinqWordsCount(words));
            Console.WriteLine("The number of the words in an array of strings:\t\t{0}", LinqOrLambdaMethods.LambdaWordsCount(words));

            //Create a list compromising of the following City data
            List<City> cities = new List<City>()
            { 
                new City("London", "ON", 330000),
                new City("Toronto", "ON", 5213000),
                new City("Vancouver", "BC", 2313328),
                new City("Nelson", "BC", 11779),
                new City("Montreal", "QB", 3678000),
                new City("Québec", "QB", 624177),
            };

            PrintLineDividers("-");

            //Test out the SortedCities method and print to the console with meaningful statements
            Console.WriteLine("Sorted list of all cities: \n");
            foreach(City city in CityStatistics.SortedCities(cities))
            {
                Console.WriteLine(city);
            }

            PrintLineDividers("-");

            //Test out the CitiesByProvince method and print to the console with meaningful statements
            var citiesByProvince = CityStatistics.CitiesByProvince(cities);
            foreach(var cityGroup in citiesByProvince)
            {
                Console.WriteLine($"\nCities in province {cityGroup.Key}");
                PrintLineDividers("*", 25);
                foreach (var city in cityGroup)
                {
                    Console.WriteLine(city);
                }
            }

            PrintLineDividers("-");

            //Test out the ProvincesPopulation method and print to the console with meaningful statements
            Console.WriteLine("Provinces with population: \n");
            Array provincesByPopulation = CityStatistics.ProvincesPopulation(cities);
            foreach(var province in provincesByPopulation)
            {
                Console.WriteLine(province);
                PrintLineDividers("*", 44);
            }
        }

        /*
        * Method Name: PrintLineDividers
        * Purpose: This method will print line dividers to the console with a specified line divider and an optional limit
        * Accepts: A string and an optional int
        * Returns: Nothing
        */
        static void PrintLineDividers(string lineDivider, int limit = 100)
        {
            for (int i = 0; i < limit; i++)
            {
                Console.Write(lineDivider);
            }
            Console.WriteLine();
        }
    }
}
