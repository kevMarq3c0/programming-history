﻿/*
 * Program: City.cs
 * Date: 2024-03-25
 * Author: Kevin Marquez #1054838
 * Purpose: This public class will hold information on a city, its name, the province it is in and the population of the city
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise6_KM
{
    public class City
    {
        //Public properties of a City object
        public string Name { get; set; }
        public string Province { get; set; }
        public int Population { get; set; }

        //Constructor that will initialize a City object and its properties
        public City(string name, string province, int population)
        {
            Name = name;
            Province = province;
            Population = population;
        }

        /*
        * Method Name: ToString
        * Purpose: This method will override the ToString method to return the City name
        * Accepts: Nothing
        * Returns: A string
        */
        public override string ToString()
        {
            return Name;
        }
    }
}
