﻿/*
 * Program: PeriodicTable.cs
 * Date: 2024-02-03
 * Author: Tuvia Nacshonov, Hameedullah Sakhizada, and Kevin Marquez 
 * Purpose: This is a static class that provides public access to information about all the elements in the Periodic Table.
 */

using Newtonsoft.Json;

namespace StoichiometryLibrary
{
    public class PeriodicTable
    {
        //A read-only static array of type IElement that will contain an entry for each element in the Periodic Table
        //It has a hidden set so we can initialize the array
        public static IElement[]? Elements { get; private set; }

        //This constructor will grab the PeriodicTable JSON data and call a method to initialize the array of IElements
        public PeriodicTable()
        {
            string filePath = "PeriodicTableJSON.json";
            LoadPeriodicTable(filePath);
        }

        /*
        * Method Name: LoadPeriodicTable
        * Purpose: This method will read in the JSON file, deserialize it and initialize the array of Elements with its contents
        * Accepts: A string which represents the file path
        * Returns: nothing
        */
        private void LoadPeriodicTable(string filePath)
        {
            //Declare a StreamReader which will read each line of the JSON file
            using (StreamReader r = new(filePath))
            {
                string json = r.ReadToEnd();
                // Deserialize into a wrapper class that matches the JSON structure
                var periodicTable = JsonConvert.DeserializeObject<PeriodicTableWrapper>(json);
                if (periodicTable != null && periodicTable.Elements != null)
                {
                    //Copy the elements of the list into an array and initialize the Elements array
                    Elements = periodicTable.Elements.ToArray();
                }
            }
        }
    }

    /*
    * Class Name: PeriodicTableWrapper
    * Purpose: This hidden class will be used to deserialize the JSON into an object with the property of a List of elements from the JSON
    */
    internal class PeriodicTableWrapper
    {
        //This is public read-only element which will contain the Elements from the JSON file
        public List<Element> Elements { get; }
        internal PeriodicTableWrapper()
        {
            Elements = new List<Element>();
        }
    }

}