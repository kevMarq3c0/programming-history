﻿/*
 * Program: Element.cs
 * Date: 2024-02-03
 * Author: Tuvia Nacshonov, Hameedullah Sakhizada, and Kevin Marquez 
 * Purpose: This is a hidden utility class that implements the IElement and IMolecularElement interfaces and will allow us to hold the values of an Element that we parse from the JSON file.
 */

using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace StoichiometryLibrary
{
    internal class Element : IElement, IMolecularElement
    {
        //Implement the interfaces properties with a hidden set within the read-only properties and decorate the AtomicNumber and PropertyName 
        //with JsonProperty so it will be able to obtain the appropriate corresponding values from the JSON file
        [JsonProperty(PropertyName = "number")]
        public ushort AtomicNumber { get; private set; }
        public string Symbol { get; private set; }
        public string Name { get; private set; }

        [JsonProperty(PropertyName = "atomic_mass")]
        public double AtomicMass { get; private set; }
        public ushort Period { get; private set; }
        public ushort Group { get; private set; }
        public ushort Multiplier { get; set; }

        //Declare a constructor visible to the Library but hidden from the Client which will initialize an Element object and its properties
        //with values passed to it from the command line or the JSON file
        [JsonConstructor]
        internal Element(string symbol, string name, ushort atomicNumber, double atomicMass, ushort period, ushort group)
        {
            Symbol = symbol;
            Name = name;
            AtomicNumber = atomicNumber;
            AtomicMass = atomicMass;
            Period = period;
            Group = group;
        }
        
    }
}
