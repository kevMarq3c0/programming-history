﻿/*
 * Program: IMolecularElement.cs
 * Date: 2024-02-03
 * Author: Tuvia Nacshonov, Hameedullah Sakhizada, and Kevin Marquez 
 * Purpose: This class is an interface which extends the IElement interface and will hold a property which will convey the multiplicity of an element in a provided formula.
 */

namespace StoichiometryLibrary
{
    public interface IMolecularElement : IElement
    {
        //This is a readonly unsigned integer that will hold the number of occurrences of an element in a formula
        public ushort Multiplier { get; }
    }

}
