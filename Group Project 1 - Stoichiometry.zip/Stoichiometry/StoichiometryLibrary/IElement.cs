﻿/*
 * Program: IElement.cs
 * Date: 2024-02-03
 * Author: Tuvia Nacshonov, Hameedullah Sakhizada, and Kevin Marquez 
 * Purpose: This is a public interface which will represent an element in the Periodic Table and holds properties of that element that we retrieve from a JSON file.
 */

namespace StoichiometryLibrary
{
    public interface IElement
    {
        //A read-only string that contains an element's symbol in the periodic table
        public string Symbol { get; }
        //A read-only string that contains an element's name
        public string Name { get; }
        //A read-only unsigned integer that contain's an element's atomic number
        public ushort AtomicNumber { get; }
        //A read-only floating point that contains an element's atomic mass
        public double AtomicMass { get; }
        //A read-only unsigned integer that contains an element's row number in the periodic table
        public ushort Period { get; }
        //A read-only unsigned integer that contains an element's column number in the periodic table
        public ushort Group { get; }
    }

}