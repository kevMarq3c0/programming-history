﻿/*
 * Program: Molecule.cs
 * Date: 2024-02-03
 * Author: Tuvia Nacshonov, Hameedullah Sakhizada, and Kevin Marquez 
 * Purpose: This class will represent a chemical formula and will provide us with methods to allow us to validate the formula and calculate its atomic mass.
 */

using System.Text.RegularExpressions;

namespace StoichiometryLibrary
{

    // Custom class used to allow the setting of values for an IMolecularElement
    internal class MolecularElement : IMolecularElement
    {
        public string? Symbol { get; set; }
        public ushort Multiplier { get; set; }
        public string? Name { get; set; }
        public ushort AtomicNumber { get; set; }
        public double AtomicMass { get; set; }
        public ushort Period { get; set; }
        public ushort Group { get; set; }
    }

    public class Molecule
    {
        public bool Valid { get; private set; }

        public string Formula { get; set; }

        
        public Molecule()
        {
            Formula = "";
        }

        public Molecule(string formula)
        {
            Formula = formula;
        }

        /*
        * Method Name: CalcMass
        * Purpose: This method will calculate the mass of all the elements in the formula
        * Accepts: Nothing
        * Returns: A double
        */
        public double CalcMass()
        {
            // Validate the formula
            if (validateFormula())
            {
                double result = 0;

                // Retrieve the array from the GetComposition method which will have the correct counts of each element and their atomic
                // mass which will be used to do the calculation
                IMolecularElement[] molecules = GetComposition();

                foreach (var item in molecules)
                {
                    result += item.AtomicMass * item.Multiplier;
                }


                return result;
            }

            return 0;
        }

        /*
        * Method Name: GetComposition
        * Purpose: This method will return an array of IMolecularElement that contain the correct number of occurencies that
        * each element appears in the formula
        * Accepts: Nothing
        * Returns: A array of IMolecularElement
        */
        public IMolecularElement[] GetComposition()
        {
            PeriodicTable table = new PeriodicTable();
            Stack<List<MolecularElement>> elementStack = new Stack<List<MolecularElement>>();
            elementStack.Push(new List<MolecularElement>());

            bool bracketsUsed = false;

            var result = new List<MolecularElement>();
            int bracketCount = 0;

            int i = 0;
            while (i < Formula.Length)
            {
                char currentChar = Formula[i];

                // Check for the start of an element
                if (char.IsUpper(currentChar))
                {

                    string symbol = currentChar.ToString();
                    i++;

                    // Check if the element is more than 1 charcater long
                    while (i < Formula.Length && char.IsLower(Formula[i]))
                    {
                        symbol += Formula[i];
                        i++;
                    }

                    // Find the count of the element
                    int count = 0;
                    while (i < Formula.Length && char.IsDigit(Formula[i]))
                    {
                        count = count * 10 + (Formula[i] - '0');
                        i++;
                    }

                    // If no subscript was provided, set the count to 1
                    if (count == 0)
                    {
                        count = 1;
                    }

                    // Search the periodic table for the data that corresponds to the element
                    var elementInfo = PeriodicTable.Elements!.FirstOrDefault(data => data.Symbol == symbol);

                    // Pass the data to a new object
                    var element = new MolecularElement
                    {
                        Symbol = symbol,
                        Multiplier = (ushort)count,
                        Name = elementInfo!.Name,
                        AtomicMass = elementInfo.AtomicMass,
                        AtomicNumber = elementInfo.AtomicNumber,
                        Period = elementInfo.Period,
                        Group = elementInfo.Group,
                    };

                    // Add the element to the stack
                    elementStack.Peek().Add(element);
                }
                else if (currentChar == '(')
                {
                    // Create a new list in the stack to store the sub formula that will between the brackets
                    elementStack.Push(new List<MolecularElement>());
                    bracketsUsed = true;
                    bracketCount++;
                    i++;
                }
                else if (currentChar == ')')
                {

                    i++;

                    // Get the count (if any) after the closing bracket to know how much to mulitply by
                    int count = 0;
                    while (i < Formula.Length && char.IsDigit(Formula[i]))
                    {
                        count = count * 10 + (Formula[i] - '0');
                        i++;
                    }
                    if (count == 0)
                    {
                        count = 1;
                    }

                    // Retrieve the top element from the stack
                    foreach (var element in elementStack.Pop())
                    {
                        bool addElement = true;

                        // Take the element from the list from the stack and multiply its current count by the count after the ')'
                        element.Multiplier *= (ushort)count;

                        // Only add the elements to the result stack if we are on the last element of the stack
                        if (elementStack.Count == 1)
                        {
                            // Check if the element you want to add already exists (prevents adding dubplicate elements)
                            for (int index = 0; index < result.Count; index++)
                            {
                                if (result[index].Symbol == element.Symbol)
                                {
                                    result[index].Multiplier += element.Multiplier;
                                    addElement = false;
                                }
                            }

                            // Add the element if its not in the list yet
                            if (addElement)
                            {
                                result.Add(element);
                            }
                        }
                        // Add the popped elements from the stack to the lower item in the stack as long as there are still open brackets
                        if (bracketCount > 1)
                        {
                            elementStack.Peek().Add(element);
                        }
                    }
                    bracketCount--;
                }
                // Skip any other character
                else
                {
                    i++;
                }
            }

            //Combine the element stack into a list which will be converted into an array
            foreach (var elementList in elementStack)
            {

                // Check for duplicate elements in the scenario that brackets were not used in the equation
                foreach (var item in elementList)
                {
                    bool addElement = true;
                    for (int index = 0; index < result.Count; index++)
                    {

                        if (item.Symbol == result[index].Symbol)
                        {
                            result[index].Multiplier += item.Multiplier;
                            addElement = false;
                        }
                    }
                    if (addElement)
                    {
                        result.Add(item);
                    }
                }

                // Add the elements normally if brackets were used
                if (bracketsUsed)
                {
                    result.AddRange(elementList);
                }
            }

            // Sort the list alphabetically
            return result.OrderBy(e => e.Symbol).ToArray();
        }

        /*
        * Method Name: validateFormula
        * Purpose: This method will call the validateSubMolecules method and also ansure the the valid formatted formula 
        * does contain elements real elements
        * Accepts: Nothing
        * Returns: A bool
        */
        public bool validateFormula()
        {

            Valid = false;

            // Check if the formula is empty or has whitespace
            if (string.IsNullOrWhiteSpace(Formula))
                return false;


            // Check if the formula has teh correct starting characters of either a Letter or a (
            if (!char.IsLetter(Formula[0]) && Formula[0] != '(')
                return false;

            // Call the recursive function that validates the format of sub formulas within brackets
            if (validateSubMolecules(Formula, 0, Formula.Length))
            {
                // Get a list of each induvidal element
                List<string> elementSymbols = retrieveElements();

                PeriodicTable elementList = new PeriodicTable();

                List<string> elements = new List<string>();

                foreach (var element in PeriodicTable.Elements!)
                {
                    elements.Add(element.Symbol);
                }

                // Check if all element symbols are real elements
                Valid = elementSymbols.All(symbol => elements.Contains(symbol));
            }

            return Valid;
        }

        /*
        * Method Name: validateSubMolecules
        * Purpose: This method will recursively call itself to validate sub molecules that are in brackets
        * Accepts: the string formula, the start and end index of where in the formula to begin parsing
        * Returns: A bool
        */
        private bool validateSubMolecules(string formula, int startIndex, int endIndex)
        {
            Regex elementSymbolRegex = new Regex(@"[A-Z][a-z]*");
            Regex subscriptRegex = new Regex(@"\d+");

            int i = startIndex;
            while (i < endIndex)
            {
                char currentChar = formula[i];

                // Ensure the element symbols are in correct format
                if (char.IsLetter(currentChar))
                {
                    // Match element symbols
                    Match match = elementSymbolRegex.Match(formula, i, endIndex - i);
                    if (!match.Success || match.Index != i)
                        return false;
                    i += match.Length;
                }
                // Ensure the subscripts are in correct format
                else if (char.IsDigit(currentChar))
                {
                    // Match numeric subscripts
                    Match match = subscriptRegex.Match(formula, i, endIndex - i);
                    if (!match.Success || match.Index != i)
                        return false;
                    i += match.Length;
                }
                // Check for begginning of sub formulas
                else if (currentChar == '(')
                {
                    // Match opening parentheses and find corresponding closing parenthesis
                    int openParenCount = 1;
                    int j = i + 1;
                    // Check that an pening bracket has a corresponding closing bracket
                    while (j < endIndex && openParenCount > 0)
                    {
                        if (formula[j] == '(')
                            openParenCount++;
                        else if (formula[j] == ')')
                            openParenCount--;
                        j++;
                    }
                    // bracket counts don't match
                    if (openParenCount != 0)
                        return false;
                    // Call the function again to validate the new sub formula
                    if (!validateSubMolecules(formula, i + 1, j - 1))
                        return false;
                    i = j;
                }
                // Check if additional closing brackets were used
                else if (currentChar == ')')
                {
                    // Unexpected closing parenthesis
                    return false;
                }
                // Return false if encountered with an invalid character
                else
                {
                    return false;
                }
            }
            return true;
        }

        /*
        * Method Name: retrieveElements
        * Purpose: This method will return a list of Strings that contain each induvidal element from the formula
        * Accepts: Nothing
        * Returns: A list of strings
        */
        private List<string> retrieveElements()
        {
            List<string> elementSymbols = new List<string>();

            int i = 0;

            while (i < Formula.Length)
            {
                // Check if the current character is an uppercase letter which would be the start of an element
                if (char.IsUpper(Formula[i]))
                {
                    // Get the element   
                    string symbol = Formula[i].ToString();

                    // Check if next characters are a new element or a part of the current element
                    i++;
                    while (i < Formula.Length && char.IsLower(Formula[i]))
                    {
                        symbol += Formula[i];
                        i++;
                    }

                    elementSymbols.Add(symbol);
                }
                else
                {
                    i++; // Skip non-element characters
                }
            }
            return elementSymbols;
        }

    }
}
