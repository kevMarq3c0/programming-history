﻿/*
 * Program: Program.cs
 * Date: 2024-02-03
 * Author: Tuvia Nacshonov, Hameedullah Sakhizada, and Kevin Marquez 
 * Purpose: This is the client which will read in command line arguments from the console and interact with the StoichiometryLibrary interface which will access the Periodic Table JSON 
 *          and perform the logic to validate elements in the formulas passed to it and calculate their total mass.
 */

using StoichiometryLibrary;

namespace Stoichiometry
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\nStoichiometry 1.0.0.0 © 2024 - Kevin, Hameed, Tuvia\n");
            
            //Check if there are no arguments
            if (args.Length == 0)
            {
                Console.WriteLine("No arguments provided. Use /? for help.");
                return;
            }

            //Retrieve the first argument and split it by : to check if the user has passed a /f: argument
            string[] userInput = args[0].Split(":");

            //Check the command-line argument and see which option has been chosen
            switch (userInput[0])
            {
                //This will print out the Application version, author information and usage instructions
                case "/?":
                    Console.WriteLine("\n{0,-2}Stoichiometry [/?] [formulas] [/t] [/f:filepath]\r\n" +
                                        "\n{0,-2}formulas{0,-8}" + "Specifies one or more white-space delimited molecular formulae for which to" +
                                        "\n{0,-17} compute the molecular mass.\n" +
                                        "{0,-2}/?{0,-14}Displays usage information.\n" +
                                        "{0,-2}/t{0,-14}Lists the elements in the periodic table.\n" +
                                        "{0,-2}/f:filepath{0,-5}Computes the molecular mass for each formula in the file 'filepath'.\n" +
                                        "{0,-2}filepath{0,-7} Specifies a text file containing molecular formulas, one per line.", ""
                                        );
                    break;
                case "/t":
                    //List all the elements in the periodic table with column labels
                    DisplayElements();
                    break;
                case "/f":
                    //Analyze the formulas in a provided filepath and report the molecular mass and show the mass calculations for each valid chemical formula
                    AnalyzeFormulasInFile(userInput[1]);
                    break;
                default:
                    //Check if the user passed a file without the /f: prefix
                    if(Path.GetExtension(args[0]) != "")
                    {
                        //Analyze the formulas in a provided filepath and report the molecular mass and show the mass calculations for each valid chemical formula
                        AnalyzeFormulasInFile(userInput[0]);
                    }
                    else
                    {
                        //If no file extension was found, treat the command-line arguments as formulas to validate and analyze
                        CalculateAtomicMass(userInput);
                    }
                    break;
            }
        }

        /*
        * Method Name: DisplayElements
        * Purpose: This is a static method that will print out all the elements with column labels and various fields for every element
        * Accepts: Nothing
        * Returns: Nothing
        */
        static void DisplayElements()
        {
            //Declare an instance of the PeriodicTable class to initialize the array of Elements
            PeriodicTable table = new PeriodicTable();

            //Print out the column headers
            Console.WriteLine($"{"Atomic #",10} {"Symbol",8} {"Name",6} {"Mass",25} {"Period",8} {"Group",7}");
            Console.WriteLine($"{"--------",10} {"------",8} {"----",6} {"----",25} {"------",8} {"-----",7}");

            //Using a foreach loop, retrieve every element from the array and print out its fields
            foreach (var element in PeriodicTable.Elements!)
            {
                Console.WriteLine($"{"  "}{element.AtomicNumber,-10} {element.Symbol,-8} {element.Name,-14} {element.AtomicMass,15} {element.Period, 8} {element.Group, 7}");
            }
        }

        /*
        * Method Name: AnalyzeFormulasInFile
        * Purpose: This is a static method that will read the contents of a file and report the molecular mass and calculations of every valid formula found in the file
        * Accepts: A string representing the filepath 
        * Returns: Nothing
        */
        static void AnalyzeFormulasInFile(string filePath)
        {
            try
            {
                //Read each line of the file and store it into an array of strings
                string[] formulas = File.ReadAllLines(filePath);
                
                //Iterate through each formula found using a foreach
                foreach(string formula in formulas)
                {
                    //Declare a Molecule object initialized with the formula and calculate its mass
                    Molecule testFormula = new Molecule(formula);
                    double result = testFormula.CalcMass();
                    //Check if the formula is valid or not
                    if(result != 0)
                    {
                        Console.WriteLine($"{formula} has a mass of {result}\n");
                        //Retrieve an array of each element that is in the formula
                        IMolecularElement[] elements = testFormula.GetComposition();
                        //Report the molecular mass and mass calculations for each element in the valid formula
                        foreach(IMolecularElement element in elements)
                        {
                            Console.WriteLine("\t{0, -2} {1,-15}\t\t\t{2: -13} = {3,-10}", element.Symbol, "(" + element.Name + ")", element.AtomicMass.ToString("#.######") + " x " + element.Multiplier, (element.AtomicMass * element.Multiplier));
                        }
                        Console.WriteLine();
                    }
                    else
                    {
                        Console.WriteLine($"{formula} is NOT valid\n");
                    }
                }
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        /*
        * Method Name: CalculateAtomicMass
        * Purpose: This is a static method that will validate each chemical formula on the command line and show the mass calculation for each valid chemical formula.
        * Accepts: An array of strings
        * Returns: Nothing
        */
        static void CalculateAtomicMass(string[] formulaList)
        {
            //Declare a List of Molecule types
            List<Molecule> formulas = new List<Molecule>();

            //Add each formula on the command line to the List of Molecule objects
            foreach (var item in formulaList)
            {
                formulas.Add(new Molecule(item));
            }

            //Iterate through the List of Molecule and validate each formula
            foreach (var item in formulas)
            {
                if (item.CalcMass() != 0)
                {
                    Console.WriteLine($"{item.Formula} is a valid formula\n");

                    IMolecularElement[] elements = item.GetComposition();
                    foreach (IMolecularElement element in elements)
                    {
                        Console.WriteLine("\t{0, -2} {1,-15}\t\t\t{2: -13} = {3,-10}", element.Symbol, "(" + element.Name + ")", element.AtomicMass.ToString("#.######") + " x " + element.Multiplier, (element.AtomicMass * element.Multiplier));
                    }
                    Console.WriteLine();
                }
                else
                {
                    Console.WriteLine($"{item.Formula} is not a valid formula\n");
                }
            }
        }
    }
}
