import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;

import javax.swing.JPanel;

public class GamePanel extends JPanel implements ActionListener{

	// Determines size and speed of game
	static final int SCREEN_WIDTH = 600;
	static final int SCREEN_HEIGHT = 600;
	static final int UNIT_SIZE = 25;
	static final int GAME_UNITS = (SCREEN_WIDTH * SCREEN_HEIGHT)/UNIT_SIZE;
	static final int DELAY = 75;
	
	// Determines coordinates of x and y of the snake as well as its size
	final int xCoordinates[] = new int[GAME_UNITS];
	final int yCoordinates[] = new int[GAME_UNITS];
	int bodyParts = 6;
	
	// Variables to track apple coordinates and how many apples were eaten
	int numApplesEaten, appleXCoordinates, appleYCoordinates;
	
	// Char that determines which direction the snake shall go, starts at R for right
	char directionChoice = 'R';
	
	// Boolean to check if the game is still running 
	boolean running = false;
	Timer timer;
	Random random;
	
	// Constructor for Game Panel
	GamePanel() 
	{
		random = new Random();
		this.setPreferredSize(new Dimension(SCREEN_WIDTH, SCREEN_HEIGHT));
		this.setBackground(Color.DARK_GRAY);
		this.setFocusable(true);
		this.addKeyListener(new MyKeyAdapter());
		
		startGame();
	}
	
	// Starts game
	public void startGame() 
	{
		newApple();
		running = true;
		// Determines how fast the game is running
		timer = new Timer(DELAY, this);
		timer.start();
	}
	
	// Paints game components
	public void paintComponent(Graphics g) 
	{
		super.paintComponent(g);
		draw(g);
	}
	
	// Draw in grid components
	public void draw(Graphics g)
	{
		if(running) {
			for(int i = 0; i < SCREEN_HEIGHT/UNIT_SIZE; i++)
			{
				g.drawLine(i * UNIT_SIZE, 0, i * UNIT_SIZE, SCREEN_HEIGHT);
				g.drawLine(0, i * UNIT_SIZE, SCREEN_WIDTH, i * UNIT_SIZE);
			}
			g.setColor(Color.RED);
			g.fillOval(appleXCoordinates, appleYCoordinates, UNIT_SIZE, UNIT_SIZE);
			
			// Draw the snake
			for (int i = 0; i < bodyParts; i++)
			{
				// For the head of the snake
				if(i == 0) {
					g.setColor(Color.GREEN);
					g.fillRect(xCoordinates[i], yCoordinates[i], UNIT_SIZE, UNIT_SIZE);
				}
				else
				{
					g.setColor(new Color(45, 180, 0));
					g.fillRect(xCoordinates[i], yCoordinates[i], UNIT_SIZE, UNIT_SIZE);
				}
			}
			
			// Draw the score
			g.setColor(Color.yellow);
			g.setFont(new Font("Ink Free", Font.BOLD, 40));
			FontMetrics metrics = getFontMetrics(g.getFont());
			g.drawString("Score: " + numApplesEaten, (SCREEN_WIDTH - metrics.stringWidth("Score: " + numApplesEaten))/2, g.getFont().getSize());
		}
		else
		{
			gameOver(g);
		}
	}
	
	// Method to create an apple and its coordinates
	public void newApple()
	{
		appleXCoordinates = random.nextInt((int)(SCREEN_WIDTH/UNIT_SIZE)) * UNIT_SIZE;
		appleYCoordinates = random.nextInt((int)(SCREEN_HEIGHT/UNIT_SIZE)) * UNIT_SIZE;
	}
	
	// Move direction action for snake
	public void move() 
	{
		// Change the position for each coordinate of the snake 
		for(int i = bodyParts; i > 0; i--)
		{
			xCoordinates[i] = xCoordinates[i-1];
			yCoordinates[i] = yCoordinates[i-1];
		}
		
		switch(directionChoice)
		{
			// U for Up
			case 'U':
				yCoordinates[0] = yCoordinates[0] - UNIT_SIZE;
				break;
			// D for Down
			case 'D':
				yCoordinates[0] = yCoordinates[0] + UNIT_SIZE;
				break;
			// R for Right
			case 'R':
				xCoordinates[0] = xCoordinates[0] + UNIT_SIZE;
				break;
			// L for Left
			case 'L':
				xCoordinates[0] = xCoordinates[0] - UNIT_SIZE;
				break;
		}
	}
	
	// Checks if apple was eaten
	public void ateApple() 
	{
		if((xCoordinates[0] == appleXCoordinates) && (yCoordinates[0] == appleYCoordinates))
		{
			bodyParts++;
			numApplesEaten++;
			newApple();
		}
	}
	
	// Checks if snake hit a collision 
	public void checkCollisions() 
	{
		// Checks if head collided with the body
		for(int i = bodyParts; i > 0; i--)
		{
			// Check if head collided with the body
			if((xCoordinates[0] == xCoordinates[i]) && (yCoordinates[0] == yCoordinates[i]))
			{
				// triggers game over method
				running = false;
			}
		}
		
		// Checks if head touches left border 
		if(xCoordinates[0] < 0)
		{
			running = false;
		}
		
		// Checks if head touches right border
		if(xCoordinates[0] > SCREEN_WIDTH)
		{
			running = false;
		}
		
		// Checks if head touches top border
		if(yCoordinates[0] < 0)
		{
			running = false;
		}
		
		// Checks if head touches bottom border 
		if(yCoordinates[0] > SCREEN_HEIGHT)
		{
			running = false;
		}
		
		if(!running)
		{
			timer.stop();
		}
	}
	
	// Game over method
	public void gameOver(Graphics g)
	{
		//Game Over text 
		g.setColor(Color.red);
		g.setFont(new Font("Ink Free", Font.BOLD, 75));
		FontMetrics metrics1 = getFontMetrics(g.getFont());
		g.drawString("Game Over", (SCREEN_WIDTH - metrics1.stringWidth("Game Over"))/2, SCREEN_HEIGHT/2);
		
		// Final Score
		g.setColor(Color.yellow);
		g.setFont(new Font("Ink Free", Font.BOLD, 40));
		FontMetrics metrics2 = getFontMetrics(g.getFont());
		g.drawString("Score: " + numApplesEaten, (SCREEN_WIDTH - metrics2.stringWidth("Score: " + numApplesEaten))/2, g.getFont().getSize());
		
		// Button to restart 
		g.setColor(Color.yellow);
		g.setFont(new Font("Ink Free", Font.BOLD, 40));
		FontMetrics metrics3 = getFontMetrics(g.getFont());
		g.drawString("Press enter to restart", (SCREEN_WIDTH - metrics3.stringWidth("Press enter to restart"))/2, SCREEN_HEIGHT/3);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// Check if game is running
		if(running)
		{
			// Move the snake;
			move();
			// Check if we ate the apple
			ateApple();
			// Check if we hit a collision
			checkCollisions();
		}
		repaint();
	}
	
	public class MyKeyAdapter extends KeyAdapter
	{
		@Override 
		public void keyPressed(KeyEvent e) {
			//Examines the key code 
			switch(e.getKeyCode())
			{
				case KeyEvent.VK_LEFT:
					//Prevents user from imploding themselves
					if(directionChoice != 'R') 
					{
						directionChoice = 'L';
					}
					break;
				case KeyEvent.VK_RIGHT:
					if(directionChoice != 'L')
					{
						directionChoice = 'R';
					}
					break;
				case KeyEvent.VK_UP:
					if(directionChoice != 'D')
					{
						directionChoice = 'U';
					}
					break;
				case KeyEvent.VK_DOWN:
					if(directionChoice != 'U')
					{
						directionChoice = 'D';
					}
					break;
				case KeyEvent.VK_ENTER:
					numApplesEaten = 0;
					bodyParts = 6;
					xCoordinates[0] = 0;
					yCoordinates[0] = 0;
					directionChoice = 'R';
					startGame();
					repaint();
					break;
			}
		}
	}
}
