/**
	 * Class Name: K_M_LoanPayable	
	 * Purpose:	Creates an interface that will hold a constant value called ANNUAL_RATE_TO_MONTHLY_RATE to convert whatever annual prime interest rate the user inputs tp
	 * 			the monthly rate decimal equivalent. It will also hold an abstract method called calculateLoanPayment for calculating Loan Payment 
	 * Coder: Kevin Marquez
	 * Date: April 8 2022
*/
public interface K_M_LoanPayable {
	public static final double ANNUAL_RATE_TO_MONTHLY_RATE = 1.0/1200.0;
	
	/**
	 * Calculates the Loan Payment 
	 * @param principalAmount
	 * @param annualPrimeInterest
	 * @param amoritzationPeriodMonths
	 * @return a double representing the monthly payment 
	 */
	public abstract double calculateLoanPayment(double principalAmount, double annualPrimeInterest, int amoritzationPeriodMonths);
}
