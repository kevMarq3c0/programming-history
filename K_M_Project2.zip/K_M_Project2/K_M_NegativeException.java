/**
	 * Class Name: K_M_NegativeException
	 * Purpose:	Creates a class called K_M_NegativeException to throw as an exception if a value is found negative
	 * Coder: Kevin Marquez
	 * Date: April 8 2022
*/
public class K_M_NegativeException extends Error
{
	public K_M_NegativeException(double num)
	{
		super("Invalid input - Negative value: " + num);
	}
}
