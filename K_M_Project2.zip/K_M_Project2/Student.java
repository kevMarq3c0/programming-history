/**
	 * Class Name: Student.java	
	 * Purpose:	Creates a class called student with a constructor and various methods to access a Student object and its attributes
	 * Coder: Kevin Marquez
	 * Date: April 8 2022
*/
public class Student {
	private String studentID, surname, middleName, firstName, aptNumber, streetNumber, streetName, city, province, postalCode;
	private double cslLoanAmount, oslLoanAmount;
	
	/**
	 * Creates a student object
	 * @param studentID
	 * @param surname
	 * @param middleName
	 * @param firstName
	 * @param aptNumber
	 * @param streetNumber
	 * @param streetName
	 * @param city
	 * @param province
	 * @param postalCode
	 * @param cslLoanAmount
	 * @param oslLoanAmount
	 */
	public Student(String studentID, String surname, String middleName, String firstName, String aptNumber, String streetNumber, 
			String streetName, String city, String province, String postalCode, double cslLoanAmount, double oslLoanAmount)
	{
		this.studentID = studentID;
		this.surname = surname;
		this.middleName = middleName;
		this.firstName = firstName;
		this.aptNumber = aptNumber;
		this.streetNumber = streetNumber;
		this.streetName = streetName;
		this.city = city;
		this.province = province;
		this.postalCode = postalCode;
		this.cslLoanAmount = cslLoanAmount;
		this.oslLoanAmount = oslLoanAmount;
	}

	/**
	 * Gets the Student ID of a Student object
	 * @return A string
	 */
	public String getStudentID() {
		return studentID;
	}

	/**
	 * Gets the surname of a Student object
	 * @return A string
	 */
	public String getSurname() {
		return surname;
	}

	/**
	 * Sets the surname of a Student object
	 * @param surname
	 */
	public void setSurname(String surname) {
		this.surname = surname;
	}

	/**
	 * Gets the middle name of a Student object
	 * @return a string
	 */
	public String getMiddleName() {
		return middleName;
	}

	/**
	 * Sets the middle name of a Student object
	 * @param middleName
	 */
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	/**
	 * Gets the first name of a Student object
	 * @return a string
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Sets the first name of a Student object
	 * @param firstName
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Gets the apartment number of a Student object
	 * @return a string
	 */
	public String getAptNumber() {
		return aptNumber;
	}

	/**
	 * Sets the apartment number of a Student object
	 * @param aptNumber
	 */
	public void setAptNumber(String aptNumber) {
		this.aptNumber = aptNumber;
	}

	/**
	 * Gets the street number of a Student object
	 * @return a string
	 */
	public String getStreetNumber() {
		return streetNumber;
	}

	/**
	 * Sets the street number of a Student object
	 * @param streetNumber
	 */
	public void setStreetNumber(String streetNumber) {
		this.streetNumber = streetNumber;
	}

	/**
	 * Gets the street name of a Student object
	 * @return a string
	 */
	public String getStreetName() {
		return streetName;
	}

	/**
	 * Sets the street name of a Student object
	 * @param streetName
	 */
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	/**
	 * Gets the city of a Student object
	 * @return a string
	 */
	public String getCity() {
		return city;
	}

	/**
	 * Sets the city of a Student object
	 * @param city
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * Gets the province of a Student object
	 * @return a string
	 */
	public String getProvince() {
		return province;
	}

	/**
	 * Sets the province of a Student object
	 * @param province
	 */
	public void setProvince(String province) {
		this.province = province;
	}

	/**
	 * Gets the postal code of a Student object
	 * @return a string
	 */
	public String getPostalCode() {
		return postalCode;
	}

	/**
	 * Sets the postal code of a Student object
	 * @param postalCode
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * Gets the CSL Loan Amount of a Student object
	 * @return a double
	 */
	public double getCslLoanAmount() {
		return cslLoanAmount;
	}

	/**
	 * Sets the CSL Loan Amount of a Student object
	 * @param cslLoanAmount
	 */
	public void setCslLoanAmount(double cslLoanAmount) {
		this.cslLoanAmount = cslLoanAmount;
	}

	/**
	 * Gets the OSL Loan Amount of a Student object
	 * @return a double
	 */
	public double getOslLoanAmount() {
		return oslLoanAmount;
	}

	/**
	 * Sets the OSL Loan Amount of a Student object
	 * @param oslLoanAmount
	 */
	public void setOslLoanAmount(double oslLoanAmount) {
		this.oslLoanAmount = oslLoanAmount;
	}
	
	/**
	 * Method Name: toString()
	 *Purpose: Represents the current state of a Student object
	 *@param NO arguments
	 *@return A string
	 */
	@Override
	public String toString()
	{
		String result = "Student Name: " + surname + ", " + firstName + " " + middleName +
				"\nStudent Number: " + studentID + "\nCSL Amount is $" + cslLoanAmount + "\nOSL Amount is $" + oslLoanAmount;
		return result;
	}
	
}
