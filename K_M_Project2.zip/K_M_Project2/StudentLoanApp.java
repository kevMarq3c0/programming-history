/**
	 * Class Name:	StudentLoanApp
	 * Purpose:		GUI for an app that prompts a user to enter student data and the amounts of their loans then output their data as well as 
	 * 				the total monthly payments they need to make 
	 * Coder:		Kevin Marquez	
	 * Date:		April 8, 2022	
*/
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import java.text.DecimalFormat;

public class StudentLoanApp extends JFrame{
	
	ArrayList<Student> students = new ArrayList<Student>();
	ArrayList<String> amortizationPeriods = new ArrayList<String>();
	ArrayList<String> percentageChoice = new ArrayList<String>();
	DecimalFormat format = new DecimalFormat("#,###.00");
	private JComboBox<String> cboOptions;
	private JButton submitBtn, clearBtn, calculateBtn, nextBtn, previousBtn;
	private JTextField studentID, surname, middleName, firstName, aptNumber, streetNum, streetName, city, province, postalCode, cslLoanAmount, oslLoanAmount, amortizationMonths;
	private JTextField idOutput, surnameOutput, middleOutput, firstOutput, aptOutput, strNumOutput, strNameOutput, cityOutput, provinceOutput, postalOutput, cslOutput, oslOutput,
			totalCSL, totalOSL, totalMonthPayment;
	private JPanel topPanel, leftPanel, rightPanel, bottomPanel;
	private int numCount = 0;
	private int index = -1;
	public StudentLoanApp()
	{
		super("Kevin Marquez - Student #1054838");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(800, 600);
		this.setLocationRelativeTo(null);
		this.setLayout(new BorderLayout());
		
		topPanel = new JPanel();
		
		JLabel myLabel = new JLabel("This is Kevin's Student Loan Calculator!");
		topPanel.add(myLabel);
		
		this.add(topPanel, BorderLayout.NORTH);
		
		buildLeftPanel();
		this.add(leftPanel, BorderLayout.WEST);
		
		buildRightPanel();
		this.add(rightPanel, BorderLayout.EAST);
		
		bottomPanel = new JPanel();
		bottomPanel.setLayout(new FlowLayout());
		
		JLabel totalCSLMonth = new JLabel("CSL Monthly Payment:");
		totalCSL = new JTextField(10);
		JLabel totalOSLMonth = new JLabel("OSL Monthly Payment:");
		totalOSL = new JTextField(10);
		JLabel totalMonthPay = new JLabel("Total Monthly Payment:");
		totalMonthPayment = new JTextField(10);
		
		bottomPanel.add(totalCSLMonth);
		bottomPanel.add(totalCSL);
		bottomPanel.add(totalOSLMonth);
		bottomPanel.add(totalOSL);
		bottomPanel.add(totalMonthPay);
		bottomPanel.add(totalMonthPayment);
		
		this.add(bottomPanel, BorderLayout.SOUTH);
		
		this.setVisible(true);
	}
	
	/**
	 * Method Name: buildLeftPanel
	 * Purpose: Constructs the left panel of a JFrame
	 * @param NO arguments
	 * @return Nothing
	 */
	public void buildLeftPanel()
	{
		leftPanel = new JPanel();
		leftPanel.setLayout(new BorderLayout());
		
		JPanel inputTitlePanel = new JPanel();
		JLabel inputTitle = new JLabel("Input Form");
		inputTitlePanel.add(inputTitle);
		leftPanel.add(inputTitlePanel, BorderLayout.NORTH);
		
		JPanel promptPanel = new JPanel();
		promptPanel.setLayout(new GridLayout(14,2));
		
		studentID = new JTextField();
		studentID.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent ke)
			{
				char userInput = ke.getKeyChar();
				if (userInput < '0' || userInput > '9'|| numCount > 6)
				{
					ke.consume();
				}
				else
				{
					numCount++;
				}
			}
		}
		);
		
		surname = new JTextField();
		middleName = new JTextField();
		firstName = new JTextField();
		aptNumber = new JTextField();
		streetNum = new JTextField();
		streetName = new JTextField();
		city = new JTextField();
		province = new JTextField();
		postalCode = new JTextField();
		
		cslLoanAmount = new JTextField();
		cslLoanAmount.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent ke)
			{
				char userInput = ke.getKeyChar();
				if (userInput < '0' || userInput > '9')
				{
					if(userInput != '.' && userInput != '-')
					{
						ke.consume();
					}
				}
			}
		}
		);
		
		oslLoanAmount = new JTextField();
		oslLoanAmount.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent ke)
			{
				char userInput = ke.getKeyChar();
				if (userInput < '0' || userInput > '9')
				{
					if(userInput != '.' && userInput != '-')
					{
						ke.consume();
					}
				}
			}
		}
		);
		
		amortizationMonths = new JTextField();
		amortizationMonths.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent ke)
			{
				char userInput = ke.getKeyChar();
				if (userInput < '0' || userInput > '9')
				{
					if(userInput != '.' || userInput != '-')
					{
						ke.consume();
					}
				}
			}
		}
		);
		
		String [] options= {"4.00%", "4.25%", "4.50%", "4.75%", "5.00%"};
		cboOptions = new JComboBox<String>(options);
		
		JLabel idPrompt = new JLabel("Student ID: ");
		JLabel surnamePrompt = new JLabel("Surname: ");
		JLabel middleNamePrompt = new JLabel("Middle Name: ");
		JLabel firstNamePrompt = new JLabel("First Name: ");
		JLabel aptNumPrompt = new JLabel("Apartment #: ");
		JLabel streetNumPrompt = new JLabel("Street #: ");
		JLabel streetNamePrompt = new JLabel("Street Name: ");
		JLabel cityPrompt = new JLabel("City: ");
		JLabel provincePrompt = new JLabel("Province: ");
		JLabel postalPrompt = new JLabel("Postal Code: ");
		JLabel cslLoanPrompt = new JLabel("CSL Loan Prompt: ");
		JLabel oslLoanPrompt = new JLabel("OSL Loan Prompt: ");
		JLabel annualPrimeInterest = new JLabel("Annual Prime Interest: ");
		JLabel amortization = new JLabel("Amortization (Months): ");
		
		promptPanel.add(idPrompt);
		promptPanel.add(studentID);
		promptPanel.add(surnamePrompt);
		promptPanel.add(surname);
		
		promptPanel.add(middleNamePrompt);
		promptPanel.add(middleName);
		promptPanel.add(firstNamePrompt);
		promptPanel.add(firstName);
		
		promptPanel.add(aptNumPrompt);
		promptPanel.add(aptNumber);
		promptPanel.add(streetNumPrompt);
		promptPanel.add(streetNum);
		
		promptPanel.add(streetNamePrompt);
		promptPanel.add(streetName);
		promptPanel.add(cityPrompt);
		promptPanel.add(city);
		
		promptPanel.add(provincePrompt);
		promptPanel.add(province);
		promptPanel.add(postalPrompt);
		promptPanel.add(postalCode);
		
		promptPanel.add(cslLoanPrompt);
		promptPanel.add(cslLoanAmount);
		promptPanel.add(oslLoanPrompt);
		promptPanel.add(oslLoanAmount);
		
		promptPanel.add(annualPrimeInterest);
		promptPanel.add(cboOptions);
		promptPanel.add(amortization);
		promptPanel.add(amortizationMonths);
		
		leftPanel.add(promptPanel, BorderLayout.CENTER);
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout());
		
		submitBtn = new JButton("Submit");
		clearBtn = new JButton("Clear");
		
		submitBtn.addActionListener(new SubmitButtonListener());
		clearBtn.addActionListener(new ClearButtonListener());
		
		buttonPanel.add(submitBtn);
		buttonPanel.add(clearBtn);
		
		leftPanel.add(buttonPanel, BorderLayout.SOUTH);
	}
	
	/**
	 * Method Name: buildRightPanel
	 * Purpose: Constructs the right panel of a JFrame
	 * @param NO arguments
	 * @return Nothing
	 */
	public void buildRightPanel()
	{
		rightPanel = new JPanel();
		rightPanel.setLayout(new BorderLayout());
		
		JPanel repaymentTitlePanel = new JPanel();
		JLabel repaymentTitle = new JLabel("Repayment Calculation Form");
		repaymentTitlePanel.add(repaymentTitle);
		rightPanel.add(repaymentTitlePanel, BorderLayout.NORTH);
		
		JPanel displayPanel = new JPanel();
		displayPanel.setLayout(new GridLayout(12,2));
		
		idOutput = new JTextField();
		idOutput.setEditable(false);
		
		surnameOutput = new JTextField();
		surnameOutput.setEditable(false);
		
		middleOutput = new JTextField();
		middleOutput.setEditable(false);
		
		firstOutput = new JTextField();
		firstOutput.setEditable(false);
		
		aptOutput = new JTextField();
		aptOutput.setEditable(false);
		
		strNumOutput = new JTextField();
		strNumOutput.setEditable(false);
		
		strNameOutput = new JTextField();
		strNameOutput.setEditable(false);
		
		cityOutput = new JTextField();
		cityOutput.setEditable(false);
		
		provinceOutput = new JTextField();
		provinceOutput.setEditable(false);
		
		postalOutput = new JTextField();
		postalOutput.setEditable(false);
		
		cslOutput = new JTextField();
		cslOutput.setEditable(false);
		
		oslOutput = new JTextField();
		oslOutput.setEditable(false);
		
		JLabel idDisplay = new JLabel("Student ID: ");
		JLabel surnameDisplay = new JLabel("Surname: ");
		JLabel middleNameDisplay = new JLabel("Middle Name: ");
		JLabel firstNameDisplay = new JLabel("First Name: ");
		JLabel aptNumDisplay = new JLabel("Apartment #: ");
		JLabel streetNumDisplay = new JLabel("Street #: ");
		JLabel streetNameDisplay = new JLabel("Street Name: ");
		JLabel cityDisplay = new JLabel("City: ");
		JLabel provinceDisplay = new JLabel("Province: ");
		JLabel postalDisplay = new JLabel("Postal Code: ");
		JLabel cslLoanDisplay = new JLabel("CSL Loan Amount: ");
		JLabel oslLoanDisplay = new JLabel("OSL Loan Amount: ");
		
		displayPanel.add(idDisplay);
		displayPanel.add(idOutput);
		displayPanel.add(surnameDisplay);
		displayPanel.add(surnameOutput);
		
		displayPanel.add(middleNameDisplay);
		displayPanel.add(middleOutput);
		displayPanel.add(firstNameDisplay);
		displayPanel.add(firstOutput);
		
		displayPanel.add(aptNumDisplay);
		displayPanel.add(aptOutput);
		displayPanel.add(streetNumDisplay);
		displayPanel.add(strNumOutput);
		
		displayPanel.add(streetNameDisplay);
		displayPanel.add(strNameOutput);
		displayPanel.add(cityDisplay);
		displayPanel.add(cityOutput);
		
		displayPanel.add(provinceDisplay);
		displayPanel.add(provinceOutput);
		displayPanel.add(postalDisplay);
		displayPanel.add(postalOutput);
		
		displayPanel.add(cslLoanDisplay);
		displayPanel.add(cslOutput);
		displayPanel.add(oslLoanDisplay);
		displayPanel.add(oslOutput);
		
		rightPanel.add(displayPanel, BorderLayout.CENTER);
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout());
		
		calculateBtn = new JButton("Calculate");
		calculateBtn.addActionListener(new CalculateButtonListener());
		
		nextBtn = new JButton("Next");
		nextBtn.addActionListener(new ChangeButtonListener());
		
		previousBtn = new JButton("Previous");
		previousBtn.addActionListener(new ChangeButtonListener());
		
		buttonPanel.add(calculateBtn);
		buttonPanel.add(nextBtn);
		buttonPanel.add(previousBtn);
		
		rightPanel.add(buttonPanel, BorderLayout.SOUTH);
	}
	
	/**
	 * Method Name: SubmitButtonListener
	 * Purpose: Creates an Event Handler for the Submit button
	 * @param ActionEvent e
	 * @return Nothing
	 */
	private class SubmitButtonListener implements ActionListener
	{
		String studentVal, surnameVal, middleNameVal, firstNameVal, apartmentNum, streetNumber, streetNameVal, cityVal, provinceVal, postalVal, cslLoanVal, oslLoanVal;
		double cslAmount, oslAmount;
		@Override
		public void actionPerformed(ActionEvent e) {
			try {
				studentVal = studentID.getText();
				surnameVal = surname.getText();
				middleNameVal = middleName.getText();
				firstNameVal = firstName.getText();
				apartmentNum = aptNumber.getText();
				streetNumber = streetNum.getText();
				streetNameVal = streetName.getText();
				cityVal = city.getText();
				provinceVal = province.getText();
				postalVal = postalCode.getText();
				cslLoanVal = cslLoanAmount.getText();
				oslLoanVal = oslLoanAmount.getText();
			
				checkInput(studentVal, surnameVal, middleNameVal, firstNameVal, apartmentNum, streetNumber, streetNameVal, cityVal, provinceVal, postalVal, cslLoanVal, oslLoanVal);
				cslAmount = Double.parseDouble(cslLoanAmount.getText());
				oslAmount = Double.parseDouble(oslLoanAmount.getText());
				
				checkIfNegative(cslAmount, oslAmount);
				Student studentTemplate = new Student(studentVal, surnameVal, middleNameVal, firstNameVal, apartmentNum, streetNumber, streetNameVal, cityVal, provinceVal, postalVal,
						cslAmount, oslAmount);
				students.add(studentTemplate);
				
				String selected = (String) cboOptions.getSelectedItem();
				selected = selected.substring(0, selected.length()-1);
				percentageChoice.add(selected);
				
				if((amortizationMonths.getText()).isEmpty())
				{
					throw new EmptyException();
				}
				else
				{
					String amortizationTemplate = amortizationMonths.getText();
					amortizationPeriods.add(amortizationTemplate);
				}
			} 
			catch (K_M_NegativeException e1)
			{
				JOptionPane.showMessageDialog(null, "Found value that is negative, converting to positive", "Value Negative", JOptionPane.OK_OPTION);
				cslAmount = Math.abs(cslAmount);
				oslAmount = Math.abs(oslAmount);
				
				Student studentTemplate = new Student(studentVal, surnameVal, middleNameVal, firstNameVal, apartmentNum, streetNumber, streetNameVal, cityVal, provinceVal, postalVal,
						cslAmount, oslAmount);
				students.add(studentTemplate);
				
				String selected = (String) cboOptions.getSelectedItem();
				selected = selected.substring(0, selected.length()-1);
				percentageChoice.add(selected);
				
				String amortizationTemplate = amortizationMonths.getText();
				amortizationPeriods.add(amortizationTemplate);
			}
			catch (EmptyException e2) {
				JOptionPane.showMessageDialog(null, "Value empty - please re-enter", "Value Empty", JOptionPane.OK_OPTION);
				e2.printStackTrace();
			}
		}
	}
	
	/**
	 * Method Name: ClearButtonListener
	 * Purpose: Creates an Event Handler for the Clear Button
	 * @param ActionEvent e
	 * @return Nothing
	 */
	private class ClearButtonListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e) {
			studentID.setText(null);
			surname.setText(null);
			middleName.setText(null);
			firstName.setText(null);
			aptNumber.setText(null);
			streetNum.setText(null);
			streetName.setText(null);
			city.setText(null);
			province.setText(null);
			postalCode.setText(null);
			cslLoanAmount.setText(null);
			oslLoanAmount.setText(null);
			amortizationMonths.setText(null);
			numCount = 0;
		}
	}
	
	/**
	 * Method Name: CalculateButtonListener
	 * Purpose: Builds an Event Handler for the Calculate Button
	 * @param ActionEvent e
	 * @return Nothing
	 */
	private class CalculateButtonListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e) 
		{
			if((cslLoanAmount.getText()).isEmpty())
			{
				JOptionPane.showMessageDialog(null, cslLoanAmount.getText(), "Input CSL Loan Amount Error", JOptionPane.OK_OPTION);
			}
			else if ((oslLoanAmount.getText()).isEmpty())
			{
				JOptionPane.showMessageDialog(null, oslLoanAmount.getText(), "Input OSL Loan Amount Error", JOptionPane.OK_OPTION);
			}
			else if((amortizationMonths.getText()).isEmpty()) 
			{
				JOptionPane.showMessageDialog(null, amortizationMonths.getText(), "Input Amortization Error", JOptionPane.OK_OPTION);
			}
			else
			{
				double cslLoanVal = students.get(index).getCslLoanAmount();
				double oslLoanVal = students.get(index).getOslLoanAmount();
				int amortizationVal = Integer.parseInt(amortizationPeriods.get(index));
				
				String selected = (String) cboOptions.getSelectedItem();
				selected = selected.substring(0, selected.length()-1);
				
				double annualPrimeInterest = Double.parseDouble(percentageChoice.get(index));
				double cslAnnualPrimeInterest = annualPrimeInterest + 2.5;
				
				MonthlyPayments test = new MonthlyPayments();
				double cslMonthlyPayment = test.calculateLoanPayment(cslLoanVal, cslAnnualPrimeInterest, amortizationVal);
				totalCSL.setText("$" + format.format(cslMonthlyPayment));
				
				double oslAnnualPrimeInterest = annualPrimeInterest + 1.0;
				double oslMonthlyPayment = test.calculateLoanPayment(oslLoanVal, oslAnnualPrimeInterest, amortizationVal);
				totalOSL.setText("$" + format.format(oslMonthlyPayment));
				
				double totalMonthlyPayment = cslMonthlyPayment + oslMonthlyPayment;
				totalMonthPayment.setText("$" + format.format(totalMonthlyPayment));
			}
		}
	}
	
	/**
	 * Method Name: ChangeButtonListener
	 * Purpose: Builds an Event Handler for both the Next and Previous Buttons
	 * @param ActionEvent e
	 * @return Nothing
	 */
	private class ChangeButtonListener implements ActionListener 
	{
		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getActionCommand().equals("Next"))
			{
				index++;
			}
			else if(e.getActionCommand().equals("Previous"))
			{
				index--;
			}
			
			if (index > (students.size() - 1))
			{
				JOptionPane.showMessageDialog(null, studentID.getText(), "No more student entries exist", JOptionPane.OK_OPTION);
			}
			else if(index < 0)
			{
				JOptionPane.showMessageDialog(null, studentID.getText(), "No more previous student entries", JOptionPane.OK_OPTION);
			}
			else
			{
				idOutput.setText(students.get(index).getStudentID());
				surnameOutput.setText(students.get(index).getSurname());
				middleOutput.setText(students.get(index).getMiddleName());
				firstOutput.setText(students.get(index).getFirstName());
				aptOutput.setText(students.get(index).getAptNumber());
				strNumOutput.setText(students.get(index).getStreetNumber());
				strNameOutput.setText(students.get(index).getStreetName());
				cityOutput.setText(students.get(index).getCity());
				provinceOutput.setText(students.get(index).getProvince());
				postalOutput.setText(students.get(index).getPostalCode());
				cslOutput.setText("$" + format.format(students.get(index).getCslLoanAmount()));
				oslOutput.setText("$" + format.format(students.get(index).getOslLoanAmount()));
			}
		}	
	}
	
	/**
	 * Method Name: checkInput
	 * Purpose: Checks if all strings are empty or not
	 * @param 12 strings
	 * @return An exception if found empty
	 */
	public void checkInput(String s, String s2, String s3, String s4, String s5, String s6, String s7, String s8, String s9, String s10, String csl, String osl) throws EmptyException
	{
		if(s.isEmpty() || s2.isEmpty() || s3.isEmpty() || s4.isEmpty() || s5.isEmpty() || s6.isEmpty() || s7.isEmpty() || s8.isEmpty() || s9.isEmpty() || s10.isEmpty() || 
				csl.isEmpty() || osl.isEmpty())
		{
			throw new EmptyException();
		}
	}
	
	/**
	 * Method Name: checkIfNegative
	 * Purpose: Checks if either of numerical values are negative
	 * @param 2 Doubles
	 * @return An exception if found empty
	 */
	public void checkIfNegative(double num1, double num2)
	{
		if(num1 < 0)
		{
			throw new K_M_NegativeException(num1);
		}
		else if(num2 < 0)
		{
			throw new K_M_NegativeException(num2);
		}
	}
	
	/**
	 * Class Name: MonthlyPayments.java	
	 * Purpose:	Creates a class called MonthlyPayments that inherits from the K_M_LoanPayable interface
	 * Coder: Kevin Marquez
	 * Date: April 8 2022
	 */
	public class MonthlyPayments implements K_M_LoanPayable
	{
		/**
		 * Calculates the Loan Payment 
		 * @param principalAmount
		 * @param annualPrimeInterest
		 * @param amoritzationPeriodMonths
		 * @return a double representing the monthly payment 
		 */
		@Override
		public double calculateLoanPayment(double principalAmount, double annualPrimeInterest, int amoritzationPeriodMonths) 
		{
		
			double monthlyRatePercentage = annualPrimeInterest * ANNUAL_RATE_TO_MONTHLY_RATE;
			double monthlyPaymentPart = principalAmount * monthlyRatePercentage * Math.pow(1 + monthlyRatePercentage, amoritzationPeriodMonths);
			double fullMonthlyPayment = monthlyPaymentPart/(Math.pow(1 + monthlyRatePercentage, amoritzationPeriodMonths) - 1);
			
			return fullMonthlyPayment;
		}
	}
	
	public static void main(String[] args)
	{
		new StudentLoanApp();
	}
	
}
