/**
	 * Class Name: EmptyException
	 * Purpose:	Creates a class called EmptyException to throw as an exception if a value is found empty 
	 * Coder: Kevin Marquez
	 * Date: April 8 2022
*/
public class EmptyException extends Exception
{
	/**
	 * Method Name: EmptyException
	 * Purpose: Overloads an error message from the exception class with one that is specific to the exception that it covers
	 * @param NO arguments
	 * @return Nothing
	 */
	public EmptyException()
	{
		super("Empty line inputs detected. Please fill in all the prompts.");
	}
}
