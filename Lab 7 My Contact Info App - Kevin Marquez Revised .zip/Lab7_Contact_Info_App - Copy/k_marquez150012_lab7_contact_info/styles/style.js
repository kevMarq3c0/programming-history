import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
    screen: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
    },
    container: {
        margin: 5,
        alignItems: 'center', // This will center the buttons horizontally
    },
    section: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        alignItems: 'flex-start'
    },
    header: {
        fontSize: 30,
        marginBottom: 30,
        textAlign: 'center'
    },
    label: {
        fontSize: 18,
        marginBottom: 16,
        textAlign: 'center',
    },
    imagePreview: {
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 20,
    },
    image: {
        width: '50%', // Make image responsive by using percentage
        borderRadius: 50,
        backgroundColor: 'gray',
        height: 100,   // Fixed height, you might want to make this responsive as well
        marginBottom: 10
    },
    defaultImage: {
        width: 100, // Make image responsive by using percentage
        borderRadius: 50,
        backgroundColor: 'gray',
        alignItems: 'center',
        height: 100,   // Fixed height, you might want to make this responsive as well
        marginBottom: 10
    },
    imageText: {
        color: 'yellow',
        verticalAlign: 'middle',
        lineHeight: 100,
    },
    directoryOutput: {
        fontSize: 18,
        fontWeight: 'bold',
        textAlign: 'left'
    },
    fileOutput: {
        borderColor: 'red',
        borderWidth: 1,
        margin: 5,
    },
    inputLabel: {
        fontSize: 18,
        marginBottom: 16,
        textAlign: 'left'
    },
    textInput: {
        borderColor: '#ccc',
        width: '100%',
        paddingLeft: 5,
        borderWidth: 1,
        marginBottom: 15,
        marginRight: 15,
    },
    pickerInput: {
        borderColor: '#ccc',
        width: '100%',
        paddingLeft: 5,
        borderWidth: 1,
        marginBottom: 15,
        marginRight: 15,
    },
    button: {
        width: '40%',
        alignContent: 'center'
    },
    inputGroup: {
        flexWrap: 'wrap',
        alignItems: 'flex-start',
        width: '100%',
    }, 
    scrollViewContainer: {
        flexGrow: 1,
        justifyContent: 'center',
    },
    disabledPickerItem: {
        color: 'gray',
    },
    form: {
        width: '80%',
        height: '10%',
        margin: 30,
        marginTop: 10,
        backgroundColor: "#DCE69E",
        justifyContent: 'center',
        alignItems: 'center',
    },
    text: {
        color: '#454913',
        fontSize: 15,
        fontWeight: 'bold',
    },
})