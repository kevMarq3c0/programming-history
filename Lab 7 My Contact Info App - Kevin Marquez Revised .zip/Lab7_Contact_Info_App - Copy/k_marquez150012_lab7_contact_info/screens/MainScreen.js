import React, { useState, useEffect } from 'react';
import {View, Text, Image, ScrollView, Button, TouchableOpacity } from 'react-native';
import ImageSelector from '../components/ImageSelector';
import InputField from '../components/InputFields';
import ProvinceStatePicker from '../components/ProvincePicker';
import CountryPicker from '../components/CountryPicker';
import { styles } from '../styles/style';
import * as FileSystem from 'expo-file-system';
import * as SQLite from 'expo-sqlite';

const db = SQLite.openDatabase('myTestDB');
let dbURI;

const MainScreen = () => {
    const [selectedImageUri, setSelectedImageUri] = useState();

    const [dataForDatabase, setDataForDatabase] = useState({});
    const [dataFromDatabase, setDataFromDatabase] = useState([]);
    const [formValid, setFormValid] = useState(false);
    const [infoSaved, setInfoSaved] = useState(false);
    const [showMessage, setShowMessage] = useState(false);
    const [statusMessage, setStatusMessage] = useState('');

    const [firstName, setFirstName] = useState();
    const [lastName, setLastName] = useState();
    const [email, setEmail] = useState();
    const [phone, setPhone] = useState();
    const [address1, setAddress1] = useState();
    const [address2, setAddress2] = useState();
    const [city, setCity] = useState();
    const [postalCode, setPostalCode] = useState();
    const [provinceState, setProvinceState] = useState();
    const [country, setCountry] = useState();

    useEffect(() => {
        db.transaction(tx => {
            tx.executeSql(
                `CREATE TABLE IF NOT EXISTS ContactsTable (id INTEGER PRIMARY KEY NOT NULL, 
                                                           firstName TEXT, 
                                                           lastName TEXT, 
                                                           email TEXT, 
                                                           phone TEXT,
                                                           address1 TEXT,
                                                           address2 TEXT,
                                                           city TEXT,
                                                           postalCode TEXT,
                                                           provinceState TEXT,
                                                           country TEXT,
                                                           uri TEXT);`,
                [],
                () => console.log('TABLE CREATED!'),
                (_, error) => console.log('TABLE CREATE failed:', error)
            );
        });

        retrieveFromDatabase();
    }, []);

    const imgDir = FileSystem.documentDirectory + 'images/';

    const ensureDirectoryExists = async () => {
        const dirInfo = await FileSystem.getInfoAsync(imgDir);
        if(!dirInfo.exists) {
            await FileSystem.makeDirectoryAsync(imgDir, {intermediates: true});
            console.log('Directory created');
        } else {
            console.log('Directory exists');
        }
    };

    const loadImage = async (uri) => {
        await ensureDirectoryExists();
        try {
            FileSystem.getInfoAsync(imgDir).then(async () => {
                const image = await FileSystem.readDirectoryAsync(imgDir);
                image.map(fileName => {
                    if(uri === fileName)
                    {
                        setSelectedImageUri(imgDir + fileName);
                        console.log(imgDir + fileName);
                        dbURI = fileName;
                    }
                });
            });
        } catch (error)
        {
            console.log('Error: ' + error);
        }
    };

    const saveImage = async () => {
        await ensureDirectoryExists();
        const filename = dbURI.split('/').pop();
        const destination = imgDir + filename;
        
        if(filename !== dataFromDatabase.uri && dataFromDatabase.uri !== undefined)
        {
            const olddestination = imgDir + dataFromDatabase.uri;
            FileSystem.getInfoAsync(olddestination).then(async () => {
                await FileSystem.deleteAsync(olddestination, {});
                console.log('File was deleted');
            })            
        }

        const dirInfo = await FileSystem.getInfoAsync(destination);
        if(!dirInfo.exists)
        {
            await FileSystem.moveAsync({from: selectedImageUri, to: destination}).then(() => {
                console.log('File saved at ' + destination);
            });
        }
    };

    const onChangeHandler = (value, field) => {
        setDataForDatabase(prevState => ({ ...prevState, [field]: value}));
        validateForm();
    };

    const validateForm = () => {
        if(dataForDatabase.firstName === null || dataForDatabase.firstName === ''||
           dataForDatabase.lastName === null || dataForDatabase.lastName === '' ||
           dataForDatabase.email === null || dataForDatabase.email === '' ||
           dataForDatabase.phone === null || dataForDatabase.phone === '' || 
           dataForDatabase.address1 === null || dataForDatabase.address1 === ''||
           dataForDatabase.city === null || dataForDatabase.city === '' ||
           dataForDatabase.postalCode === null ||  dataForDatabase.postalCode === '' ||
           dataForDatabase.province === "0" || dataForDatabase.country === "0")
        {
            setFormValid(false);
        }
        else
        {
            setFormValid(true);
        }
    };

    const saveToDatabase = () => {
        if(formValid)
        {
            db.transaction(
                tx => {
                    tx.executeSql(
                      "INSERT INTO ContactsTable (firstName, lastName, email, phone, address1, address2, city, postalCode, provinceState, country, uri) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                      [dataForDatabase.firstName, dataForDatabase.lastName, dataForDatabase.email, dataForDatabase.phone, 
                       dataForDatabase.address1, dataForDatabase.address2, dataForDatabase.city, dataForDatabase.postalCode, 
                       dataForDatabase.provinceState, dataForDatabase.country, dataForDatabase.uri],
                      () => {
                        setStatusMessage('Saved Successfully!');
                        saveImage();
                        setInfoSaved(true);
                      },
                      (_, error) => {
                        console.log(error);
                        setStatusMessage('Save failed!');
                      }
                    );
                  },
                  null,
                  retrieveFromDatabase
            );
            setShowMessage(true);
        }
        else
        {
            setStatusMessage('Missing fields - cannot save!');
            setShowMessage(true);
        }
    };

    const updateToDatabase = () => {
        db.transaction(
            tx => {
                tx.executeSql(
                    `UPDATE ContactsTable
                    SET firstName = (?), lastname = (?), email = (?), phone = (?), address1 = (?), address2 = (?), city = (?), postalCode = (?), provinceState = (?), country = (?), uri = (?)
                    WHERE id = 1`,
                    [firstName, lastName, email, phone, address1, address2, city, postalCode, provinceState, country, dbURI],
                    () => {
                        setStatusMessage('Updated Successfully!');
                        saveImage();
                    },
                    (_, error) => {
                        console.log(error);
                        setStatusMessage('Update failed!');
                    }
                )
            },
            null,
            retrieveFromDatabase
        );
        setShowMessage(true);
    };

    const retrieveFromDatabase = () => {
        db.transaction(
            tx => {
                tx.executeSql(
                "SELECT * FROM ContactsTable",
                [],
                (_, { rows }) => {
                    if(rows._array[0] !== undefined) {
                        setDataFromDatabase(rows._array[0]);
                        setFirstName(rows._array[0].firstName);
                        setLastName(rows._array[0].lastName);
                        setEmail(rows._array[0].email);
                        setPhone(rows._array[0].phone);
                        setAddress1(rows._array[0].address1);
                        setAddress2(rows._array[0].address2);
                        setCity(rows._array[0].city);
                        setPostalCode(rows._array[0].postalCode);
                        setProvinceState(rows._array[0].provinceState);
                        setCountry(rows._array[0].country);
                        loadImage(rows._array[0].uri);
                        setInfoSaved(true);
                    }
                },
                (_, error) => console.log('SELECT failed:', error)
                )
            }
        );
    };

    const dropDatabase = () => {
        db.transaction(
            tx => {
                tx.executeSql(
                    `DROP TABLE IF EXISTS ContactsTable`,
                    [],
                    () => {
                        setStatusMessage('Table has been dropped!');
                        clearDocumentDirectory();
                        setShowMessage(true);
                    },
                    (_, error) => {
                        console.log(error);
                        setStatusMessage('Table drop failed!');
                        setShowMessage(true);
                    }
                )
            }
        );
    };

    const clearDocumentDirectory = async () => {
        FileSystem.getInfoAsync(imgDir).then(async () => {
            await FileSystem.deleteAsync(imgDir, {});
        })    
    };

    const imageSelectedHandler = (uri) => {
        setSelectedImageUri(uri);
        const filename = uri.split('/').pop();
        dbURI = filename;
        onChangeHandler(filename, "uri")
    };
    
    const resetHandler = () => {
        setSelectedImageUri(null);
    };

    return (
        <ScrollView contentContainerStyle={styles.scrollViewContainer}>
            <View style={styles.screen}>
                <Text style={styles.label}>k_marquez150012</Text>
                <Text style={styles.header}>Lab 7 - Contact Info App</Text>
                {!selectedImageUri ? (
                    <ImageSelector onImageSelected={imageSelectedHandler} />
                ) : (
                    <TouchableOpacity style={styles.imagePreview} onPress={resetHandler} >
                        <Image style={styles.image} source={{ uri: selectedImageUri }} />
                    </TouchableOpacity>
                )}
                
                {!infoSaved && (
                    <View>
                        <View style={styles.section}>
                            <InputField label="First Name" onChangeText={(text) => onChangeHandler(text, 'firstName')} placeholder="First Name" value={firstName}/>
                            <InputField label="Last Name" onChangeText={(text) => onChangeHandler(text, 'lastName')} placeholder="Last Name" value={lastName}/>
                        </View>
                        <View style={styles.section}>
                            <InputField label="Email Address" onChangeText={(text) => onChangeHandler(text, 'email')} placeholder="Email Address" value={email}/>
                            <InputField label="Phone Number" onChangeText={(text) => onChangeHandler(text, 'phone')} placeholder="Phone Number" value={phone}/>
                        </View>
                        <View style={styles.section}>
                            <InputField label="Address" onChangeText={(text) => onChangeHandler(text, 'address1')} placeholder="Address Line 1" value={address1}/>
                            <InputField label="" onChangeText={(text) => onChangeHandler(text, 'address2')} placeholder="Address Line 2" value={address2}/>
                        </View>
                        <View style={styles.section}>
                            <InputField label="City" onChangeText={(text) => onChangeHandler(text, 'city')} placeholder="City" value={city}/>
                            <InputField label="Postal Code" onChangeText={(text) => onChangeHandler(text, 'postalCode')} placeholder="Postal Code" value={postalCode}/>
                        </View>
                        <View style={styles.section}>
                            <ProvinceStatePicker label="Province/State" onChangeText={(text) => onChangeHandler(text, 'provinceState')} placeholder="Province/State" value={provinceState}/>
                            <CountryPicker label="Country" onChangeText={(text) => onChangeHandler(text, 'country')} placeholder="Country" value={country}/>
                        </View>
                    </View>
                )}

                {!infoSaved && (
                    <Button 
                        title="Save"
                        onPress={saveToDatabase}
                        color="#007bff"
                    />
                )}

                {infoSaved && (
                    <View>
                        <View style={styles.section}>
                            <InputField label="First Name" onChangeText={(text) => setFirstName(text)} placeholder="First Name" value={firstName}/>
                            <InputField label="Last Name" onChangeText={(text) => setLastName(text)} placeholder="Last Name" value={lastName}/>
                        </View>
                        <View style={styles.section}>
                            <InputField label="Email Address" onChangeText={(text) => setEmail(text)} placeholder="Email Address" value={email}/>
                            <InputField label="Phone Number" onChangeText={(text) => setPhone(text)} placeholder="Phone Number" value={phone}/>
                        </View>
                        <View style={styles.section}>
                            <InputField label="Address" onChangeText={(text) => setAddress1(text)} placeholder="Address Line 1" value={address1}/>
                            <InputField label="" onChangeText={(text) => setAddress2(text)} placeholder="Address Line 2" value={address2}/>
                        </View>
                        <View style={styles.section}>
                            <InputField label="City" onChangeText={(text) => setCity(text)} placeholder="City" value={city}/>
                            <InputField label="Postal Code" onChangeText={(text) => setPostalCode(text)} placeholder="Postal Code" value={postalCode}/>
                        </View>
                        <View style={styles.section}>
                            <ProvinceStatePicker label="Province/State" onChangeText={(text) => setProvinceState(text)} placeholder="Province/State" value={provinceState}/>
                            <CountryPicker label="Country" onChangeText={(text) => setCountry(text)} placeholder="Country" value={country}/>
                        </View>
                    </View>
                )}

                {infoSaved && (
                    <Button
                        title="Update"
                        onPress={updateToDatabase}
                        color="#007bff"
                    />
                )}
                
                <View style={{marginTop: 10}}>
                    <Button
                        title="Delete Data"
                        onPress={dropDatabase}
                        color="red"
                    />
                </View>

                {showMessage && (<View style={styles.form}>
                    <Text style={styles.text}>
                    { showMessage ? statusMessage : null}
                    </Text>
                </View>)}
            </View>
        </ScrollView>
    )
}

export default MainScreen;