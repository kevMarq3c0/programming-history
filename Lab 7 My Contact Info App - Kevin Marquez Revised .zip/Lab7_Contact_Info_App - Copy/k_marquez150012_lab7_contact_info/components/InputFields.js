import React, { useState, useEffect } from 'react';
import {View, Text, TextInput} from 'react-native';
import { styles } from '../styles/style';

const InputField = (props) => {
    const [value, setValue] = useState('');

    const onChangeHandler = (value) => {
        setValue(value);
        props.onChangeText(value);
    }

    useEffect(() => {
        if(props.value)
        {
            setValue(props.value);
        }
    }, [props.value]);

    return (
        <View style={styles.inputGroup}>
            {props.label !== "" && <Text style={styles.inputLabel}>{props.label}</Text>}
            <TextInput 
                style={styles.textInput}  
                onChangeText={onChangeHandler}
                value={value}
                placeholder={props.placeholder}
                keyboardType={props.keyboardType}
            />
        </View>
    )
};

export default InputField;