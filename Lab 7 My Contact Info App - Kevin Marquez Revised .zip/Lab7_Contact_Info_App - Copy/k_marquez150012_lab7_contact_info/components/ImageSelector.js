import React from 'react';
import { View, Alert, Text, TouchableOpacity } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { styles } from '../styles/style';

// The following are required for access to the camera:
// expo install expo-image-picker

const ImageSelector = ({ onImageSelected }) => {
    const verifyPermissions = async () => {
        const result = await ImagePicker.requestCameraPermissionsAsync();
        
        if(result.status !== 'granted') {
            Alert.alert('Insufficient Permissions!', 'You need to grant camera permissions to use this app.', [{ text: 'Okay' }]);
            return false;
        }
        return true;
    }

    const handleImagePicked = async (pickerResult) => {
        if (pickerResult.canceled) {
            return;
        }
        if (pickerResult.assets && pickerResult.assets.length > 0) {
            const uri = pickerResult.assets[0].uri;
            onImageSelected(uri);
        }
    };

    const retrieveImageHandler = async () => {
        const hasPermission = await verifyPermissions();
        if(!hasPermission) {
            return;
        }
        
        const result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            allowsEditing: true,
            aspect: [4, 3],
            quality: 0.5
        });

        handleImagePicked(result);
    }
    
    return (
        <View style={styles.container}>
            <TouchableOpacity style={styles.defaultImage} onPress={retrieveImageHandler} >
                <Text style={styles.imageText}>ADD PICTURE</Text>
            </TouchableOpacity>
        </View>
    )
};

export default ImageSelector;
