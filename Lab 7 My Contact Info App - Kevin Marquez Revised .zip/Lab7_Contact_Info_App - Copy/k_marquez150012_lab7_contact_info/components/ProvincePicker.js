import React, { useState, useEffect } from 'react';
import { View, Text } from 'react-native';
import {Picker} from "@react-native-picker/picker"
import { styles } from '../styles/style';

const ProvinceStatePicker = props => {
    const [selectedProvinceState, setSelectedProvinceState] = useState();

    useEffect(() => {
        if(props.value)
        {
            setSelectedProvinceState(props.value);
        }
    }, [props.value]);

    const provinceStateChosen = (provinceState) => {
        setSelectedProvinceState(provinceState)
        props.onChangeText(provinceState);
    };

    var provinceStates = [
        'Alabama','Alaska', 'Alberta', 'American Samoa', 'Arizona', 'Arkansas',
        'British Columbia', 'California','Colorado', 'Connecticut', 'Delaware',
        'District of Columbia','Federated States of Micronesia','Florida','Georgia','Guam',
        'Hawaii','Idaho','Illinois','Indiana','Iowa','Kansas','Kentucky','Louisiana',
        'Maine', 'Manitoba', 'Marshall Islands','Maryland','Massachusetts','Michigan','Minnesota','Mississippi','Missouri','Montana',
        'Nebraska', 'Nevada', 'New Brunswick', 'New Hampshire','New Jersey','New Mexico','New York','North Carolina','North Dakota','Northern Mariana Islands',
        'Newfoundland and Labrador', 'Northwest Territories', 'Nova Scotia', 'Nunavut', 'Ohio','Oklahoma','Oregon', 'Ontario', 'Palau','Pennsylvania','Puerto Rico',
        'Prince Edward Island', 'Quebec', 'Rhode Island', 'Saskatchewan', 'South Carolina','South Dakota','Tennessee','Texas','Utah','Vermont',
        'Virgin Island','Virginia','Washington','West Virginia','Wisconsin','Wyoming', 'Yukon Territory'
    ]

    return (
        <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>{props.label}</Text>
            <Picker
                style={styles.pickerInput}
                selectedValue={props.value ? props.value :selectedProvinceState}
                onValueChange={(itemValue, itemIndex) => 
                    provinceStateChosen(itemValue)
                }>   
                <Picker.Item key={'unselectable'} label={props.placeholder} value='0' enabled={false} style={styles.disabledPickerItem}/>
                {provinceStates.map((provinceState) => {
                    return (<Picker.Item label={provinceState} value={provinceState} key={provinceState}/>)
                })}
            </Picker>
        </View>
    )
};

export default ProvinceStatePicker;