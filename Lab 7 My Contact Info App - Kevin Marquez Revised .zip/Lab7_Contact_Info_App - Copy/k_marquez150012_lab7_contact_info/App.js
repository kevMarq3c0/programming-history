import React from 'react';
import MainScreen from './screens/MainScreen';

export default function App() {
  return (
    <MainScreen />
  );
}