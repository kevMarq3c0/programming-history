﻿/*
 * Program: Course.cs
 * Date: 2024-02-15
 * Author: Kevin Marquez #1054838
 * Purpose: This non-generic class will represent a Course which contains an array of Students, a Professor for the course, various methods to calculate the average, highest,
 *          and lowest marks of the class and has an EventHandler that will notify the Professor when the average has been calculated
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ObjectiveC;
using System.Text;
using System.Threading.Tasks;

namespace Midterm_KM
{
    public class Course
    {
        //An array of three students and an index to keep populating it
        Student[] students = new Student[3];
        int index = 0;

        private Professor professor;

        //An EventHandler of Professor that will notify the professor once the class average is calculated
        public event EventHandler<Professor> AverageReleased;

        //A constructor that will initialize the Professor's name
        public Course(string firstName, string lastName)
        { 
            professor = new Professor(firstName, lastName);
        }

        /*
        * Method Name: Add
        * Purpose: This method will add a student to the array of students, and will throw an exception if the array is now full
        * Accepts: A Student object
        * Returns: Nothing
        */
        public void Add(Student newStudent)
        {
            if (index >= students.Length)
                throw new IndexOutOfRangeException("Students' array has reached its maximum capacity and cannot accept more students.");
            else
            {
                students[index] = newStudent;
                index++;
            }
        }

        /*
        * Method Name: ClassAverageValue
        * Purpose: This method will calculate and return the average of total marks of all registered students in the students' array
        * Accepts: Nothing
        * Returns: Double
        */
        public double ClassAverageValue()
        {
            double markSum = 0;
            for(int i = 0; i < students.Length; i++)
            {
                markSum += students[i].TotalMark;
            }
            double classAverage = (markSum / students.Length);
            OnAverageCalculated(professor);
            return classAverage;
        }

        /*
        * Method Name: ClassHighestMark
        * Purpose: This method will use a SortedSet and our OrderByMarks class to find and return the highest total mark in the class
        * Accepts: Nothing
        * Returns: Double
        */
        public double ClassHighestMark()
        {
            SortedSet<Student> highestMarks = new SortedSet<Student>(new OrderedByMarks());
            for(int i = 0; i < students.Length; i++)
            {
                highestMarks.Add(students[i]);
            }
            return highestMarks.Max!.TotalMark;
        }

        /*
        * Method Name: ClassLowestMark
        * Purpose: This method will use a SortedSet and our OrderByMarks class to find and return the lowest total mark in the class
        * Accepts: Nothing
        * Returns: Double
        */
        public double ClassLowestMark()
        {
            SortedSet<Student> lowestMarks = new SortedSet<Student>(new OrderedByMarks());
            for (int i = 0; i < students.Length; i++)
            {
                lowestMarks.Add(students[i]);
            }
            return lowestMarks.Min!.TotalMark;
        }

        /*
        * Method Name: OnAverageCalculated
        * Purpose: This virtual method will raise the Class Average calculated event to the Professor
        * Accepts: A Professor object
        * Returns: Nothing
        */
        protected virtual void OnAverageCalculated(Professor prof)
        {
            AverageReleased.Invoke(this, prof);
        }
    }
}
