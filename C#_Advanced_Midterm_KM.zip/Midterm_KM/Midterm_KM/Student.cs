﻿/*
 * Program: Student.cs
 * Date: 2024-02-15
 * Author: Kevin Marquez #1054838
 * Purpose: This non-generic class defines a Student including their properties such as a their name, their marks and their total marks. It will provide us with the ability
 *          to insert 3 marks and calculate their total mark.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm_KM
{
    public class Student
    {
        //First and Last Name Properties that have a null default value
        public string? FirstName { get; set; } = null;
        public string? LastName { get; set; } = null;

        //A double property that represents their TotalMark and has a default value of zero
        public double TotalMark { get; set; } = 0;

        //An array of 3 double numbers representing the grades/marks for each Student
        double[] Grades = new double[3];

        //A constructor that will instantiate the name of the Student
        public Student(string firstName, string lastName) 
        { 
            FirstName = firstName; 
            LastName = lastName;
        }

        /*
        * Method Name: CalculateTotalMarks
        * Purpose: This will calculate the total marks for each student and update their TotalMark property
        * Accepts: Nothing
        * Returns: Nothing
        */
        public void CalculateTotalMarks()
        {
            double totalMark = 0;
            for(int i = 0; i < Grades.Length; i++)
            {
                totalMark += Grades[i];
            }
            TotalMark = totalMark;
        }

        /*
        * Method Name: InsertMarks
        * Purpose: This method will prompt the user to populate three double numbers into the Grades array and validate their number entries
        * Accepts: Nothing
        * Returns: Nothing
        */
        public void InsertMarks()
        {
            double mark;
            bool IsValid;

            Console.WriteLine($"\nEnter the marks of student {FirstName} {LastName}");
            Console.WriteLine("-------------------------------------------------------------");
            for (int i = 0; i < 3; i++)
            {
                do
                {
                    IsValid = Double.TryParse(Console.ReadLine(), out mark);
                    if (mark < 0 || mark > 100)
                    {
                        Console.WriteLine("Out of range, please try again.");
                        IsValid = false;
                    }
                    else if (!IsValid)
                    {
                        Console.WriteLine("Not a number, please try again!");
                    }
                } while (!IsValid);

                Grades[i] = mark;
            }
        }
    }
}
