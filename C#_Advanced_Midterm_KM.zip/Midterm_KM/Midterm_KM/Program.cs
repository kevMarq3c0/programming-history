﻿/*
 * Program: Program.cs
 * Date: 2024-02-15
 * Author: Kevin Marquez #1054838
 * Purpose: This is the main method where we will initialize our studnets and create a Course object
 */

namespace Midterm_KM
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //This is an array to define the headers once we show the marks of the class
            string[] markHeaders = new string[] { "The average of the class:", "The top mark of the class", "The Lowest mark of the class" };

            //Create and initialize 3 Student objects
            Student firstStudent = new Student("Clara", "Lara");
            Student secondStudent = new Student("Mathew", "Walker");
            Student thirdStudent = new Student("Dora", "Maldonado");

            //Prompt the user to populate the marks for each Student
            firstStudent.InsertMarks();
            secondStudent.InsertMarks();
            thirdStudent.InsertMarks();

            //Calculate the total marks of each Student
            firstStudent.CalculateTotalMarks();
            secondStudent.CalculateTotalMarks();
            thirdStudent.CalculateTotalMarks();

            //Declare a Course object and initialize it with the name of the Professor
            Course Info5101 = new Course("Kevin", "Marquez");
            //Add the Students to this Course
            Info5101.Add(firstStudent); 
            Info5101.Add(secondStudent); 
            Info5101.Add(thirdStudent);

            //Assign the subscriber method to the publisher
            Info5101.AverageReleased += NotifyProfessor;

            //Use the Func<> delegate to encapsulate the class mark calculations in our Course object
            Func<double> classMarks = Info5101.ClassAverageValue;
            classMarks += Info5101.ClassHighestMark;
            classMarks += Info5101.ClassLowestMark;

            //Iterate through all the methods encapsulated in the Func<> delegate and display the results
            int index = 0;
            foreach(Func<double> markResult in classMarks.GetInvocationList())
            {
                double result = markResult();
                Console.WriteLine(markHeaders[index]);
                Console.WriteLine("--------------------------");
                Console.WriteLine("{0:N2}", result);
                index++;
            }
        }

        /*
        * Method Name: NotifyProfessor
        * Purpose: This static method will act as a subscriber and show a message upon an Event being raised to the Professor
        * Accepts: An object which is the source and a Professor object
        * Returns: Nothing
        */
        public static void NotifyProfessor(object Source, Professor prof)
        {
            Console.WriteLine($"Hi Professor {prof.FirstName} {prof.LastName}, the class average has been calculated; other statistics will be displayed on the console soon.");
        }
    }
}
