﻿/*
 * Program: Professor.cs
 * Date: 2024-02-15
 * Author: Kevin Marquez #1054838
 * Purpose: This non-generic class defines a Professor for a Course that has two properties, their first and last name
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm_KM
{
    public class Professor 
    {
        //Their name properties 
        public string? FirstName { get; set; }
        public string? LastName { get; set; }

        //A constructor that will instantiate the name of the Professor
        public Professor(string firstName, string lastName)
        { 
            FirstName = firstName;
            LastName = lastName;
        }
    }
}
