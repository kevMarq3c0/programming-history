﻿/*
 * Program: OrderedByMarks.cs
 * Date: 2024-02-15
 * Author: Kevin Marquez #1054838
 * Purpose: This non-generic class will implement the generic form of IComparer and sort the students passed to it based on their total mark.
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm_KM
{
    public class OrderedByMarks : IComparer<Student>
    {
        /*
        * Method Name: Compare
        * Purpose: This method implements the IComparer interface to sort the students according to their total mark
        * Accepts: Two Student objects
        * Returns: An int
        */
        public int Compare(Student? firstStudent, Student? secondStudent)
        {
            if (firstStudent!.TotalMark > secondStudent!.TotalMark)
                return 1;
            if (firstStudent!.TotalMark < secondStudent!.TotalMark)
                return -1;
            else
                return 0;
        }
    }
}
