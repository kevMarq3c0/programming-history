﻿/*
 * Program: ProblemViewModel.cs
 * Purpose: Creates a ViewModel for the Problems Table that lets us have a GUI application view so we can provide data and functionality 
 *          that will actually be used and represents the Presentation layer for EmployeeCalls
 * Coder: Kevin Marquez 
 * Date: December 12 2022
 */
using HelpDeskDAL;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Threading.Tasks;

namespace HelpDeskViewModels
{
    //Create a class for ProblemViewModel that has properties to provide the state to the view and methods that will change the state
    public class ProblemViewModel
    {
        readonly private ProblemDAO _dao;

        public int? Id { get; set; }
        public string? Description { get; set; }
        public string? Timer { get; set; }

        // Constructor for the CallViewModel that instantiates it with an CallDAO object
        public ProblemViewModel()
        {
            _dao = new ProblemDAO(); 
        }

        //Get a Problem by its decription, then instantiate the properties in the viewmodel with these values
        public async Task GetByDescription()
        {
            try
            {
                Problem pro = await _dao.GetByDescription(Description!);
                Description = pro.Description;
                Id = pro.Id;
                Timer = Convert.ToBase64String(pro.Timer!);
            }
            catch (NullReferenceException nex)
            {
                Debug.WriteLine(nex.Message);
                Description = "not found";
            }
            catch (Exception ex)
            {
                Description = "not found";
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
        }

        //Get all problems and their descriptions, and return a List of ProblemViewModels
        public async Task<List<ProblemViewModel>> GetAll()
        {
            List<ProblemViewModel> allVms = new();
            try
            {
                List<Problem> allProblems = await _dao!.GetAll();
                foreach(Problem pro in allProblems)
                {
                    ProblemViewModel proVm = new()
                    { 
                        Id = pro.Id,
                        Description = pro.Description,
                        Timer = Convert.ToBase64String(pro.Timer!)
                    };
                    allVms.Add(proVm);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            return allVms;
        }
    }
}
