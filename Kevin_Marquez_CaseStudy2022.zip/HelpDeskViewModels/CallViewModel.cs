﻿/*
 * Program: CallViewModel.cs
 * Purpose: Creates a ViewModel for the Calls Table that lets us have a GUI application view so we can provide data and functionality 
 *          that will actually be used and represents the Presentation layer for EmployeeCalls
 * Coder: Kevin Marquez 
 * Date: December 12 2022
 */
using HelpDeskDAL;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Threading.Tasks;

namespace HelpDeskViewModels
{
    //Create a class for CallViewModel that has properties to provide the state to the view and methods that will change the state
    public class CallViewModel
    {
        readonly private CallDAO _dao;

        public int Id { get; set; }
        public int EmployeeId { get; set; }
        public int ProblemId { get; set; }
        public string? EmployeeName { get; set; }
        public string? ProblemDescription { get; set; }
        public string? TechName { get; set; }
        public int TechId { get; set; }
        public DateTime DateOpened { get; set; }
        public DateTime? DateClosed { get; set; }
        public bool OpenStatus { get; set; }
        public string? Notes { get; set; }
        public string? Timer { get; set; }

        // Constructor for the CallViewModel that instantiates it with an CallDAO object
        public CallViewModel()
        {
            _dao = new CallDAO();
        }

        //Retrieve the Call by its id 
        public async Task GetById()
        {
            try
            {
                Call call = await _dao.GetByID(Id!);
                //Instantiate the attributes with the results of the GetByID from dao
                Id = call.Id;
                EmployeeId = call.EmployeeId;
                ProblemId = call.ProblemId;
                TechId = call.TechId;
                DateOpened = call.DateOpened;
                DateClosed = call.DateClosed;
                OpenStatus = call.OpenStatus; 
                Notes = call.Notes;
                Timer = Convert.ToBase64String(call.Timer!);
            }
            catch (NullReferenceException nex)
            {
                Debug.WriteLine(nex.Message);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
        }

        //This method will get all the calls and return a list of CallViewModel
        public async Task<List<CallViewModel>> GetAll()
        {
            //Create at list of CallViewModels
            List<CallViewModel> allVms = new();
            try
            {
                List<Call> allCalls = await _dao.GetAll();

                //For every Call, initialize that entry of the CallViewModel with its return attribute values
                foreach (Call call in allCalls)
                {
                    CallViewModel callVm = new() 
                    {
                        Id = call.Id,
                        EmployeeId = call.EmployeeId,
                        ProblemId = call.ProblemId,
                        TechId = call.TechId,
                        EmployeeName = call.Employee.FirstName,
                        ProblemDescription = call.Problem.Description,
                        DateOpened = call.DateOpened,
                        DateClosed = call.DateClosed,
                        OpenStatus = call.OpenStatus,
                        Notes = call.Notes,
                        Timer = Convert.ToBase64String(call.Timer!)
                    };
                    //Add to the list of CallViewModels
                    allVms.Add(callVm);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            return allVms;
        }

        //This method will add a new Call 
        public async Task Add()
        {
            Id = -1;
            try
            {
                //Instantiate a Call object, then call the Add() in dao to see if it is successful
                Call call = new()
                {
                    EmployeeId = EmployeeId,
                    ProblemId = ProblemId,
                    TechId = TechId,
                    DateOpened = DateOpened,
                    DateClosed = DateClosed,
                    OpenStatus = OpenStatus,
                    Notes = Notes!
                };
                Id = await _dao.Add(call);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
        }

        //This method will update a Call entry in the database
        public async Task<int> Update()
        {
            try
            {
                //Instatiate a Call object then see if it can be updated in the database
                Call call = new()
                {
                    Id = (int)Id!,
                    EmployeeId = EmployeeId,
                    ProblemId = ProblemId,
                    TechId = TechId,
                    DateOpened = DateOpened,
                    DateClosed = DateClosed,
                    OpenStatus = OpenStatus,
                    Notes = Notes!
                };
                call.Timer = Convert.FromBase64String(Timer!);

                return Convert.ToInt16(await _dao.Update(call));
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
        }

        //This method will delete a Call in the database
        public async Task<int> Delete()
        {
            try
            {
                return await _dao.Delete(Id);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
        }
    }
}
