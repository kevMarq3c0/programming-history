﻿/*
 * Program: DepartmentViewModel.cs
 * Purpose: Creates a ViewModel for the Departments Table that lets have a GUI application view so we can provide data and functionality 
 *          that will actually be used and represents the Presentation layer. We will abstract the physical database related objects as 
 *          much as possible
 * Coder: Kevin Marquez 
 * Date: October 26 2022
 */

//Make a reference to the HelpDeskDAL project to act as a client of the DAO
using HelpDeskDAL;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Threading.Tasks;

namespace HelpDeskViewModels
{
    //Create a class for DepartmentViewModel that has properties to provide the state to the view and methods that will load and change the state
    public class DepartmentViewModel
    {
        readonly private DepartmentDAO? _dao;

        //Getters and Setters for the attributes in the DepartmentViewModel
        public int? Id { get; set; }
        public string? Name { get; set; }
        public string? Timer { get; set; }

        //Constructor for DepartmentViewModel that instantiates with a DepartmentDAO
        public DepartmentViewModel()
        {
            _dao = new DepartmentDAO();
        }

        //Get all the Departments as DepartmentViewModel instances
        public async Task<List<DepartmentViewModel>>GetAll()
        {
            List<DepartmentViewModel> allVms = new();
            try
            {
                List<Department> allDepartments = await _dao!.GetAll();

                //Convert Department instance to DepartmentViewModel since the Web Layer isn't aware of the domain class 
                foreach (Department dep in allDepartments)
                {
                    DepartmentViewModel depVm = new()
                    { 
                        Id = dep.Id,
                        Name = dep.DepartmentName,
                        Timer = Convert.ToBase64String(dep.Timer!)
                    };
                    allVms.Add(depVm);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " +
                MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            return allVms;
        }
    }
}
