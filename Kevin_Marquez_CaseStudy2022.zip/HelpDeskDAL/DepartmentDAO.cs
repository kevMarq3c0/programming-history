﻿/*
 * Program: DepartmentDAO.cs
 * Purpose: Allows us to create methods that will grant us access to the Department database using entity or lambda expressions
 *          working along with the domain classes and as a server to another layer, we have to get through DAO to give and read information 
 * Coder: Kevin Marquez 
 * Date: October 26 2022
 */
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace HelpDeskDAL
{
    public class DepartmentDAO
    {
        //Create a readonly IRepository object that takes in Department as a result of the generic parameter T
        readonly IRepository<Department> _repo;

        //Instantiate the IRepository object with a HelpDeskRepository object of type Department 
        public DepartmentDAO()
        {
            _repo = new HelpDeskRepository<Department>();
        }

        //Retrieve a list of Department instances to the user 
        public async Task<List<Department>>GetAll()
        {
            List<Department> allDepartments;
            try
            {
                //Make an async request to the GetAll method to see to instantiate the list 
                allDepartments = await _repo.GetAll();
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            //return the list of Departments 
            return allDepartments;
        }
    }
}
