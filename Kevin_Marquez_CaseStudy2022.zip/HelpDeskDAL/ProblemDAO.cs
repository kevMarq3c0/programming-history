﻿/*
 * Program: ProblemDAO.cs
 * Purpose: Allows us to create methods that will grant us access to the Problem database with the Domain class to provide and edit
 *          information in our database. This can then be used in our ViewModel and in our application layer
 * Coder: Kevin Marquez 
 * Date: December 12 2022
 */
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Reflection;

namespace HelpDeskDAL
{
    public class ProblemDAO
    {
        //Create a readonly IRepository object that takes a Problem Object
        readonly IRepository<Problem> _repo;

        //Instantiate the IRepository object with a HelpDeskRepository of Call type
        public ProblemDAO()
        {
            _repo = new HelpDeskRepository<Problem>();
        }

        //This will retrieve a Problem entry based on its description
        public async Task<Problem> GetByDescription(string? description)
        {
            Problem? possibleProblem;
            try
            {
                possibleProblem = await _repo.GetOne(pro => pro.Description == description);
            }
            catch(Exception ex) 
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " +
                MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            return possibleProblem!;
        }

        //This will get all of the problems and return a list of Problem type
        public async Task<List<Problem>> GetAll()
        {
            List<Problem> allProblems;
            try
            {
                allProblems = await _repo.GetAll();
            }
            catch (Exception ex) 
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " +
                MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            return allProblems;
        }
    }
}
