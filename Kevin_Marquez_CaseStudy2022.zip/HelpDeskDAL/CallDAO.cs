﻿/*
 * Program: CallDAO.cs
 * Purpose: Allows us to create methods that will grant us access to the Call database with the Domain class to provide and edit
 *          information in our database. This can then be used in our ViewModel and in our application layer
 * Coder: Kevin Marquez 
 * Date: December 12 2022
 */
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Reflection;

namespace HelpDeskDAL
{
    public class CallDAO
    {
        //Create a readonly IRepository object that takes a Call Object
        readonly IRepository<Call> _repo;

        //Instantiate the IRepository object with a HelpDeskRepository of Call type
        public CallDAO()
        {
            _repo = new HelpDeskRepository<Call>();
        }

        //This method will get the Call based on its corresponding id 
        public async Task<Call> GetByID(int callId)
        {
            Call? selectedCall;
            try
            {
                selectedCall = await _repo.GetOne(call => call.Id == callId);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            return selectedCall!;
        }

        //This method will return a List of Call Type and retrieve all the Call information from the database
        public async Task<List<Call>> GetAll()
        {
            List<Call> allCalls;
            try
            {
                allCalls = await _repo.GetAll();
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            return allCalls;
        }

        //This method will add a new entry in the database 
        public async Task<int> Add(Call newCall)
        {
            try
            {
                newCall = await _repo.Add(newCall);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            return newCall.Id;
        }

        //This method will update a known Call and return an updateStatus
        public async Task<UpdateStatus> Update(Call updatedCall)
        {
            UpdateStatus status;
            try
            {
                status = await _repo.Update(updatedCall);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            return status;
        }

        //This will delete a Call in the database based on its id
        public async Task<int> Delete(int? id)
        {
            int callsDeleted = -1;
            try
            {
                callsDeleted = await _repo.Delete((int)id!);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            return callsDeleted;
        }
    }
}
