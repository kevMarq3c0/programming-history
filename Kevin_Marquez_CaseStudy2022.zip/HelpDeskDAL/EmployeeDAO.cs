﻿/*
 * Program: EmployeeDAO.cs
 * Purpose: Allows us to create methods that will grant us access to the Employee database using entity or lambda expressions
 *          working along with the domain classes and as a server to another layer, we have to get through DAO to give and read information 
 * Coder: Kevin Marquez 
 * Date: October 26 2022
 */
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Reflection;

namespace HelpDeskDAL
{
   
    public class EmployeeDAO
    {
        //Create a constructor of the repository and calss member that will allow EmployeeDAO to use the HelpDeskRepository
        readonly IRepository<Employee> _repo;
        public EmployeeDAO()
        {
            _repo = new HelpDeskRepository<Employee>();
        }

        //Allows us to retrieve data on an employee based on their email address
        public async Task<Employee> GetByEmail(string? email)
        {
            //? acts as a way to say there is a possibilty of it being null or condition that it is empty / doesn't exist 
            Employee? selectedEmp;
            try
            {
                //Make a request to an asynchronous operation of GetOne involving the Employee's email 
                selectedEmp = await _repo.GetOne(emp=> emp.Email == email);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            //Null acceptor, so that the compiler doesn't get mad and instead we can ignore the warning
            return selectedEmp!;
        }

        //Gets an Employee based on their Id 
        public async Task<Employee> GetByID(int id)
        {
            Employee? selectedEmployee;
            try
            {
                //Makes a request to an asynchronous operation that will find the Employer Id and return it
                selectedEmployee = await _repo.GetOne(emp=> emp.Id == id);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            return selectedEmployee!;
        }

        //Retrieve a list container filled with all the employees' information that contains a series of Employee instances 
        public async Task<List<Employee>> GetAll()
        {
            List<Employee> allEmployees;
            try
            {
                //Make an async request and see if it is successful, if so, then fill the List with the Employee instances
                allEmployees = await _repo.GetAll();
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            //Return the list of Employees 
            return allEmployees;
        }

        //Add a new employee entry to the database, returns 
        public async Task<int> Add(Employee newEmployee)
        {
            try
            {
                newEmployee = await _repo.Add(newEmployee);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            return newEmployee.Id;
        }

        //This method differs because we pass the UpdateStatus, an enumerated operator that can identify if an error occurred or data is stale
        public async Task<UpdateStatus> Update(Employee updatedEmployee)
        {
            //Create an UpdateStatus to check if our changes were successful or not 
            UpdateStatus status;

            try
            {
                status = await _repo.Update(updatedEmployee);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            return status;
        }
        
        //Delete an entry in the database and return an int that represents the number of rows deleted
        public async Task<int> Delete(int? id)
        {
            int employeesDeleted = -1;
            try
            {
                //See if we can find the id that was passed if it is present on the database 
                //We have to explicitly cast the int for VS2022 to change the nullable 
                employeesDeleted = await _repo.Delete((int)id!); 
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                throw;
            }
            return employeesDeleted;
        }
    }

}
