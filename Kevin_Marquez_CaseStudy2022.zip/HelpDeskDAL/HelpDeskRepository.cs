﻿/*
 * Program: HelpDeskRepository.cs
 * Purpose: In order to avoid the DRY principle where we constantly create new DAOs which will have a lot of repeating code, the 
 *          HelpDeskRepository allows us to abstract the data layer and centralize the domain classes by mimicking an interface 
 * Coder: Kevin Marquez 
 * Date: October 26 2022
 */
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using System.Reflection;

namespace HelpDeskDAL
{
    //Define Generic Parameter T, so that it can specialize at compile time whatever Domain object we pass it 
    public class HelpDeskRepository<T> : IRepository<T> where T : HelpDeskEntity
    {
        readonly private HelpDeskContext _db;
        public HelpDeskRepository()
        {
            _db = new HelpDeskContext();
        }

        //Create a list of methods that accept the generic parameter T and thus can be made available to any of the domain classes
        //Which will promote type-safe data and boost performance 
        public async Task<List<T>> GetAll()
        {
            return await _db.Set<T>().ToListAsync();
        }
        //GetSome will create a predicate where we see if the condition we pass it evaluates to true or false 
        public async Task<List<T>> GetSome(Expression<Func<T, bool>> match)
        {
            return await _db.Set<T>().Where(match).ToListAsync();
        }

        //GetOne will accomplish what GetSome does on a singular level, usually at the top of the stack
        public async Task<T?> GetOne(Expression<Func<T, bool>> match)
        {
            return await _db.Set<T>().FirstOrDefaultAsync(match);
        }

        //Changes the database by adding on a new entity then saving the changes asynchroniously 
        public async Task<T> Add(T entity)
        {
            _db.Set<T>().Add(entity);
            await _db.SaveChangesAsync();
            return entity;
        }

        //Update an entity found in the database and see if the UpdateStatus is secure and went through, if not then pass a reason for the 
        //error
        public async Task<UpdateStatus> Update(T updatedEntity)
        {
            UpdateStatus operationStatus = UpdateStatus.Failed;
            try
            {
                T? currentEntity = await GetOne(ent => ent.Id == updatedEntity.Id);
                _db.Entry(currentEntity!).OriginalValues["Timer"] = updatedEntity.Timer;
                _db.Entry(currentEntity!).CurrentValues.SetValues(updatedEntity);
                if (await _db.SaveChangesAsync() == 1) // should throw exception if stale;
                    operationStatus = UpdateStatus.Ok;
            }
            catch (DbUpdateConcurrencyException dbx)
            {
                operationStatus = UpdateStatus.Stale;
                Console.WriteLine("Problem in " + MethodBase.GetCurrentMethod()!.Name + dbx.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Problem in " + MethodBase.GetCurrentMethod()!.Name + ex.Message);
            }
            return operationStatus;
        }

        //Delete an object from the database given its id, then save the changes
        public async Task<int> Delete(int id)
        {
            T? currentEntity = await GetOne(ent => ent.Id == id);
            _db.Set<T>().Remove(currentEntity!);
            return _db.SaveChanges();
        }
    }
}
