﻿/*
 * Program: UpdateStatus.cs
 * Purpose: An class that holds an enumerated value that we can use for the Update status which contains all the possible 
 *          responses when we try and update 
 * Coder: Kevin Marquez 
 * Date: October 26 2022
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDeskDAL
{
    //Create an accessible enum operator UpdateStatus to be used in Update methods 
    public enum UpdateStatus
    {
        Ok = 1,
        Failed = -1,
        Stale = -2
    }
}
