﻿using Xunit;
using HelpdeskViewModels;
using System.Threading.Tasks;
using HelpDeskDAL;

namespace CaseStudyTests
{
    public class ViewModelTests
    {
        [Fact]
        public async Task Employee_GetByEmailTest()
        {
            EmployeeViewModel vem = new() { Email = "km@abc.com" };
            await vem.GetByEmail();
            Assert.NotNull(vem.Email);
        }

        [Fact]
        public async Task Employee_GetByIdTest()
        {
            EmployeeViewModel vem = new() { Email = "km@abc.com" };
            await vem.GetByEmail();

            EmployeeViewModel vem2 = new() { Id = vem.Id };
            await vem2.GetById();
            Assert.NotNull(vem.Firstname);
        }

        [Fact]
        public static async Task Employee_GetAllTest()
        {
            List<EmployeeViewModel> allEmployeeVms;

            EmployeeViewModel vem = new();

            allEmployeeVms = await vem.GetAll();
            Assert.True(allEmployeeVms.Count > 0);
        }

        [Fact]
        public async Task Employee_AddTest()
        {
            EmployeeViewModel vem;
            vem = new()
            { 
                Title = "Mr.",
                Firstname = "Kevin",
                Lastname = "Marquez",
                Email = "k_marquez150012@fanshaweonline.ca",
                Phoneno = "(222)777-8881",
                IsTech = true,
                DepartmentId = 500
            };
            await vem.Add();
            Assert.True(vem.Id > 0);
        }

        [Fact]
        public async Task Employee_UpdateTest()
        {
            EmployeeViewModel vem = new() { Email = "km@abc.com" };
            await vem.GetByEmail();
            vem.Phoneno = vem.Phoneno == "(222)777-8881" ? "(444)555-2221" : "(555)555-5551";
            
            Assert.True(await vem.Update() == 1);
        }

        [Fact]
        public async Task Employee_DeleteTest()
        {
            EmployeeViewModel vem = new() { Email = "km@abc.com" };
            await vem.GetByEmail();
            Assert.True(await vem.Delete() == 1);
        }
    }
}
