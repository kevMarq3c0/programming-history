using ExercisesDAL;
using HelpDeskDAL;
using HelpdeskViewModels;
using HelpDeskViewModels;
using Xunit.Abstractions;

namespace CaseStudyTests
{
    public class DAOTests
    {
        private readonly ITestOutputHelper output;
        public DAOTests(ITestOutputHelper output)
        {
            this.output = output; 
        }

        [Fact]
        public async Task Employee_GetByEmailTest()
        {
            EmployeeDAO dao = new();
            Employee selectedEmployee = await dao.GetByEmail("bs@abc.com");
            Assert.NotNull(selectedEmployee);
        }

        [Fact]
        public async Task Employee_GetByID()
        {
            EmployeeDAO dao = new();
            Employee? selectedEmployee = await dao.GetByID(1);
            Assert.NotNull(selectedEmployee);
        }

        [Fact]
        public async Task Employee_GetAllTest()
        {
            EmployeeDAO dao = new();
            List<Employee> allEmployees = await dao.GetAll();
            Assert.True(allEmployees.Count() > 0);
        }

        [Fact]
        public async Task Employee_AddTest()
        {
            EmployeeDAO dao = new();
            Employee newEmployee = new()
            {
                FirstName = "Kevin",
                LastName = "Marquez",
                PhoneNo = "(222)333-4444",
                Title = "Mr.",
                DepartmentId = 500,
                IsTech = true,
                Email = "k_marquez150012@fanshaweonline.ca"
            };
            Assert.True(await dao.Add(newEmployee) > 0);
        }

        [Fact]
        public async Task Employee_UpdateTest()
        {
            EmployeeDAO dao = new();
            Employee? employeeForUpdate = await dao.GetByEmail("k_marquez150012@fanshaweonline.ca");
            if (employeeForUpdate != null)
            {
                string oldPhoneNo = employeeForUpdate.PhoneNo!;
                string newPhoneNo = oldPhoneNo == "519-555-1234" ? "555-555-5555" : "519-555-1234";
                employeeForUpdate!.PhoneNo = newPhoneNo;
            }
            Assert.True(await dao.Update(employeeForUpdate!) == UpdateStatus.Ok); // 1 indicates the # of rows updated
        }

        [Fact]
        public async Task Employee_DeleteTest()
        {
            EmployeeDAO dao = new();
            Employee? employeeForDelete = await dao.GetByEmail("k_marquez150012@fanshaweonline.ca");
            Assert.True(await dao.Delete(employeeForDelete!.Id) == 1); // 1 indicates the # of rows updated
        }

        [Fact]
        public async Task Employee_ConcurrencyTest()
        {
            EmployeeDAO dao1 = new();
            EmployeeDAO dao2 = new();
            Employee employeeForUpdate1 = await dao1.GetByEmail("k_marquez150012@fanshaweonline.ca");
            Employee employeeForUpdate2 = await dao2.GetByEmail("k_marquez150012@fanshaweonline.ca");
            if (employeeForUpdate1 != null)
            {
                string? oldPhoneNo = employeeForUpdate1.PhoneNo;
                string? newPhoneNo = oldPhoneNo == "519-555-1234" ? "555-555-5555" : "519-555-1234";
                employeeForUpdate1.PhoneNo = newPhoneNo;
                if (await dao1.Update(employeeForUpdate1) == UpdateStatus.Ok)
                {
                    // need to change the phone # to something else
                    employeeForUpdate2.PhoneNo = "666-666-6668";
                    Assert.True(await dao2.Update(employeeForUpdate2) == UpdateStatus.Stale);
                }
                else
                    Assert.True(false); // first update failed
            }
            else
                Assert.True(false); // didn't find employee 1
        }

        [Fact]
        public async Task Employees_LoadPicsTest()
        {
            {
                CasestudyDALPicUtil util = new();
                Assert.True(await util.AddEmployeePicsToDb());
            }
        }

        [Fact]
        public async Task Call_ComprehensiveText()
        {
            CallDAO cdao = new();
            EmployeeDAO edao = new();
            ProblemDAO pdao = new();
            Employee kevin = await edao.GetByEmail("k_marquez150012@fanshaweonline.ca");
            Employee burner = await edao.GetByEmail("bb@abc.com");
            Problem badDrive = await pdao.GetByDescription("Hard Drive Failure");
            Call call = new()
            {
                DateOpened = DateTime.Now,
                DateClosed = null,
                OpenStatus = true,
                EmployeeId = kevin.Id,
                TechId = burner.Id,
                ProblemId = badDrive.Id,
                Notes = "Kevin's drive is shot, Burner to fix it"
            };
            int newCallId = await cdao.Add(call);
            output.WriteLine("New Call Generated - Id = " + newCallId);
            call = await cdao.GetByID(newCallId);
            byte[] oldtimer = call.Timer!;
            output.WriteLine("New Call Retrieved");
            call.Notes += "\n Ordered new drive!";
            if (await cdao.Update(call) == UpdateStatus.Ok)
            {
                output.WriteLine("Call was updated " + call.Notes);
            }
            else
            {
                output.WriteLine("Call was not updated!");
            }
            call.Timer = oldtimer;
            call.Notes = "doesn't matter data is stale now";
            if (await cdao.Update(call) == UpdateStatus.Stale)
            {
                output.WriteLine("Call was not updated due to stale data");
            }
            cdao = new CallDAO();
            await cdao.GetByID(newCallId);
            if (await cdao.Delete(newCallId) == 1)
            {
                output.WriteLine("Call was deleted!");
            }
            else
            {
                output.WriteLine("Call was not deleted");
            }
            Assert.Null(await cdao.GetByID(newCallId));
        }

        [Fact]
        public async Task Call_ComprehensiveVMTest()
        {
            CallViewModel cvm = new();
            EmployeeViewModel evm = new();
            ProblemViewModel pvm = new();
            cvm.DateOpened = DateTime.Now;
            cvm.DateClosed = null;
            cvm.OpenStatus = true;
            evm.Email = "k_marquez150012@fanshaweonline.ca";
            await evm.GetByEmail();
            cvm.EmployeeId = Convert.ToInt16(evm.Id);
            evm.Email = "bb@abc.com";
            await evm.GetByEmail();
            cvm.TechId = Convert.ToInt16(evm.Id);
            pvm.Description = "Memory Upgrade";
            await pvm.GetByDescription();
            cvm.ProblemId = (int)pvm.Id!;
            cvm.Notes = "Kevin has bad RAM, Burner to fix it";
            await cvm.Add();
            output.WriteLine("New Call Generated - Id = " + cvm.Id);
            int id = cvm.Id; // need id for delete later
            await cvm.GetById();
            cvm.Notes += "\n Ordered new RAM!";
            if (await cvm.Update() == 1)
            {
                output.WriteLine("Call was updated " + cvm.Notes);
            }
            else
            {
                output.WriteLine("Call was not updated!");
            }
            cvm.Notes = "Another change to comments that should not work";
            if (await cvm.Update() == -2)
            {
                output.WriteLine("Call was not updated data was stale");
            }
            cvm = new CallViewModel
            {
                Id = id
            };
            // need to reset because of concurrency error
            await cvm.GetById();
            if (await cvm.Delete() == 1)
            {
                output.WriteLine("Call was deleted!");
            }
            else
            {
                output.WriteLine("Call was not deleted");
            }
            // should throw expected exception
            Task<NullReferenceException> ex = Assert.ThrowsAsync<NullReferenceException>(async ()
           => await cvm.GetById());
        }

    }
}