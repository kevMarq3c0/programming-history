﻿/*
 * Program: EmployeeController.cs
 * Purpose: This is a class that will handle HTTP requests and provide REST (Representational State Transfer) services which is used for
 *          desinging networked applications 
 * Coder: Kevin Marquez 
 * Date: October 26 2022
 */
using HelpdeskViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Reflection;

namespace CasestudyWebsite.Controllers
{
    //Route that will try to match the URI against the route templates in the table 
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        //The client is going to request data and it will pass along a variable called email
        [HttpGet("{email}")]
        //We are going to use email variable in the method 
        public async Task<IActionResult> GetByEmail(string email)
        {
            //IActionResult controller is controlling this instance to a JSON object, and sending it back
            try
            {
                //Set up a new viewmodel and set the value of the email equal to the email string variable 
                EmployeeViewModel viewmodel = new() { Email = email };
                await viewmodel.GetByEmail();
                //OK is going to send a 200, which means things worked 
                return Ok(viewmodel);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " +
                MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                //This will send a 500, which means something has gone wrong 
                return StatusCode(StatusCodes.Status500InternalServerError); // something went wrong
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById (int id)
        {
            try
            {
                EmployeeViewModel viewmodel = new() { Id = id};
                await viewmodel.GetById();
                return Ok(viewmodel);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " +
                MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                //This will send a 500, which means something has gone wrong 
                return StatusCode(StatusCodes.Status500InternalServerError); // something went wrong
            }
        }

        //PUT operation that will update a given EmployeeViewModel instance 
        [HttpPut]
        public async Task<ActionResult> Put(EmployeeViewModel viewModel)
        {
            try
            {
                int retVal = await viewModel.Update();
                //Use a switch in order to adapt JSON that will contain a property msg 
                return retVal switch
                {
                    1 => Ok(new { msg = "Employee " + viewModel.Lastname + " updated!" }),
                    -1 => Ok(new { msg = "Employee " + viewModel.Lastname + " not updated!" }),
                    -2 => Ok(new { msg = "Data is stale for " + viewModel.Lastname + ", Employee not updated" }),
                    _ => Ok(new { msg = "Employee " + viewModel.Lastname + " not updated!" }),
                };
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError); 
            }
        }

        //This GET method will faciltate concurrency to test if data is stale or if an update failed 
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                EmployeeViewModel viewModel = new();
                List<EmployeeViewModel> allEmployees = await viewModel.GetAll();
                return Ok(allEmployees);
            }
            catch(Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        //This POST method will take the parameter of an EmployeeViewModel object then add in another entry
        [HttpPost]
        public async Task<ActionResult> Post(EmployeeViewModel viewModel)
        {
            try
            {
                await viewModel.Add();
                //If the current Id of the viewModel after the add, if Id is greater than 1, the add was successful, else it failed 
                return viewModel.Id > 1
                    ? Ok(new { msg = "Employee " + viewModel.Lastname + " added!" })
                    : Ok(new { msg = "Employee " + viewModel.Lastname + " not added!" });
            }
            catch(Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        //This DELETE method will take an integer as the ID, then iterate through the EmployeeViewModel and delete the entry corresponding
        //to that id 
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                EmployeeViewModel viewModel = new() { Id = id };
                //If the delete was successful, then it returns 1, if not than a problem has occurred 
                return await viewModel.Delete() == 1
                    ? Ok(new { msg = "Employee " + id + " deleted!" })
                    : Ok(new { msg = "Employee " + id + " not deleted!" });
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
    }
}

