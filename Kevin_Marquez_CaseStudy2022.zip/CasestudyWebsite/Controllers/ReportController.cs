﻿/*
 * Program: ReportController.cs
 * Purpose: This class provides REST functions for HTTP requests to allow us to generate imgs and pdfs, specifically a report
 *          of Employees
 * Coder: Kevin Marquez 
 * Date: December 12 2022
 */
using Microsoft.AspNetCore.Mvc;
using CasestudyWebsite.Reports;
namespace CasestudyWebsite.Controllers
{
    public class ReportController : Controller
    {
        private readonly IWebHostEnvironment _env;
        public ReportController(IWebHostEnvironment env)
        {
            _env = env;
        }
        //This will generate and retrieve an EmployeeReport
        [Route("api/employeereport")]
        [HttpGet]
        public async Task<IActionResult> GetEmployeeReport()
        {
            EmployeeReport report = new();
            //Call the EmployeeReport function with the IWebHostEnvironment route of pdfs to send it to
            await report.GenerateReport(_env.WebRootPath);
            return Ok(new { msg = "Report Generated" });
        }

    }
}
