﻿/*
 * Program: ProblemController.cs
 * Purpose: This class provides REST functions for HTTP requests to have access to the ProblemDAO and ProblemViewModel Classes
 *          to retrieve and enact data on the application server 
 * Coder: Kevin Marquez 
 * Date: December 12 2022
 */
using HelpdeskViewModels;
using HelpDeskViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Reflection;

namespace CasestudyWebsite.Controllers
{
    //This will help us get the route necessary to access the Route templates
    [Route("api/[controller]")]
    [ApiController]
    public class ProblemController : ControllerBase
    {
        //This will get all Problem ids and their description
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                ProblemViewModel viewModel = new();
                List<ProblemViewModel> allProblems = await viewModel.GetAll();
                return Ok(allProblems);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " +
                MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
    }
}
