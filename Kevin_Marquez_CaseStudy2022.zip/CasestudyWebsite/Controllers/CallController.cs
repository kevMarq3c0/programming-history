﻿/*
 * Program: CallController.cs
 * Purpose: This class provides REST functions for HTTP requests to have access to the CallDAO and CallViewModel Classes
 *          to retrieve and enact data on the application server 
 * Coder: Kevin Marquez 
 * Date: December 12 2022
 */
using HelpdeskViewModels;
using HelpDeskViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Reflection;

namespace CasestudyWebsite.Controllers
{
    //Route that will try to match the URI against the route arguments and templates
    [Route("api/[controller]")]
    [ApiController]
    public class CallController : ControllerBase
    {
        //Find a Call based on its CallId
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            try
            {
                CallViewModel viewmodel = new() { Id = id };
                await viewmodel.GetById();
                return Ok(viewmodel);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " +
                MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                //This will send a 500, which means something has gone wrong 
                return StatusCode(StatusCodes.Status500InternalServerError); // something went wrong
            }
        }

        //Update a known CallViewModel
        [HttpPut]
        public async Task<ActionResult> Put(CallViewModel cvm)
        {
            try
            {
                //Check the result of the Update to see if it was successful or not, perhaps stale
                int returnVal = await cvm.Update();
                return returnVal switch 
                {
                    1 => Ok(new { msg = "Call " + cvm.Id + " updated!" }),
                    -1 => Ok(new { msg = "Call " + cvm.Id + " not updated!" }),
                    -2 => Ok(new { msg = "Data is stale for call " + cvm.Id + ", call not updated!" }),
                    _ => Ok(new { msg = "Call " + cvm.Id + " not updated!" }),
                };
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " +
                MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError); // something went wrong
            }
        }

        //Add a Call 
        [HttpPost]
        public async Task<ActionResult> Post(CallViewModel viewModel)
        {
            try
            {
                //Check if the add() was successful
                await viewModel.Add();
                return viewModel.Id > 1
                    ? Ok(new { msg = "Call " + viewModel.Id + " added!" })
                    : Ok(new { msg = "Call " + viewModel.Id + " not added!" });
            }
            catch(Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        //Get all the Calls and their information 
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                //Create a new CallViewModel
                CallViewModel viewModel = new();
                //Store in a list of CallViewModels
                List<CallViewModel> allCalls = await viewModel.GetAll();
                return Ok(allCalls);
            }
            catch (Exception ex) 
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        //This will delete a CallViewModel based on its id
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                CallViewModel viewModel = new() { Id = id };
                //Check the status of the delete
                return await viewModel.Delete() == 1
                    ? Ok(new { msg = "Call " + id + " deleted!" })
                    : Ok(new { msg = "Call " + id + " was not deleted!" });
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
    }
}
