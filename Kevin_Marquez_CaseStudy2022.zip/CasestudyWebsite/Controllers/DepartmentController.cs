﻿/*
 * Program: DepartmentController.cs
 * Purpose: This is a class that will handle HTTP requests and provide REST (Representational State Transfer) services which is used for
 *          desinging networked applications 
 * Coder: Kevin Marquez 
 * Date: October 26 2022
 */

using HelpdeskViewModels;
using HelpDeskViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Reflection;

namespace CasestudyWebsite.Controllers
{
    //Route that will try to match the URI against the route templates in the table 
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentController : ControllerBase
    {
        //This will return a list of all the registered Departments on the server as well as their details 
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                //Create a DepartmentViewmModel object and then fill a list of departments with GetAll method available in DepartmentViewModel
                DepartmentViewModel viewModel = new();
                List<DepartmentViewModel> allDepartments = await viewModel.GetAll();
                return Ok(allDepartments);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " +
                MethodBase.GetCurrentMethod()!.Name + " " + ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError); // something went wrong
            }
        }
    }
}
