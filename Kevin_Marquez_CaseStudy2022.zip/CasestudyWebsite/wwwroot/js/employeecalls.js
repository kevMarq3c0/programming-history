﻿$(() => {
    const getAll = async (msg) => {
        try {
            //Make a fetch to retrieve call data
            $("#callList").text("Finding Call Information...");
            let response = await fetch(`api/call`)
            if (response.ok) {
                let payload = await response.json();
                //If the response is ok, then send this data to the buildCallList to build the main list
                buildCallList(payload);
                msg == "" ?
                    $("#status").text("Calls Loaded") : $("#status").text(`${msg} - Calls Loaded`);
            } else if (response.status !== 404) {
                let problemJson = await response.json();
                errorRtn(problemJson, response.status);
            } else {
                $("#status").text("no such path on server");
            }
        }
        catch (error) {
            $("#status").text(error.message);
        }
    };

    const setupForUpdate = (id, data) => {
        $("#actionbutton").val("update");
        $("#modaltitle").html("<h4>update call</h4>");
        $('#deletealert').hide();
        $('#deleteprompt').show();
        //Be sure to show these rows as they are available for updates
        $("#DateclosedRow").show();
        $("#ClosecallRow").show();
        clearModalFields();
        data.forEach(call => {
            if (call.id === parseInt(id)) {
                //Make these calls if the call id is correct
                loadEmployeeDDL(call.employeeId);
                loadProblemsDDL(call.problemId);
                loadTechniciansDDL(call.techId);
                //Store them in sessionStorage to be accessible by other methods
                sessionStorage.setItem("id", call.id);
                sessionStorage.setItem("timer", call.timer);
                //Show and format the date
                $("#DateopenedText").text(formatDate(call.dateOpened).replace("T", " "));
                $("#TextBoxNotes").val(call.notes);
                $("modalstatus").text("update data");
                $("#myModal").modal("toggle");
                $("#myModalLabel").text("Update");
                //In case this has already been updated then disable action button and make entry readonly 
                if (!call.openStatus) {
                    $("#ddlProblems").attr('disabled', true);
                    $("#ddlEmployees").attr('disabled', true);
                    $("#ddlTechnicians").attr('disabled', true);
                    $("#DateclosedText").text(formatDate(call.dateClosed).replace("T", " "));
                    $("#checkBoxClose").prop('checked', true);
                    $("#TextBoxNotes").attr('readonly', true);
                    $("#actionbutton").hide();
                }
                else {
                    $("#actionbutton").show();
                }
            }
        })
    };

    const setupForAdd = () => {
        $("#actionbutton").val("add");
        $("#modaltitle").html("<h4>add employee</h4>");
        $("#theModal").modal("toggle");
        $("#modalstatus").text("add new call");
        $("#myModalLabel").text("Add");
        $("#actionbutton").show();
        //Hide these rows as they are only available for update
        $("#DateclosedRow").hide();
        $("#ClosecallRow").hide();
        $('#deletealert').hide();
        $('#deleteprompt').hide();
        clearModalFields();
    };

    const clearModalFields = () => {
        $("#TextBoxTitle").val("");
        $("#TextBoxFirstname").val("");
        $("#TextBoxLastname").val("");
        $("#TextBoxPhone").val("");
        //Show the date of the entry or currently and place it in sessionStorage formatted 
        $("#DateopenedText").text(formatDate().replace("T", " "));
        sessionStorage.setItem("dateOpened", formatDate());
        $("#TextBoxNotes").val("");
        sessionStorage.removeItem("id");
        sessionStorage.removeItem("departmentId");
        sessionStorage.removeItem("timer");
        sessionStorage.removeItem("picture");
        //This will reset the dropdown list of Employees, Problems and Technicians
        loadEmployeeDDL(-1);
        loadProblemsDDL(-1);
        loadTechniciansDDL(-1);
        $("#ddlProblems").attr('disabled', false);
        $("#ddlEmployees").attr('disabled', false);
        $("#ddlTechnicians").attr('disabled', false);
        $("#DateclosedText").text("");
        $("#checkBoxClose").prop('checked', false);
        $("#TextBoxNotes").attr('readonly', false);
        $("#myModal").modal("toggle");
        let validator = $("#EmployeeModalForm").validate();
        validator.resetForm();
    }; // clearModalFields

    const add = async () => {
        try {
            call = new Object();
            call.id = -1;
            //Retrieve the id of the choice in the dropdown lists
            call.employeeId = parseInt($("#ddlEmployees").val());
            call.problemId = parseInt($("#ddlProblems").val());
            call.techId = parseInt($("#ddlTechnicians").val());
            //Retrieve the current data formatted
            call.dateOpened = sessionStorage.getItem("dateOpened");
            call.dateClosed = null;
            //Set open status to true, open status only affected in update
            call.openStatus = true;
            call.notes = $("#TextBoxNotes").val();
            call.timer = null;
            let response = await fetch("api/call", {
                method: "POST",
                headers: { "Content-Type": "application/json; charset=utf-8"},
                body: JSON.stringify(call)
            });
            if (response.ok) {
                let data = await response.json();
                getAll(data.msg);
            } else if (response.status !== 404) {
                let problemJson = await response.json();
                errorRtn(problemJson, response.status);
            } else {
                $("#status").text("no such path on server")
            }
        }
        catch (error) {
            $("#status").text(error.message);
        }
        $("#myModal").modal("toggle");
    };

    const _delete = async () => {
        try {
            let response = await fetch(`api/call/${sessionStorage.getItem('id')}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json; charset=utf-8'}
            });
            if (response.ok) {
                let data = await response.json();
                getAll(data.msg);
            } else {
                $('#status').text(`Status - ${response.status}, Problem on delete server side, see server console`);
            }
            $('#myModal').modal('toggle');
        }
        catch (error) {
            $("#status").text(error.message);
        }
    }

    const update = async () => {
        try {
            call = new Object();
            call.id = parseInt(sessionStorage.getItem("id"));
            call.employeeId = parseInt($("#ddlEmployees").val());
            call.problemId = parseInt($("#ddlProblems").val());
            call.techId = parseInt($("#ddlTechnicians").val());
            //Retrieve date values from sessionStorage
            call.dateOpened = sessionStorage.getItem("dateOpened");
            call.dateClosed = sessionStorage.getItem("dateClosed");
            //Check if the checkbox is selected or not
            if ($("#checkBoxClose").is(":checked"))
                call.openStatus = false;
            else
                call.openStatus = true;
            call.notes = $("#TextBoxNotes").val();
            call.timer = sessionStorage.getItem("timer");
            let response = await fetch("api/call", {
                method: "PUT",
                headers: { "Content-Type": "application/json; charset=utf-8" },
                body: JSON.stringify(call)
            });
            if (response.ok) {
                let data = await response.json();
                getAll(data.msg);
            } else if (response.status !== 404) {
                let problemJson = await response.json();
                errorRtn(problemJson, response.status);
            } else {
                $("#status").text("no such path on server")
            }
        }
        catch (error) {
            $("#status").text(error.message);
        }
        $("myModal").modal("toggle");
    }
    $("#actionbutton").click(() => {
        //If the button value is an update, we will do an update, if it is not, then we will do an add
        $("#actionbutton").val() === "update" ? update() : add();
    });

    //Allows us to find the Employee in the calllist from the search bar
    $("#srch").keyup(() => {
        let alldata = JSON.parse(sessionStorage.getItem("allCalls"));
        let filtereddata = alldata.filter((call) => call.employeeName.match(new RegExp($("#srch").val(), 'i')));
        buildCallList(filtereddata, false);
    }); // srch keyup

    //This method will format the date and get rid of the T for all date in JavaScript 
    const formatDate = (date) => {
        let d;
        (date === undefined) ? d = new Date() : d = new Date(Date.parse(date));
        let _day = d.getDate();
        if (_day < 10) { _day = "0" + _day; }
        let _month = d.getMonth() + 1;
        if (_month < 10) { _month = "0" + _month; }
        let _year = d.getFullYear();
        let _hour = d.getHours();
        if (_hour < 10) { _hour = "0" + _hour; }
        let _min = d.getMinutes();
        if (_min < 10) { _min = "0" + _min; }
        return _year + "-" + _month + "-" + _day + "T" + _hour + ":" + _min;
    } // formatDate

    //This method will check if the checkbox has been selected, and then get the current data as date closed, and send it to sessionStorage
    $("#checkBoxClose").click(() => {
        if ($("#checkBoxClose").is(":checked")) {
            $("#DateclosedText").text(formatDate().replace("T", " "));
            sessionStorage.setItem("dateClosed", formatDate());
        } else {
            $("#DateclosedText").text("");
            sessionStorage.setItem("dateClosed", "");
        }
    }); // checkBoxClose
 
    //Allow for rows in the callList to be clicked on which will open a modal with the option to add or update pr delete
    $("#callList").click((e) => {
        if (!e) e = window.event;
        let id = e.target.parentNode.id;
        if (id === "callList" || id === "") {
            id = e.target.id;
        } // clicked on row somewhere else
        if (id !== "status" && id !== "heading") {
            let data = JSON.parse(sessionStorage.getItem("allCalls"));
            id === "0" ? setupForAdd() : setupForUpdate(id, data);
        } else {
            return false; // ignore if they clicked on heading or status
        }
    }); // callList click

    //Click event handler for the delete prompt and delete alert to allow the user to delete and confirm a delete
    $('#deleteprompt').click((e) => {
        $('#deletealert').show();
    });
    $('#deletenobutton').click((e) => {
        $('#deletealert').hide();
    });
    $('#deletebutton').click(() => {
        _delete();
    });

    //Dynamically build the callList with given data 
    const buildCallList = (data, usealldata = true) => {
        console.log("Build Start");
        $("#callList").empty();
        div = $(`<div class="list-group-item text-white bg-secondary row d-flex" id="status">Call Info</div>
                <div class= "list-group-item row d-flex text-center" id="heading">
                <div class="col-4 h4">Date</div>
                <div class="col-4 h4">For</div>
                <div class="col-4 h4">Problem</div>
                </div>`);
        div.appendTo($("#callList"));
        usealldata ? sessionStorage.setItem("allCalls", JSON.stringify(data)) : null;
        btn = $(`<button class="list-group-item row d-flex" id="0">...click to add call</button>`);
        btn.appendTo($("#callList"));
        data.forEach((call) => {
            btn = $(`<button class="list-group-item row d-flex" id="${call.id}">`);
            //Be sure to format the date, as directly from the Database, it will include a T
            btn.html(`<div class="col-4" id="callDate${call.id}">${(formatDate(call.dateOpened).replace("T", " "))}</div>
                      <div class="col-4" id="callEmpName${call.id}">${call.employeeName}</div>
                      <div class="col-4" id="callProblem${call.id}">${call.problemDescription}</div>`
            );
            btn.appendTo($("#callList"));
        }); // forEach
    }; // buildEmployeeList

    //Populate the HTML select with the employee options so when the modal opens, we can retrieve from a parsed JSON array than
    //build it with options for each employee option
    const loadEmployeeDDL = async (callemp) => {
        response = await fetch(`api/employee`);
        if (response.ok) {
            let allemployees = await response.json();
            sessionStorage.setItem("allEmployees", JSON.stringify(allemployees));
            html = '';
            $('#ddlEmployees').empty();
            allemployees.forEach((emp) => { html += `<option value="${emp.id}">${emp.firstname}</option>` });
            $('#ddlEmployees').append(html);
            $('#ddlEmployees').val(callemp);
        } else if (response.status !== 404) {
            let problemJson = await response.json();
            errorRtn(problemJson, response.status);
        } else {
            $("#status").text("no such path on server");
        }
    }

    //Populate the HTML select with the problem options so when the modal opens, we can retrieve from a parsed JSON array than
    //build it with options for each problem option
    const loadProblemsDDL = async (callproblem) => {
        response = await fetch(`api/problem`);
        if (response.ok) {
            let allproblems = await response.json();
            html = '';
            $('#ddlProblems').empty();
            allproblems.forEach((problem) => { html += `<option value="${problem.id}">${problem.description}</option>` });
            $('#ddlProblems').append(html);
            $('#ddlProblems').val(callproblem);
        } else if (response.status !== 404) {
            let problemJson = await response.json();
            errorRtn(problemJson, response.status);
        } else {
            $("#status").text("no such path on server");
        }
    }

    //Populate the HTML select with the technician options so when the modal opens, we can retrieve from a parsed JSON array than
    //build it with options for each technician option
    const loadTechniciansDDL = async (calltechnician) => {
        response = await fetch(`api/employee`);
        if (response.ok) {
            let alltechnicians = JSON.parse(sessionStorage.getItem("allEmployees"));
            html = '';
            $('#ddlTechnicians').empty();
            //Be sure to filter the employees so only those who are tech are shown
            alltechnicians.forEach(tech => {
                if (tech.isTech === true) {
                    html += `<option value="${tech.id}">${tech.firstname}</option>`
                }
            });
            $('#ddlTechnicians').append(html);
            $('#ddlTechnicians').val(calltechnician)
        } else if (response.status !== 404) {
            let problemJson = await response.json();
            errorRtn(problemJson, response.status);
        } else {
            $("#status").text("no such path on server");
        }
    }
    
    document.addEventListener("keyup", e => {
        $("#modalstatus").removeClass(); //remove any existing css on div
        if ($("#EmployeeModalForm").valid()) {
            $("#actionbutton").prop("disabled", false);
            $("#modalstatus").attr("class", "badge bg-success"); //green
            $("#modalstatus").text("data entered is valid");
        }
        else {
            $("#actionbutton").prop("disabled", true);
            $("#modalstatus").attr("class", "badge bg-danger"); //red
            $("#modalstatus").text("fix errors");
        }
    });

    //This grants us our validation rules
    $("#EmployeeModalForm").validate({
        rules: {
            ddlProblems: { required: true},
            ddlEmployees: { required: true },
            ddlTechnicians: { required: true },
            TextBoxNotes: { maxlength: 250, required: true }
        },
        errorElement: "div",
        messages: {
            ddlProblems: {
                required: "select Problem"
            },
            ddlEmployees: {
                required: "select Employee"
            },
            ddlTechnicians: {
                required: "select Tech"
            },
            TextBoxNotes: {
                required: "requires 1-250 chars.", maxlength: "required 1-250 chars."
            }
        }
    }); //EmployeeModalForm.validate
    
    
    getAll(""); // first grab the data from the server
}); // jQuery ready method

// server was reached but server had a problem with the call
const errorRtn = (problemJson, status) => {
    if (status > 499) {
        $("#status").text("Problem server side, see debug console");
    } else {
        let keys = Object.keys(problemJson.errors)
        problem = {
            status: status,
            statusText: problemJson.errors[keys[0]][0], // first error
        };
        $("#status").text("Problem client side, see browser console");
        console.log(problem);
    } // else
}
    