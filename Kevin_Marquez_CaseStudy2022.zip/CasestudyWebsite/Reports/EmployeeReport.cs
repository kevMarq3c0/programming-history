﻿/*
 * Program: EmployeeReport.cs
 * Purpose: This class helps us to create the details of a PDF being generated, including the size, its columns, and if it has a paper
 *          and the information that the pdf will store
 * Coder: Kevin Marquez 
 * Date: December 12 2022
 */
using iText.Kernel.Font;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using iText.IO.Font.Constants;
using iText.Layout.Properties;
using iText.Layout.Borders;
using iText.IO.Image;
using iText.Kernel.Geom;
using HelpdeskViewModels;

namespace CasestudyWebsite.Reports
{
    public class EmployeeReport
    {
        //This will dictate the font being used in the PDF
        readonly PdfFont helvetica = PdfFontFactory.CreateFont(StandardFontFamilies.HELVETICA);
        //This is the main method to be called in ReportController
        public async Task GenerateReport(string rootpath)
        {
            PageSize pg = PageSize.A4;
            //This will take a route in order to retrieve the image then specify its parameters and size
            Image img = new Image(ImageDataFactory.Create(rootpath + "/img/Helpdesk-Transparent-PNG.png"))
            .ScaleAbsolute(100, 100)
            .SetFixedPosition(((pg.GetWidth() - 100) / 2), 720);
            //This will generate the path where we create and send the newly sent pdf
            PdfWriter writer = new(rootpath + "/pdfs/employeelist.pdf",
            new WriterProperties().SetPdfVersion(PdfVersion.PDF_2_0));
            PdfDocument pdf = new(writer);
            Document document = new(pdf); // PageSize(595, 842)
            //This will specify the exact format of the pdf document by adding paragraphs
            document.Add(img);
            document.Add(new Paragraph("\n"));
            document.Add(new Paragraph("\n"));
            document.Add(new Paragraph("\n"));
            document.Add(new Paragraph("Current Employees")
            .SetFont(helvetica)
            .SetFontSize(24)
           .SetBold()
            .SetTextAlignment(TextAlignment.CENTER));
            //This will generate a three column table
            Table table = new(3);
            table
            .SetWidth(298) // roughly 50%
           .SetTextAlignment(TextAlignment.CENTER)
            .SetRelativePosition(0, 0, 0, 0)
           .SetHorizontalAlignment(HorizontalAlignment.CENTER);
            //This wil generate the cells in the table for us to give headers and help populate the values
            table.AddCell(AddCell("Title", "h", 0));
            table.AddCell(AddCell("Firstname", "h", 0));
            table.AddCell(AddCell("Lastname", "h", 0));
            table.AddCell(AddCell(" ", "d"));
            table.AddCell(AddCell(" ", "d"));
            table.AddCell(AddCell(" ", "d"));
            EmployeeViewModel employee = new();
            List<EmployeeViewModel> employees = await employee.GetAll();
            //A for loop that will generate the information about each column
            foreach (EmployeeViewModel emp in employees)
            {
                table.AddCell(AddCell(emp.Title!, "d", 8));
                table.AddCell(AddCell(emp.Firstname!, "d"));
                table.AddCell(AddCell(emp.Lastname!, "d"));
            }
            document.Add(table);
            document.Add(new Paragraph("\n"));
            document.Add(new Paragraph("\n"));
            document.Add(new Paragraph("Employee report written on - " + DateTime.Now)
            .SetFontSize(6)
            .SetTextAlignment(TextAlignment.CENTER));
            document.Close();
        }
        //This is a method only visible in this class that allows us to add cells to the table
        private static Cell AddCell(string data, string celltype, int padLeft = 16)
        {
            Cell cell;
            if (celltype == "h")
            {
                cell = new Cell().Add(
                new Paragraph(data)
               .SetFontSize(16)
               .SetTextAlignment(TextAlignment.LEFT)
               .SetBold()
               )
               .SetBorder(Border.NO_BORDER);
            }
            else
            {
                cell = new Cell().Add(
                new Paragraph(data)
               .SetFontSize(14)
               .SetTextAlignment(TextAlignment.LEFT)
                .SetPaddingLeft(padLeft)
                )
               .SetBorder(Border.NO_BORDER);
            }
            return cell;
        }
    }
}


