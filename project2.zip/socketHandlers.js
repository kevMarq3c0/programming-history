import matColours from "./matdes100colours.json" assert {type: "json"};
import moment from "moment";

const reservedUserNames = ["Admin"];
const adminColorIndex = matColours.colours.length - 14;
const rooms = ["main"];
const reservedColourIndexes = [];
const clientRooms = [];

const handleJoin = async (socket, client) => {
    if(reservedUserNames.includes(client.name))
    {
        socket.emit(
            "nameexists",
            `name already taken, try a different name`
        );
    }
    else
    {
        socket.name = client.name;
        socket.join(client.room);
        console.log(`${socket.name} has joined ${client.room}`);

        let msg = {text: `${reservedUserNames[0]} Says:\nRoom: ${client.room} @ ${moment().format('h:mm:ss a')}\nWelcome ${socket.name}`, color: matColours.colours[adminColorIndex], sender: reservedUserNames[0]}

        socket.emit(
            "welcome",
            msg
        );

        msg.text = `${reservedUserNames[0]} Says:\nRoom: ${client.room} @ ${moment().format('h:mm:ss a')}\nWelcome ${socket.name} has joined the ${client.room} room`
        socket
            .to(client.room)
            .emit("someonejoined", msg);

        reservedUserNames.push(socket.name);
        clientRooms.push({name: socket.name, room: client.room});
        if(!rooms.includes(client.room))
        {
            rooms.push(client.room);
        }
    }
};

const handleDisconnect = async (socket) => {
    const clientLeavingRoom = clientRooms.find((room) => room.name === socket.name);
    if(clientLeavingRoom)
    {
        let msg = {text: `${reservedUserNames[0]} Says:\nRoom: ${clientLeavingRoom.room} @ ${moment().format('h:mm:ss a')}\n${socket.name} has left room ${clientLeavingRoom.room}`, color: matColours.colours[adminColorIndex], sender: reservedUserNames[0]};
        socket
        .to(clientLeavingRoom.room)
        .emit("someoneleft", msg);

        console.log(`${socket.name} has left room ${clientLeavingRoom.room}`);
        const indexOfRemoval = reservedUserNames.indexOf(socket.name);

        const indexClientRemoval = clientRooms.indexOf((client) => {
            return client.name === socket.name;
        });

        reservedUserNames.splice(indexOfRemoval, 1);
        clientRooms.splice(indexClientRemoval, 1);
    }
};

const handleTyping = async (socket, client) => {
    const clientRoom = clientRooms.find((room) => room.name === client.from);
    const currentClient = reservedColourIndexes.find((color) => color.name === client.from);
    let currentColourIndex;
    if(currentClient)
    {
        currentColourIndex = currentClient.colour;
    }
    else
    {
        currentColourIndex = Math.floor(Math.random() * matColours.colours.length) + 1;
        reservedColourIndexes.push({name: client.from, colour: currentColourIndex});
    }
    const msg = {from: client.from, text: `${client.from} is typing`, color: matColours.colours[currentColourIndex]};
    socket
        .to(clientRoom.room)
        .emit("someoneistyping", msg);
};

const handleMessage = async (io, socket, client) => {
    const currentClient = reservedColourIndexes.find((color) => color.name === client.from);
    const clientRoom = clientRooms.find((room) => room.name === client.from);
    let currentColourIndex;
    if(currentClient)
    {
        currentColourIndex = currentClient.colour;
    }
    else
    {
        currentColourIndex = Math.floor(Math.random() * matColours.colours.length) + 1;
        reservedColourIndexes.push({name: client.from, colour: currentColourIndex});
    }
    
    const msg = { text: `${client.from} Says:\nRoom: ${clientRoom.room} @ ${moment().format('h:mm:ss a')}\n${client.text}`, color: matColours.colours[currentColourIndex], sender: client.from};
    io.in(clientRoom.room).emit("newmessage", msg);
};

const handleGetRoomsAndUsers = async(io) => {
    let clientDialogMsgs = [];
    let roomToCheck;
    for(let clientRoom of clientRooms)
    {
        if(clientRoom.room !== roomToCheck || roomToCheck === undefined)
        {
            const clientsInRoom = clientRooms.filter(client => client.room === clientRoom.room);
            for(let client of clientsInRoom)
            {
                const currentClient = reservedColourIndexes.find((color) => color.name === client.name);
                let currentColourIndex;
                if(currentClient)
                {
                    currentColourIndex = currentClient.colour;
                }
                else
                {
                    currentColourIndex = Math.floor(Math.random() * matColours.colours.length) + 1;
                    reservedColourIndexes.push({name: client.name, colour: currentColourIndex});
                }
                let msg = `${client.name} is in room ${clientRoom.room}`;
                clientDialogMsgs.push({message: msg, color: matColours.colours[currentColourIndex]});
            }
            roomToCheck = clientRoom.room;
        }
    }

    io.emit("whoison", clientDialogMsgs);
};

const handleRoomCheck = async(io) => {
    io.emit("rooms", rooms);
};

export { handleJoin, handleDisconnect, handleTyping, handleMessage, handleGetRoomsAndUsers, handleRoomCheck };