import { useState, useEffect, useRef } from "react";
import { ListItem } from "@mui/material";
import Bubble from "./bubble";
import Triangle from "./triangle";

const UserMessage = (props) => {
    const userRef = useRef(null);
    const [textAlign, setTextAlign] = useState();
    const [bubbleTextAlign, setBubbleTextAlign] = useState();

    useEffect(() => {
        userRef.current.scrollIntoView(true);
        if(props.msg.sender === props.clientName)
        {
            setTextAlign("15em");
            setBubbleTextAlign("flex-end");
        }
        else
        {
            setTextAlign("2em");
            setBubbleTextAlign("start");
        }
    }, []);

    return (
        <div>
            <ListItem
                ref={userRef}
                style={{ textAlign: "left", marginBottom: "2vh", justifyContent: bubbleTextAlign }}
            >
                <Bubble text={props.msg.text} color={props.msg.color} />
                <Triangle color={props.msg.color} alignTriangle={textAlign}/>
            </ListItem>
            <p></p>
        </div>
    );
};

export default UserMessage;
