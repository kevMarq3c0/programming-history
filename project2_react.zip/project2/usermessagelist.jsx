import { List } from "@mui/material";
import UserMessage from "./usermessage";

const UserMessageList = (props) => {
    let messages = props.messages.map((message, index) => {
        return <UserMessage msg={message} key={index} clientName={props.clientName}/>   
    });

    return <List>{messages}</List>;
};

export default UserMessageList;