import React, {useReducer, useEffect, useRef, useState} from "react";
import ForumIcon from '@mui/icons-material/Forum';
import AccountBoxIcon from '@mui/icons-material/AccountBox';
import { ThemeProvider } from "@emotion/react";
import {   
    AppBar,
    Button,
    Card,
    CardHeader,
    CardContent,
    Dialog,
    DialogTitle,
    DialogContent,
    Radio,
    RadioGroup,
    FormControlLabel,
    FormControl,
    FormLabel,
    Snackbar,
    TextField,
    Typography,
    Toolbar
} from "@mui/material";
import io from "socket.io-client";
import TopBar from "./topbar";
import UserMessageList from "./usermessagelist";
import theme from "./theme";
import "../App.css";

const ChatRooms = () => {
    const initialState = {
        showMsg: false,
        snackbarMsg: "",
        validName: true,
        showjoinfields: true,
        messages: [],
        status: "",
        chatName: "",
        roomName: "",
        roomMsg: "",
        clientsOnline: [],
        rooms: [],
        isTyping: false,
        typingMsg: "",
        typingColor: "",
        message: "",
        radioChoice: "",
    };

    const reducer = (state, newState) => ({...state, ...newState});
    const [state, setState] = useReducer(reducer, initialState);
    const effectRan = useRef(false);

    const [open, setOpen] = useState(false);
    const handleOpenDialog = () => setOpen(true);
    const handleCloseDialog = () => setOpen(false);

    useEffect(() => {
        if(effectRan.current) return;
        serverConnect();
        effectRan.current = true;
    }, []);

    const handleJoin = () => {
        state.socket.io._readyState !== "closed"
        ? joinServer()
        : setState({
            snackbarMsg: "can't get connection - try later!",
            showMsg: true,
        });
    };

    const serverConnect = () => {
        try {
            /*
            const socket = io.connect("localhost:5000", {
                forceNew: true,
                transports: ["websocket"],
                autoConnect: true,
                reconnection: false,
                timeout: 5000,
            });
            */
            // Connect to server
            const socket = io.connect();
            
            setState({socket: socket});
            socket.emit("checkrooms", {}, err => {});
            socket.on("rooms", updateRooms);
        } catch (err) {
            console.log(err);
            setState({
                showMsg: true,
                snackbarMsg: "some other problem occurred"
            });
        }
    };

    const joinServer = () => {
        state.socket.emit("join", {name: state.chatName, room: state.roomName}, (err) => {});
        state.socket.on("nameexists", onExists);
        state.socket.on("welcome", addMessageToList);
        state.socket.on("someonejoined", addMessageToList);
        state.socket.on("someoneleft", addMessageToList);
        state.socket.on("someoneistyping", onTyping);
        state.socket.on("newmessage", onNewMessage);
        state.socket.on("whoison", updateDialog);
    };

    const updateRooms = (newRooms) => {
        setState({
            rooms: newRooms
        });
    };

    const addMessageToList = (msg) => {
        if(state.validName)
        {
            let messages = state.messages;
            messages.push(msg);
            setState({
                messages: messages,
                showjoinfields: false,
            });
        } else {
            setState({
                validName: true
            });
        }
    };

    const onExists = (msg) => {
        setState({
            validName: false,
            status: msg
        });
    };

    const onTyping = (msg) => {
        if(msg.from !== state.chatName)
        {
            setState({
                typingMsg: msg.text,
                typingColor: msg.color
            });
        }
    };

    const onNewMessage = (msg) => {
        addMessageToList(msg);
        setState({typingMsg: ""});
    };

    const updateDialog = (clientRooms) => {
        setState({
            clientsOnline: clientRooms
        });
    };

    const snackbarClose = () => {
        setState({showMsg: false});
    };

    const onNameChange = (e) => {
        setState({chatName: e.target.value, status: ""});
    };

    const handleRoomInput = (e) => {
        setState({roomName: e.target.value});
    };

    const onMessageChange = (e) => {
        setState({message: e.target.value});
        if(state.isTyping === false) {
            state.socket.emit("typing", {from: state.chatName}, err => {});
            setState({ isTyping: true });
        }
    };

    const handleSendMessage = (e) => {
        if(state.message !== "") {
            state.socket.emit("message",
            {from: state.chatName, text: state.message},
            err => {}
            );
            setState({isTyping: false, message: ""});
        }
    };

    const handleChange = (e) => {
        setState({
            roomName: e.target.value,
            radioChoice: e.target.value
        });
    }

    const emptyorundefined = 
        state.chatName === undefined ||
        state.chatName === "" ||
        state.roomName === undefined ||
        state.roomName === "";

    return (
        <ThemeProvider theme={theme}>
            {!state.showjoinfields ? (
                <TopBar viewDialog={handleOpenDialog}/>
            ) : (
                <AppBar>
                    <Toolbar color="primary">
                        <Typography variant="h6" color="inherit">
                            Chat it up! - Info 3139
                        </Typography>
                    </Toolbar>
                </AppBar>
            )}

            {!state.showjoinfields ? (
                <Dialog open={open} onClose={handleCloseDialog} style={{margin: 20}}>
                    <DialogTitle style={{textAlign: "center"}}>
                        Who's On?
                    </DialogTitle>
                    <DialogContent>
                        {state.clientsOnline.map((status, index) => {
                            return <p key={index}><AccountBoxIcon style={{color: status.color}} fontSize="small"/>&nbsp;{status.message}</p>
                        })}
                    </DialogContent>
                </Dialog>
            ) : null}

            <Card className="card">
                {state.showjoinfields ? (
                    <CardContent>
                        <Typography
                            variant="h5"
                            color="inherit"
                            style={{textAlign: "center"}}
                        >
                            <ForumIcon className="svg_icons"/>

                            <p>Sign In</p>
                        </Typography>

                        <TextField
                            onChange={onNameChange}
                            placeholder="Enter user's name here"
                            autoFocus={true}
                            required
                            value={state.chatName}
                            error={state.status !== ""}
                            helperText={state.status}
                        />
                        <p></p>
                        <FormControl>
                            <FormLabel id="demo-radio-buttons-group-label">Join Existing or Enter Room Name</FormLabel>
                            <RadioGroup
                                aria-labelledby="demo-radio-buttons-group-label"
                                name="radio-buttons-group"
                                value={state.radioChoice}
                                onChange={handleChange}
                            >

                                {state.rooms.map((room, index) => {
                                    return <FormControlLabel value={room} control={<Radio />} label={room} key={index}/>
                                })}

                                <TextField
                                    onChange={handleRoomInput}
                                    placeholder="Enter room to join"
                                    autoFocus={true}
                                    required
                                    value={state.roomName}
                                    error={state.status !== ""}
                                />
                            </RadioGroup>
                        </FormControl>

                        <p></p>
                        <Button
                            color="secondary"
                            data-testid="submit"
                            style={{justifyContent: "center", alignItems: "center"}}
                            onClick={() => handleJoin()}
                            variant="contained"
                            disabled={emptyorundefined}
                        >
                            Join
                        </Button>
                    </CardContent>
                ) : null}

                {!state.showjoinfields ? (
                    <CardContent>
                        <UserMessageList messages={state.messages} clientName={state.chatName}/>
                        
                        <TextField
                            onChange={onMessageChange}
                            placeholder="type something here"
                            autoFocus={true}
                            value={state.message}
                                onKeyUp={(e) => {
                                    if(e.key === "Enter") {
                                        handleSendMessage();
                                        e.target.blur();
                                    }
                                }}
                            required
                        />
                        <p></p>
                        <div className="typingBubble">
                            <Typography color={state.typingColor}>
                                {state.typingMsg}
                            </Typography>
                        </div>
                    </CardContent>
                ) : null}
            </Card>
            <Snackbar
                open={state.showMsg}
                message={state.snackbarMsg}
                autoHideDuration={4000}
                onClose={snackbarClose}
            />
        </ThemeProvider>
    )
};

export default ChatRooms;