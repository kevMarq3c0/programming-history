import "../App.css";
const Bubble = (props) => {
    return (
    <div className="userBubble" style={{ backgroundColor: props.color }}>
        {props.text.split('\n').map((line, index) => (
            (index === 2) ? (
                <p key={index}><b>{line}</b></p>
            ) : (
                <p key={index}><small>{line}</small></p>
            )
        ))}
    </div>
    );
};

export default Bubble;