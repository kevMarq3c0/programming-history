/*!	\file		txt2conversion.h
*	\author		Kevin Marquez
*	\date		2022-03-28
* 
*	Header file meant to hold the names of methods used to convert txt files to html files called in the main body
*/

#pragma once
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <string>
using namespace std;

string switchCheck(int iArgc, int argc, char* argv[]);
string convertfilename(int iArgc, int argc, char* argv[], string option);
void printOutputFile(istream& inputfile, ostream& outfile, string outputfilename, size_t position, string option);
