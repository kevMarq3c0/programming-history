/*!	\file		txt2conversion.cpp
*	\author		Kevin Marquez
*	\date		2022-03-28
* 
*	Body of the header file to define the function methods that will be called in the main body code
*/

#include "txt2conversion.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <string>
using namespace std;

// Bool method with inline to check if the string that was called is a match or is greater/less than the second string
inline bool str_equal(const char* lhs, const char* rhs) { return strcmp(lhs, rhs) == 0; }
inline bool str_not_equal(const char* lhs, const char* rhs) { return strcmp(lhs, rhs) != 0; }
inline bool str_greater(const char* lhs, const char* rhs) { return strcmp(lhs, rhs) > 0; }
inline bool str_greater_equal(const char* lhs, const char* rhs) { return strcmp(lhs, rhs) >= 0; }
inline bool str_less(const char* lhs, const char* rhs) { return strcmp(lhs, rhs) < 0; }
inline bool str_less_equal(const char* lhs, const char* rhs) { return strcmp(lhs, rhs) <= 0; }

// String method that checks for the switch in command arguments and returns a string based on what switch letter was found, or if any were
string switchCheck(int iArgc, int argc, char* argv[])
{
	// Declare an option to hold data to return as a string
	string option;

	// Check if the argument is present and if it is a switch
	if (iArgc < argc && argv[iArgc][0] == '-') {

		// Check which switch was chosen from the second character
		switch (argv[iArgc][1]) {
		case 'r':
			if (str_equal(argv[iArgc], "-rp"))
			{
				option = "REPORT+P";
				break;
			}
			else
			{
				option = "REPORT";
				break;
			}
		case 'p':
			if (str_equal(argv[iArgc], "-pr"))
			{
				option = "REPORT+P";
				break;
			}
			else
			{
				option = "Paragraph";
				break;
			}
		case '-': if (str_equal(argv[iArgc], "--help")) option = "HELP"; break;
		default:
			cerr << "Error: unknown line switch \"" << argv[iArgc] << "\"" << endl;
			option = "failure";
			break;
		}
	}
	else
	{
		//If no switch was selected and there was just a filename
		option = "N/A";
	}

	// Return the string data
	return option;
}

// String method that will convert the file name and returns a string which is the file with file extension
string convertfilename(int iArgc, int argc, char* argv[], string option)
{
	string outputfilename;
	size_t position;

	// If there are still more arguments in the command line
	if (iArgc < argc)
	{
		// Hold the file name that the user specified
		outputfilename = argv[iArgc];
	}
	else
	{
		string infileName;
		// If a switch was chosen, accept the second argument as the filename, else take the first argument
		if (option != "N/A")
			infileName = argv[2];
		else
			infileName = argv[1];

		// Find the position of the dot to change file extension
		position = infileName.find_last_of('.');

		outputfilename = infileName;
		// Change the file extension from .txt to .html
		outputfilename.replace(position, 4, ".html");
	}
	// Return the output file name
	return outputfilename;
}

// A void method that outputs the contents of the inputfile and its conversions to the html file
void printOutputFile(istream& inputfile, ostream& outfile, string outputfilename, size_t position, string option)
{
	// Declare control variables, as well as counter variables
	string line;
	int lineCount = 0;
	int newSpace = 0;
	int paragraphOutput = 0;

	// Get the name of the file without its file extension 
	string fileName = outputfilename.substr(0, position);

	// Output the conversions of html tags to the output file
	outfile << "<!DOCTYPE html>\n";
	outfile << "<html>\n";

	outfile << "<head>\n";
	outfile << "<title>" << fileName << "</title>\n";

	outfile << "</head>\n";
	outfile << "<body>\n";

	// While loop to read all the lines till the end of the file
	while (getline(inputfile, line))
	{
		// Count each line to keep track of the # of line input
		lineCount++;

		// Check if the switch asks for paragraph <p> tags, and if not have all newspaces be <br>
		if (option == "Paragraph" || option == "REPORT+P")
		{
			if (!line.empty())
			{
				// If the control is 0, and there is text it will start a new paragraph
				if (newSpace == 0)
					outfile << "<p>\n";

				// Add the line to the output within the output
				outfile << line << "\n";
				// Change control to 1, so that <p> isn't called before each line with text till an empty space to close 
				newSpace = 1;
			}
			else
			{
				// If the control is 1, it means that a paragraph hasn't been closed, so it will close the paragraph
				if (newSpace == 1) {
					outfile << "</p>\n";
					//Increment the paragraph output in case 'r' was chosen
					paragraphOutput++;
				}
				// If there is no paragraph left open, but still an empty line, add <br>
				else
					outfile << "<br>\n";
				//Change control back to 0 so a paragraph can be opened again for new text
				newSpace = 0;
			}
		}
		else
		{
			if (!line.empty())
			{
				// Add line and be sure to make control become 0 
				outfile << line << "\n";
				newSpace = 0;
			}
			else
			{
				// If the control is 0, that means there is an extra space needed, so an additional <br> is added
				if (newSpace == 0)
				{
					outfile << "<br>\n";
				}
				outfile << "<br>\n";

				// Return newSpace to 0 to show that an extra space isn't needed
				newSpace = 1;
			}
		}
	}
	// Add closing html tags
	outfile << "</body>\n";
	outfile << "</html>";

	// If the user has chosen 'r' or 'rp' or 'pr', report the conversion metrics
	if (option == "REPORT" || option == "REPORT+P")
	{
		cout << "# line input: " << lineCount << endl;
		cout << "# paragraphs output: " << paragraphOutput << endl;
	}
}