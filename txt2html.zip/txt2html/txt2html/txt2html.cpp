#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <string>
#include "txt2conversion.h"
using namespace std;

int main(int argc, char* argv[])
{
	// Create a variable to show which argument we are on in the command line
	int iArgc = 1;
	string option;

	// Check for switch 
	option = switchCheck(iArgc, argc, argv);
	
	// If the option returns "failure", then cause exit failure, and increment iArgc if there was a switch found
	if (option == "failure")
		return EXIT_FAILURE;
	else if (option != "N/A")
		++iArgc;

	// Get the file name specified in command line
	char* filename = NULL;
	if (iArgc < argc) {
		filename = argv[iArgc];
		++iArgc;
	}

	// Check if help was chosen
	if (option == "HELP") {
		cout << "txt2html v3.0.1, (c) 2010-2022, Designed by Garth Santor, Made by Kevin Marquez" << "\n" <<
			"\n\t--help\tdisplay the help text for the program" <<
			"\n\t-r\treport convertion metrics" <<
			"\n\t-p\tuse <p> tag for paragraph breaks" <<
			"\n\n\ttextFilename\tthe name of the ASCII text file to process" <<
			"\n\thtmlFilename\tthe name of the HTML file receiving the output." <<
			"\n\t\t\tIf not provided the text filename will be used" <<
			"\n\t\t\twith its extension changed to \".html\"\n" << endl; 
		return EXIT_SUCCESS;
	}

	// Assign the filename to ifstream and see if the file exists
	ifstream infile(filename);
	if (!infile)
	{
		cerr << "Error: text filename \"" << filename << "\" --> No such file or directory\n";
		return EXIT_FAILURE;
	}
	else
	{
		// Get the outputfilename, make it the same name as input with .html if no filename is specified
		string outputfilename = convertfilename(iArgc, argc, argv, option);
		// Get the position of the . as file extension 
		size_t position = outputfilename.find_last_of('.');

		// Assign outputfilename to ofstream to see if it can be opened 
		ofstream outfile(outputfilename);
		if (!outfile)
		{
			cout << "Output file opening failed.\n";
			return EXIT_FAILURE;
		}
		else
		{
			// If output file opened successfully, print out the contents of input to output with html conversions
			printOutputFile(infile, outfile, outputfilename, position, option);

			// Close output file
			outfile.close();
		}
		// Close input file
		infile.close();
		return EXIT_SUCCESS;
	}
}