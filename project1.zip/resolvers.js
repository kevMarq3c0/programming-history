import * as alertResults from "./project1_setup.js";
import * as dbRtns from "./db_routines.js";
import * as cfg from "./config.js";

const resolvers = {
    project1_setup: async () => {
        return await alertResults.loadAlerts();
    },
    alerts: async() => {
        let db = await dbRtns.getDBInstance();
        return await dbRtns.findAll(db, cfg.alerts, {}, {});
    },
    alertsforregion: async(args) => {
        let db = await dbRtns.getDBInstance();
        return await dbRtns.findAll(db, cfg.alerts, {region: args.region}, {});
    },
    alertsforsubregion: async(args) => {
        let db = await dbRtns.getDBInstance();
        return await dbRtns.findAll(db, cfg.alerts, {subregion: args.subregion}, {});
    },
    regions: async() => {
        let db = await dbRtns.getDBInstance();
        return await dbRtns.findUniqueValues(db, cfg.alerts, "region");
    },
    subregions: async() => {
        let db = await dbRtns.getDBInstance();
        return await dbRtns.findUniqueValues(db, cfg.alerts, "subregion"); 
    },
    advisories: async() => {
        let db = await dbRtns.getDBInstance();
        return await dbRtns.findAll(db, cfg.advisories, {}, {});
    },
    addadvisory: async args => {
        let db = await dbRtns.getDBInstance();
        let advisory = {name: args.name, country: args.country, text: args.text, date: args.date };
        let results = await dbRtns.addOne(db, cfg.advisories, advisory);
        return results.acknowledged ? advisory : null;
    },
    advisoriesforname: async args => {
        let db = await dbRtns.getDBInstance();
        return await dbRtns.findAll(db, cfg.advisories, {name: args.name}, {});
    }
};

export { resolvers };
