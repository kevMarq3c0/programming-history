import { config } from "dotenv";
config();
export const rawisodata = process.env.ISOCOUNTRIES;
export const traveldata = process.env.GOCALERTS;
export const alerts = process.env.ALERTCOLLECTION;
export const advisories = process.env.ADVISORYCOLLECTION;
export const atlas = process.env.DBURL;
export const appdb = process.env.DB;
export const port = process.env.PORT;