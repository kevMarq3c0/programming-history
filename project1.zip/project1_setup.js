import * as cfg from "./config.js";
import * as utlLib from "./utilities.js";
import * as dbRtns from "./db_routines.js";

const loadAlerts = async () => {
    let results = "";
    try {
        const db = await dbRtns.getDBInstance();

        let dBResults = await dbRtns.deleteAll(db, cfg.alerts);
        
        results += `deleted ${dBResults.deletedCount} documents from ${cfg.alerts} collection. `;
        
        let alertJson = await utlLib.getJSONFromWWWPromise(cfg.traveldata);
        results += "Retrieved Alert JSON from remote web site. ";

        let countries = [];
        let countryJSONData = await utlLib.getJSONFromWWWPromise(cfg.rawisodata);

        countryJSONData.forEach((countryElement) => (countries.push(countryElement)));
        results += "Retrieved Country JSON from GitHub. ";
        
        let alertObjArray = countryJSONData.map((countryJSON) => {
            for(var code in alertJson.data)
            {
                if(code === countryJSON["alpha-2"])
                {
                    const alertCountryObj = {country: countryJSON["alpha-2"], 
                                            name: countryJSON.name, 
                                            text: alertJson.data[code].eng["advisory-text"],
                                            date: alertJson.data[code]["date-published"].date,
                                            region: countryJSON.region,
                                            subregion: countryJSON["sub-region"]};
                    return alertCountryObj;
                }
            }
            const nonAlertCountryObj = {country: countryJSON["alpha-2"], 
                                        name: countryJSON.name, 
                                        text: "No travel alerts",
                                        date: "",
                                        region: countryJSON.region,
                                        subregion: countryJSON["sub-region"]};
            return nonAlertCountryObj;
        });

        let addResults = await dbRtns.addMany(db, cfg.alerts, alertObjArray);
        results += `Added ${addResults.insertedCount} documents to the ${cfg.alerts} collection`;
    }
    catch (err) {
        console.log(err);
    } finally {
        return { results: results }
    }
};

export { loadAlerts };