﻿/*
 * Program: Employee.cs
 * Date: 2024-03-09
 * Author: Kevin Marquez #1054838
 * Purpose: This is a non-generic class that represents an Employee working in a software company that is going through an income tax audit by an external accountant. It holds all personal data on the employee, such as ID, name and payroll data
 *          to help calculate their payroll details for the tax season and provides methods to save this data and print it to the console.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise4_KM
{
    public class Employee
    {
        //The public properties that represent an employee's personal information and payroll data with some properties having a default value
        public int EmpID { get; set; }
        public string Name { get; set; }
        public double Salary { get; set; } = 1000;
        public double Bonus { get; set; } = 0;
        public double Tax { get; set; } = 0;
        public double NetIncome { get; set; } 
        public int Year { get; set; }

        //A constructor which will instantiate the EmpID, name, salary and bonus of an Employee
        public Employee(int id, string name, double salary, double bonus)
        {
            EmpID = id;
            Name = name;
            Salary = salary;
            Bonus = bonus;
        }

        /*
        * Method Name: UpdatePayroll
        * Purpose: This method will save the returning values of the tax, net income and tax year properties that are calculated by the Iterator method
        * Accepts: Two doubles and an int
        * Returns: Nothing
        */
        public void UpdatePayroll(double tax, double netIncome, int year)
        {
            Tax = tax;
            NetIncome = netIncome;
            Year = year;
        }

        /*
        * Method Name: ToString
        * Purpose: An override of the function ToString() which will return values of the Employee's member fields including name, id and payroll calculated fields
        * Accepts: Nothing 
        * Returns: A formatted string that includes the Employee's name, id, net income, tax values and the tax year
        */
        public override string ToString()
        {
            return $"The calculated net income and tax of the Employee {Name} with ID {EmpID} is ({NetIncome}, {Tax}) for the year {Year}\n";
        }
    }
}
