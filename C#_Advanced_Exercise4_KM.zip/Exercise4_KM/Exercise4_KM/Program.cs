﻿/*
 * Program: Program.cs
 * Date: 2024-03-09
 * Author: Kevin Marquez #1054838
 * Purpose: This is the main method of the Exercise where we will create our Employees to populate a List of Employees through user input and calculate and update their individual payroll properties after tax using an Iterator method 
 *          called CalculateTax. Two lists will be made after calculating the payroll of each Employee, one which will display all employees whose net income is larger than 10K and all employees sorted by their tax value.
 */

using System.Collections;

namespace Exercise4_KM
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Declare a generic list of employees that we will populate through end-user inputs
            List<Employee> employees = new List<Employee>();
            int numOfEmployees;
            string userInput;
            bool validInput;
            Console.WriteLine("---Tax Season Accounting for a Software Company---\n");
            
            //Prompt the user to enter the number of employees whose payroll will be calculated and keep prompting if invalid input is provided
            do
            {
                Console.Write("Enter the number of employees you wish to calculate: ");
                userInput = Console.ReadLine() ?? "";
                validInput = Int32.TryParse(userInput, out numOfEmployees);
                if(!validInput)
                {
                    Console.WriteLine($"Error: {userInput} is not a number.\n");
                }
            } while (!validInput);

            //Use a forloop to set each employees until the user has created the specified number of employees they provided in the earlier prompt
            for(int i = 0; i < numOfEmployees; i++)
            {
                int employeeId;
                double employeeSalary, employeeBonus;
                //Prompt the user for the ID of the employee and keep prompting until valid input is provided
                do
                {
                    Console.Write("Enter the ID for the employee: ");
                    userInput = Console.ReadLine() ?? "";
                    validInput = Int32.TryParse(userInput, out employeeId);
                    if(!validInput)
                    {
                        Console.WriteLine($"Error: {userInput} is not a valid ID. Enter only numbers for ID.\n");
                    }
                } while (!validInput);

                Console.Write("Enter the name for the employee: ");
                string employeeName = Console.ReadLine() ?? "";

                //Prompt the user for the salary of the employee and keep prompting until valid input is provided
                do
                {
                    Console.Write("Enter the salary for the employee: ");
                    userInput = Console.ReadLine() ?? "";
                    validInput = Double.TryParse(userInput, out employeeSalary);
                    if (!validInput)
                    {
                        Console.WriteLine($"Error: {userInput} is not a valid salary.\n");
                    }
                } while (!validInput);

                //Prompt the user for the bonus of the employee and keep prompting until valid input is provided
                do
                {
                    Console.Write("Enter the bonus for the employee: ");
                    userInput = Console.ReadLine() ?? "";
                    validInput = Double.TryParse(userInput, out employeeBonus);
                    if (!validInput)
                    {
                        Console.WriteLine($"Error: {userInput} is not a valid bonus.\n");
                    }
                } while (!validInput);

                //Once all values have been satisifed, declare a new employee and set its properties with the user-inputted values and add to the generic list
                employees.Add(new Employee(employeeId, employeeName, employeeSalary, employeeBonus));
                Console.WriteLine();
            }

            Console.WriteLine();

            //Declare an IEnumerator for us to iterate through the list of employees using a cursor
            IEnumerator employeeEnumerator = employees.GetEnumerator();

            //Iterate through the list of employees using the Iterator method CalculateTax to obtain the array of calculated values for that employee
            foreach (double[] payroll in CalculateTax(employees))
            {
                //Move the Enumerator to the next element
                employeeEnumerator.MoveNext();
                //Grab the employee from the current point of the cursor
                Employee employee = (Employee) employeeEnumerator.Current;
                //Call UpdatePayRoll to update their payroll data
                employee.UpdatePayroll(payroll[0], payroll[1], (int) payroll[2]);
            }

            //Declare a Delegate that accepts an Employee and will automatically call the Employee's ToString() method and print to the console
            Action<Employee> Print = e => Console.WriteLine(e.ToString());

            //Create a new list of all employees whose net income is larger than 10K using a Lambda expression and the FindAll method of the employees list
            List<Employee> employeesIncomeOver10K = employees.FindAll(employee => employee.NetIncome > 10000);
            //Print the list of all employees whose net income is larger than 10K to the console 
            Console.WriteLine("Employees with net income larger than $10000");
            Console.WriteLine("---------------------------------------------");
            employeesIncomeOver10K.ForEach(Print);

            //Sort the list of employees by their tax value using a lambda expression and the Sort method
            employees.Sort((employee1, employee2) => employee1.NetIncome.CompareTo(employee2.NetIncome));
            //Print the sorted list to the console
            Console.WriteLine("Sorted list of employees according to the tax value");
            Console.WriteLine("-----------------------------------------------------");
            employees.ForEach(Print);
        }

        /*
        * Method Name: CalculateTax
        * Purpose: This static method will calculate and return the required tax, net income and tax year properties of an employee using yield return and dispose all associated resources upon completion
        * Accepts: A generic list of Employees
        * Returns: An IEnumerable Iterator of an array of double values that include the calculated values of tax, net income and tax year
        */
        public static IEnumerable<double[]> CalculateTax(List<Employee> employees)
        {
            //Capture the current year
            int currentYear = DateTime.Now.Year;
            //Use a try-finally block to define all tax variables and calculations and then dispose them from memory upon the foreach loop completing
            try
            {
                //Iterate through the list of employees and calculate the values of tax, net income and tax year properties
                foreach (Employee employee in employees)
                {
                    //Below is the accountant's tax math to calculate tax and net income
                    double benefits = employee.Salary * 0.01;
                    double employmentInsurance = employee.Salary * 0.005;
                    double CPP = employee.Salary * 0.005;
                    double grossIncome = employee.Salary + employee.Bonus;

                    double tax = (employee.Salary <= 50000) ? employee.Salary * 0.20 : employee.Salary * 0.30;
                    double totalDeductions = benefits + employmentInsurance + CPP + tax;
                    double netIncome = grossIncome - totalDeductions;

                    //Identify the tax year by subtracting one from the current year
                    int taxYear = currentYear - 1;

                    //Store the calculated values of tax and net income and the tax year for an Employee in an array of doubles
                    double[] payroll = new double[] { tax, netIncome, taxYear };

                    yield return payroll;
                }
                //Yield break after the foreach loop is finished to enter finally block
                yield break;
            }
            finally
            {
                //The garbage collector will automatically dispose of all associated resources used during calculations once they go out of scope
                Console.WriteLine("Associated resources have been disposed from memory.");
            }
        }

    }
}
