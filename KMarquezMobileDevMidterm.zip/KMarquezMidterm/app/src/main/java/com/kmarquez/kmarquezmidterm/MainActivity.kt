package com.kmarquez.kmarquezmidterm

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.kmarquez.kmarquezmidterm.databinding.ActivityMainBinding
import java.io.IOException

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    companion object {
        lateinit var pokemon: List<Pokemon>
        var pokeDexNum:Int = 0
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        if(pokeDexNum == 0) {
            val prefsEditor = getSharedPreferences("", Context.MODE_PRIVATE)
            var sharedPrefStr = prefsEditor.getString("POKEDEXNUM", "") + "\n" +
                    prefsEditor.getString("NAME", "") + "\n" + prefsEditor.getString("TYPE", "") +
                    "\n" + prefsEditor.getString("CATCH", "")
            binding.textView.text = sharedPrefStr
        } else {
            var lastPokemon = pokemon.find { it -> pokeDexNum.equals(it.pokedex) }
            var lastPokemonStr = lastPokemon?.pokedex.toString() + "\n" +
                    lastPokemon?.name + "\n" + lastPokemon?.type + "\n" +
                    lastPokemon?.catchRate.toString()
            binding.textView.text = lastPokemonStr
            println("Pokemon: " + lastPokemonStr)
        }
    }

    fun getJSONDataFromAsset(context: Context, filename:String):String? {
        val jsonString:String
        try {
            jsonString = context.assets.open(filename).bufferedReader().use {
                it.readText()
            }
        } catch (ioException: IOException) {
            ioException.printStackTrace()
            return null
        }
        return jsonString
    }

    fun onButtonRead(view: View) {
        val jsonFileString = getJSONDataFromAsset(this, "pokedex.json")
        val listPokemonType = object: TypeToken<List<Pokemon>>() {}.type
        pokemon = Gson().fromJson(jsonFileString, listPokemonType)
        var pokedexString:String = ""
        pokemon.forEach {
            pokedexString += (it.pokedex.toString() + ", ")
        }
        println(pokemon)
        binding.textViewPokemonList.text = pokedexString
    }

    fun onLookupClick(view: View) {
        println("Launching lookup activity")
        val intent = Intent(this, LookupActivity::class.java).apply {}
        startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(this).toBundle())
    }

    override fun onResume() {
        super.onResume()
        if(pokeDexNum == 0) {
            val prefsEditor = getSharedPreferences("", Context.MODE_PRIVATE)
            var sharedPrefStr = prefsEditor.getString("POKEDEXNUM", "") + "\n" +
                    prefsEditor.getString("NAME", "") + "\n" + prefsEditor.getString("TYPE", "") +
                    "\n" + prefsEditor.getString("CATCH", "")
            binding.textView.text = sharedPrefStr
        } else {
            var lastPokemon = pokemon.find { it -> pokeDexNum.equals(it.pokedex) }
            var lastPokemonStr = lastPokemon?.pokedex.toString() + "\n" +
                    lastPokemon?.name + "\n" + lastPokemon?.type + "\n" +
                    lastPokemon?.catchRate.toString() + "\n"
            binding.textView.text = lastPokemonStr
            println("Pokemon: " + lastPokemonStr)
        }
    }
}