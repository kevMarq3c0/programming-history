package com.kmarquez.kmarquezmidterm

import android.content.Context
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.kmarquez.kmarquezmidterm.databinding.ActivityLookupBinding

class LookupActivity : AppCompatActivity() {
    private lateinit var lookupBinding: ActivityLookupBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        lookupBinding = ActivityLookupBinding.inflate(layoutInflater)
        setContentView(lookupBinding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        lookupBinding.editTextNumber.setText("")
        lookupBinding.textViewPokedexRes.text = ""
        lookupBinding.textViewNameRes.text = ""
        lookupBinding.textViewTypeRes.text = ""
        lookupBinding.textViewCatchRes.text = ""
    }

    fun onReturnClick(view: View) {
        finishAfterTransition()
    }

    fun onFindByIndexClick(view: View) {
        var inputIndex:Int = lookupBinding.editTextNumber.text.toString().toInt()
        var pokemonFound:Boolean = false
        MainActivity.pokemon.forEach{
            if(it.pokedex == inputIndex)
            {
                lookupBinding.textViewPokedexRes.text = it.pokedex.toString()
                lookupBinding.textViewNameRes.text = it.name
                lookupBinding.textViewTypeRes.text = it.type
                lookupBinding.textViewCatchRes.text = it.catchRate.toString()
                MainActivity.pokeDexNum = inputIndex
                pokemonFound = true
            }
        }
        if(!pokemonFound) {
            lookupBinding.textViewPokedexRes.text = ""
            lookupBinding.textViewNameRes.text = ""
            lookupBinding.textViewTypeRes.text = ""
            lookupBinding.textViewCatchRes.text = ""
        }
    }

    override fun onResume() {
        super.onResume()
        val prefsEditor = getSharedPreferences("KMarquezMidterm", Context.MODE_PRIVATE)
        lookupBinding.editTextNumber.setText(prefsEditor.getString("POKEDEXCHECK",""))
        lookupBinding.textViewPokedexRes.text = prefsEditor.getString("POKEDEXNUM","")
        lookupBinding.textViewNameRes.text = prefsEditor.getString("NAME","")
        lookupBinding.textViewTypeRes.text = prefsEditor.getString("TYPE","")
        lookupBinding.textViewCatchRes.text = prefsEditor.getString("CATCH","")
    }

    override fun onPause() {
        val prefsEditor = getSharedPreferences("KMarquezMidterm", Context.MODE_PRIVATE).edit()
        prefsEditor.putString("POKEDEXCHECK", lookupBinding.editTextNumber.text.toString())
        prefsEditor.putString("POKEDEXNUM", lookupBinding.textViewPokedexRes.text.toString())
        prefsEditor.putString("NAME", lookupBinding.textViewNameRes.text.toString())
        prefsEditor.putString("TYPE", lookupBinding.textViewTypeRes.text.toString())
        prefsEditor.putString("CATCH", lookupBinding.textViewCatchRes.text.toString())
        prefsEditor.apply()
        super.onPause()
    }
}