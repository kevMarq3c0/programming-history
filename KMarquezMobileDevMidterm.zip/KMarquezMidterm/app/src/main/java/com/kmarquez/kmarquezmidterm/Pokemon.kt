package com.kmarquez.kmarquezmidterm

data class Pokemon(var catchRate:Int = 0, var name:String?=null, var pokedex:Int = 0,
                   var type:String?=null) {

}
