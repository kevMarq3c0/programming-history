import java.util.Scanner;

/**
 * Program Name:K_M_ProjectMethods.java
 * Purpose: To store my methods
 * Coder: Kevin Marquez 1054838 for Section 03
 * Date: Thurs, Nov 21 2021
 */

public class K_M_ProjectMethods
{
	/**
	 *Method Name: getNextSeries class
	 *Purpose: Split-ups the tokens contained in the line based on where the comma delimiters are
	 *Accepts: An initialized scanner object that's associated with the file  
	 *Returns: An array of integers which is the series of numbers contained in the next line
	 *Date: Thurs, Nov 21 2021
	 *Coder: KM
	 *Source: https://www.tutorialspoint.com/How-to-convert-string-to-array-of-integers-in-java
	*/
	public static int[] getNextSeries(Scanner fileReader)
	{ 
		  int [] tokenIntArray = new int[6];
		  if(fileReader.hasNextLine()) 
		  { 
		  	String tokenLine = fileReader.nextLine();
		  	String [] tokenArray = tokenLine.split(","); 
		  	for (int i = 0; i < tokenArray.length; i++) 
		  	{ 
		  		tokenIntArray[i] = Integer.parseInt(tokenArray[i]); 
		  	} 
		  	/*
		  	for (int i = 0; i < tokenArray.length; i++)
		  	{
		  		if (i < tokenArray.length - 1 )
		  		{
		  			System.out.print(tokenIntArray[i] + ", ");
		  		}
		  		else
		  		{
		  			System.out.println(tokenIntArray[i]);
		  		}
		  	}
		  	*/
		  } 
		  //end while
		 	return tokenIntArray;
	}
	//end method
	
	/*
	 *Method Name: countMatchingNumbers()
	 *Purpose: Creates an algorithm to compare the numbers in each array 
	 *Accepts: Two integer arrays as arguments
	 *Returns: The number of matches from the method
	 *Date: Thurs, Nov 21 2021
	 *Coder: KM
	*/
	public static int countMatchingNumbers(int[]array1, int[]array2)
	{
		int matchingNumCount = 0;
		for (int i = 0; i < array2.length; i++)
		{
			for (int j = 0; j < array1.length; j++)
			{
				if (array2[i] == array1[j])
				{
					matchingNumCount++;
				}
			}
		}
		return matchingNumCount;
	}//end method
	
	/*
	 *Method Name: formatTicketNumbers()
	 *Purpose: Formats the numbers in order on the same line, with a comma and space as delimiters
	 *Accepts: An integer array containing one set of ticket numbers
	 *Returns: A formatted string containing the numbers
	 *Date: Saturday, Nov 27, 2021
	 *Coder: KM
	 *Source: https://beginnersbook.com/2017/10/java-string-join-method/
	 *				https://howtodoinjava.com/java8/java-8-join-string-array-example/
	 *				https://www.techiedelight.com/convert-int-array-string-array-java/
	*/
	public static String formatTicketNumbers(int[] array)
	{
		String[] formatString = new String[array.length];
		
		for (int i = 0; i < array.length; i++)
		{
			for (int j = 0; j < array.length; j++)
			{
				if (array[i] < array[j])
				{
					 int temp = array[i];
					 array[i] = array[j];
					 array[j] = temp;
				}
			}//end inner for
		}//end outer for 
		for(int i = 0; i < array.length; i++)
		{
			formatString[i] = String.valueOf(array[i]);
		}
		String joined = String.join(", ", formatString);
		return joined;
	}//end method 
}

/*
 *Method Name: 
 *Purpose: 
 *Accepts: 
 *Returns: 
 *Date: 
 *Coder: 
*/

//end class