/**
 * Program Name:K_M_LotteryPrizes.java
 * Purpose: Analyze the ticket numbers data contained in the selected data file to determine which
 * 					ticket holders have won a prize, how many ticket holders will have to share a prize and how 
 * 					much money they'll each receive.
 * Coder: Kevin Marquez 1054838 for Section 03
 * Date: November, 2021
 * 
 * PSEUDO-CODE
 * 1) Input Scanner object and File object
 * 2) Prompt the user to input the following
 * 		i) A description or name for the lottery
 * 		ii) The total amount of money in the prize pool (dollars only, no decimals, must be at least $1,000)
 * 		iii) The path and name for the input file
 * 3) Create a Scanner object to read the data from the file
 * 		i) Include suitable exception handling code, display an informative error message if an error
 * 4) Write a class method called getNextSeries()
 * 		i) First time this method is called, it will return the winning numbers.
 * 		ii) The second time will contain the winning numbers
 * 		iii) Return the count of the number of matches
 * 5) Write a class method called formatTicketNumbers()
 * 		i) Accepts an integer array and then returns a formatted string with the numbers in order
 * 		ii) Use delimiters of some sort
 * 6) Set up two data structures to store the numbers for tickets that have won a prize
 * 		i) One for second prize winners and one for third prize numbers 
 * 		ii) No need for grand prize winners as those tickets will exactly match the winning numbers
 * 				1) However set up a counter variable to keep track of the number of tickets that are grand prize
 * 					 winners
 * 		iii) These data structures should be expandable so that an element can be added each time after a
 * 				 winning ticket is found.
 * 7) Call the getNextSeries() method once to obtain and store the winning numbers
 * 		i) Set-up a loop that will call the method again repeatedly until there are no more lines to be read
 * 		ii) Each iteration of this loop should test the current set of ticket numbers against the winning 
 * 				numbers using the countMatchingNumbers() method to determine if it's a winner.
 * 8) After analyzing all the ticket numbers in the file, generate a report showing the results of this analysis
 */
import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;
public class K_M_LotteryPrizes
{

	public static void main(String[] args)
	{
		//Create the Scanner and File object
		Scanner input = new Scanner(System.in);
		String lotteryName;
		int prizeMoney;
		String pathDataFile = "";
		double GRAND_PRIZE_PERCENT = 0.85;
		double SECOND_PRIZE_PERCENT = 0.07;
		double THIRD_PRIZE_PERCENT = 0.08;
		
		
		// Output the title of the output 
		System.out.println("Lottery Prizes Analyzer");
		
		// Prompt the user to input the name and prizeMoney
		System.out.print("\nEnter the name of the lottery: ");
		lotteryName = input.nextLine();
		System.out.print("Enter the amount of money in the prize pool: $");
		prizeMoney = input.nextInt();
		
		//Validate user input to be equal to or greater than $1000
		while (prizeMoney < 1000)
		{
			System.out.print("Too little money! Must be at least $1000."
					+ " Enter the amount of money in the prize pool: $");
			prizeMoney = input.nextInt();
		}
		
		//FLUSH......rude house guest
		input.nextLine();
		
		// Prompt the user to input the path file 
		System.out.print("Enter the path for the data file: ");
		pathDataFile = input.nextLine();
		
		//Use try and catch for exception handling code so that no runtime error occurs if the file isn't found
		try 
		{
			File userFile = new File(pathDataFile);
			Scanner fileReader = new Scanner(userFile);
			
			//Display report of the name of the lottery, total prize pool, total tickets purchased 
			//and winning numbers
			System.out.println("\nLottery Prizes Report");
			System.out.println("----------------------");
			System.out.println("\nLottery Name:\t\t" + lotteryName);
			System.out.println("Total prize pool:\t$" + prizeMoney);
			
			//count total tickets
			int totalTickets = 0;
			int loopCount = 0;
			while (fileReader.hasNextLine())
			{
				fileReader.nextLine();
				if(loopCount == 0)
				{
					loopCount++;
					continue;
				}
				totalTickets++;
			}
			
			fileReader.close();
			fileReader = new Scanner(userFile);
			
			System.out.println("Number of tickets:\t"  + totalTickets);
			
			// Call the getNextSeries() method once to obtain and store the winning numbers
			System.out.print("Winning numbers:\t");
			int[] winningNums = K_M_ProjectMethods.getNextSeries(fileReader);
			for (int i = 0; i < winningNums.length; i++)
			{
				if (i < winningNums.length - 1 )
				{
					System.out.print(winningNums[i] + ", ");
				}
				else
				{
					System.out.println(winningNums[i]);
				}
			}
			

			//Set-up two data structures to store the numbers for tickets that have won a prize
			//Set up a counter variable to keep track of the number of the winning numbers
			ArrayList<String> secondPrizeWinners = new ArrayList<String>();
		  ArrayList<String> thirdPrizeWinners = new ArrayList<String>();
			int grandPrizeWinnersCount = 0;
			
			// Set-up a loop that will call the method again repeatedly until there are no more lines to be read
			int numSecondPrizes = 0;
			int numThirdPrizes = 0;
			
			for (int i = 0; i < totalTickets; i++)
			{
				//each iteration of this loop tests the current set of ticket numbers against the winning numbers
				int[] tempArray = K_M_ProjectMethods.getNextSeries(fileReader);
				int matchNum = K_M_ProjectMethods.countMatchingNumbers(tempArray, winningNums);
				
				//If a ticket is a grand prize winner, increment the "grand prize winner" counter
				if (matchNum == 6)
				{
					grandPrizeWinnersCount++;
				}
				
				//If a ticket has all but one numbers match the winning numbers, save the ticket numbers
				//into the second prize winner data structure
				else if (matchNum == 5)
				{
					 secondPrizeWinners.add(K_M_ProjectMethods.formatTicketNumbers(tempArray));
					 numSecondPrizes++;
				}
				
				//If a ticket has all but two numbers match the winning numbers, save the ticket numbers
				//into the third prize winner data structure
				else if (matchNum == 4)
				{
					thirdPrizeWinners.add(K_M_ProjectMethods.formatTicketNumbers(tempArray));

					numThirdPrizes++;

				}
			}
			
			//Report the grand prize winners, total prize value, and prize per ticket
			System.out.println("\nGrand prize winners (all numbers match)...");
			System.out.println("Number of winners:\t" + grandPrizeWinnersCount);
			System.out.println("% of prize pool:\t85.0");
			System.out.println("Total prize value:\t$" + (prizeMoney * GRAND_PRIZE_PERCENT));
			System.out.println("Prize per ticket:\t$" + (prizeMoney * GRAND_PRIZE_PERCENT)/grandPrizeWinnersCount);
			
			//Report the second prize winners, total prize value, and prize per ticket
			System.out.println("\nSecond prize winners (5 numbers match)...");
			System.out.println("Number of winners:\t" + numSecondPrizes);
			System.out.println("% of prize pool:\t7.0");
			System.out.format("Total prize value:\t$%.2f", (prizeMoney * SECOND_PRIZE_PERCENT));
			System.out.format("\nPrize per ticket:\t$%.2f", ((prizeMoney * SECOND_PRIZE_PERCENT)/numSecondPrizes));
			System.out.print("\nTicket Numbers:\t\t");
			for(String ticket: secondPrizeWinners)
	    {
	    	System.out.print(ticket + "\t");
	    }
			
			//Report the third prize winners, total prize value, and prize per ticket
			System.out.println("\n\nThird prize winners (4 numbers match)...");
			System.out.println("Number of winners:\t" + numThirdPrizes);
			System.out.println("% of prize pool:\t8.0");
			System.out.format("Total prize value:\t$%.2f", (prizeMoney * THIRD_PRIZE_PERCENT));
			System.out.format("\nPrize per ticket:\t$%.2f", ((prizeMoney * THIRD_PRIZE_PERCENT)/numThirdPrizes));
			System.out.print("\nTicket Numbers:\t\t");
			
			//counter variable in order to create newline
			int line = 0;
			for(String ticket: thirdPrizeWinners)
	    {
	    	System.out.print(ticket + "\t");
	    	line++;
	    	if(line % 2 == 0)
	    	{
	    		System.out.println();
	    		System.out.print("\t\t\t");
	    	}
	    }
			
		} //end try
		
		catch(FileNotFoundException ex)
		{
			System.out.println("An exception was caught, its message is " + ex.getMessage());
			ex.printStackTrace();
		}//end catch
		
		//HOUSEKEEPING 
		input.close();
	}
	//end main
}
//end class