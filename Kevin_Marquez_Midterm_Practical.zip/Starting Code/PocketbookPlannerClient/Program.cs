﻿/*
 * Program:         PocketbookPlannerClient.exe
 * Module:          Program.cs
 * Date:            February 2024
 * Student Name:    Kevin Marquez
 * Description:     Console client to test PocketbookPlannerLibrary.dll.
 * 
 *                  This client is incomplete. 
 *                  -   You must reference your own PocketbookPlannerLibrary and
 *                      obtain an IPlanner interface reference where directed
 *                      in the source code below. 
 *                  -   No other changes should be required!
 */

using PocketbookPlannerLibrary;

namespace PocketbookPlannerClient
{
    internal class Program
    {
        static void Main()
        {
            // Display a title
            PrintHeader(50, "The Pocketbook Planner", true);

            /** 
             * TO DO: Declare and initialize an IPlanner interface variable called 'planner'
             */
            IPlanner planner = new Planner();
            
            // Obtain data for each expense and display a summary
            int count = 0;
            do
            {
                // User inputs
                Console.Write($"\nExpense {++count} description: ");
                string description = Console.ReadLine() ?? "";
                double amount = GetUserAmount();
                FrequencyType frequency = GetUserFrequency();

                // Add expense
                planner.AddExpense(description, amount, frequency);

            } while (!EndUserInput());

            // Summary report of the monthy planner
            Console.WriteLine();
            PrintHeader(50, "Summary of Monthly Expenses", true);
            foreach (IExpense expense in planner.GetExpenses())
                Console.WriteLine(expense);
            PrintHeader(50, String.Format("Total monthly expenses = {0:C}", planner.CalcMonthlyTotal()), false);

        } // end Main()

        #region helper_code

        // Obtains a frequency for an expense from the user
        private static FrequencyType GetUserFrequency()
        {
            FrequencyType frequency;
            bool validInput;
            do
            {
                Console.Write("Frequency (weekly, monthly or yearly): ");
                string input = Console.ReadLine() ?? "";
                input = Char.ToUpper(input[0]) + input.Substring(1);
                if (!(validInput = Enum.TryParse<FrequencyType>(input, out frequency)))
                    Console.WriteLine("ERROR: Input must be weekly, monthly or yearly.");
            } while (!validInput);
            return frequency;
        } // end GetUserFrequency()

        // Obtains a valid expense amount from the user 
        private static double GetUserAmount()
        {
            string input;
            double amount;
            bool validInput;
            do
            {
                Console.Write("Amount: $");
                input = Console.ReadLine() ?? "";
                if (!(validInput = double.TryParse(input, out amount) && amount > 0))
                    Console.WriteLine($"ERROR: Amount must be a number greater than 0.");
            } while (!validInput);
            return amount;
        } // end GetUserAmount()

        // Returns true if the user has no more expenses to input
        private static bool EndUserInput()
        {
            Console.Write("\nAdd another expense? (y/n): ");
            char input = Console.ReadKey().KeyChar;
            while (!"yn".Contains(input))
            {
                Console.Write("\nInput must be y or n. Add another expense?: ");
                input = Console.ReadKey().KeyChar;
            }
            Console.WriteLine();
            return input == 'n';
        } // end EndUserInput

        // Prints text to the console in a banner format
        private static void PrintHeader(int width, string text, bool centre)
        {
            if (text is not null)
            {
                string line = new('-', width);
                Console.WriteLine(line);
                string format = "{0" + (centre ? "," + (width + text.Length) / 2 : "") + "}";
                Console.WriteLine(format, text);
                Console.WriteLine(line);
            }
        } // end PrintHeader();

        #endregion

    }
}