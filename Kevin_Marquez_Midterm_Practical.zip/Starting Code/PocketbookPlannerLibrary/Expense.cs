﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace PocketbookPlannerLibrary
{
    internal class Expense : IExpense
    {
        public string Description { get; private set; }

        public double Amount { get; private set; }

        public FrequencyType Frequency { get; private set; }

        internal Expense(string description_, double amount_, FrequencyType frequency_)
        {
            Description = description_;
            Amount = amount_;
            Frequency = frequency_;
        }

        public double GetMonthlyAmount()
        {
            double monthlyAmount;
            switch (Frequency)
            {
                case FrequencyType.Weekly:
                    monthlyAmount = (Amount * 52) / 12;
                    break;
                case FrequencyType.Monthly:
                    monthlyAmount = Amount;
                    break;
                case FrequencyType.Yearly:
                    monthlyAmount = Amount / 12;
                    break;
                default:
                    monthlyAmount = -1;
                    break;
            }

            return monthlyAmount;
        }

        public override string ToString()
        {
            return string.Format("{0} @ ${1:N2} {2} = ${3:N2}", Description, Amount, Frequency, GetMonthlyAmount());
        }
    }
}
