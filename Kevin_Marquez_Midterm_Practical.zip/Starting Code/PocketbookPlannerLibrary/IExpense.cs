﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PocketbookPlannerLibrary
{
    public interface IExpense
    {
        public string Description { get; }
        public double Amount { get; }

        public FrequencyType Frequency { get; }

        public double GetMonthlyAmount();

        public abstract string ToString();
    }
}
