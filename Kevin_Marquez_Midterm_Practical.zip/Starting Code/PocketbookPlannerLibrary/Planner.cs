﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PocketbookPlannerLibrary
{
    public class Planner : IPlanner
    {
        private List<Expense> expenses;

        public Planner() 
        { 
            expenses = new List<Expense>();
        }

        void IPlanner.AddExpense(string description, double amount, FrequencyType frequency)
        {
            Expense newExpense = new Expense(description, amount, frequency);
            expenses.Add(newExpense);
        }

        double IPlanner.CalcMonthlyTotal()
        {
            double total = 0;
            foreach(Expense expense in expenses)
            {
                total += expense.GetMonthlyAmount();
            }
            return total;
        }

        IExpense[] IPlanner.GetExpenses()
        {
            return expenses.ToArray();
        }
    }
}
