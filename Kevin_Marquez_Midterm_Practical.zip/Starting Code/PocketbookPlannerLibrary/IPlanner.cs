﻿namespace PocketbookPlannerLibrary
{
    public interface IPlanner
    {
        public void AddExpense(string description, double amount, FrequencyType frequency);

        public IExpense[] GetExpenses();

        public double CalcMonthlyTotal();
    }
}
