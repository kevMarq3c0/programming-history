﻿/*
 * Program: Security.cs
 * Date: 2024-02-02
 * Author: Kevin Marquez #1054838
 * Purpose: This is a non-generic class that will hold the data of registered users (acting like a pseudo database), a user to test to see if they made a valid login attempt, and security methods to check and validate the user's
 *          login information, their privileges, and the number of times they get into the system.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises3_KM
{
    public class Security
    {
        //Declare private variables, a generic list of type User, the user to test as type User, and a boolean to test if the user has valid login information
        private List<User> _registeredUsers = new List<User>();
        private User? _testedUser;
        private bool _IsValidUser;

        /*
        * Method Name: InsertUsers
        * Purpose: This method will pass over a generic list of type users and add its items to the private generic list _registeredUsers
        * Accepts: A generic list 
        * Returns: Nothing
        */
        public void InsertUsers(List<User> listOfUsers)
        {
            foreach(var user in listOfUsers)
            {
                _registeredUsers.Add(user);
            }
        }

        /*
        * Method Name: SetUser
        * Purpose: This method will pass over the login name, password and role to create a new User to validate and pass to the _testedUser
        * Accepts: Three strings
        * Returns: Nothing
        */
        public void SetUser(string loginName, string password, string role)
        {
            _testedUser = new User(loginName, password, role);
        }

        /*
        * Method Name: Authentication
        * Purpose: This method will check if the login name and password of the _testedUser are valid and display a message to confirm whether the login was successful or not
        * Accepts: Nothing
        * Returns: Nothing
        */
        public void Authentication()
        {
            //Initialize our private boolean to false as its default
            _IsValidUser = false;
            
            //Check if the user is null, if it is then automatically fail the login attempt
            if (_testedUser != null)
            {
                //Check through the list of registeredUsers and see if the testedUser matches the login name AND the password of a registered user
                foreach (var user in _registeredUsers)
                {
                    //If the login name and password both match for a registered user, change the boolean to true and break out of the loop
                    if (_testedUser._Login_name == user._Login_name && _testedUser._Password == user._Password)
                    {
                        _IsValidUser = true; 
                        break;
                    }
                }

                //Return a string based on if the login was successful or not
                string loginResult;
                if (_IsValidUser)
                {
                    //Change the colour of the console foregound (Personal cosmetic choice) to show whether the login was successful or not
                    Console.ForegroundColor = ConsoleColor.Green;
                    loginResult = "Login successful!";
                }
                else
                {
                    //Change the colour of the console foreground (Personal cosmetic choice) to show whether the login was successful or not
                    Console.ForegroundColor = ConsoleColor.Red;
                    loginResult = "Login failed!";
                }
                //Display a message confirming if the login was successful or failed
                Console.WriteLine(loginResult);
            }
            else
            {
                //Change the colour of the console foreground and display a message to the console (Personal cosmetic choice) to indicate the login was not successful
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Login failed!");
            }
            //Return the console foreground to white
            Console.ForegroundColor = ConsoleColor.White;
        }

        /*
        * Method Name: Authorization
        * Purpose: This method will print out a message based on if the authentication was valid and if the tested users holds one of three roles, Admin, Trusted and Guest and specify their privileges.
        *          It will also increment the number transactions of each valid user based on their role.
        * Accepts: Nothing
        * Returns: Nothing
        */
        public void Authorization()
        {
            //Check if the authentication was valid for the user, if not then display "No privileges"
            if(_IsValidUser)
            {
                //If authentication was valid, check if the tested user holds on of the following roles
                switch (_testedUser!._Role!.ToLower()) 
                {
                    case "admin":
                        //Admin user's transactions increment by three
                        Console.WriteLine("\"Admin\": All privileges are granted!\n");
                        _registeredUsers.First(user => user._Login_name == _testedUser._Login_name)._NoOfTransactions += 3;
                        break;
                    case "trusted":
                        //Trusted user's transactions increment by two
                        Console.WriteLine("\"Trusted\": Read/write privileges are granted!\n");
                        _registeredUsers.First(user => user._Login_name == _testedUser._Login_name)._NoOfTransactions += 2;
                        break;
                    case "guest":
                        //Guest user's transactions increment by one
                        Console.WriteLine("\"Guest\": Read privileges are only granted!\n");
                        _registeredUsers.First(user => user._Login_name == _testedUser._Login_name)._NoOfTransactions++;
                        break;
                    default:
                        //Otherwise, display "No privileges" and do not increment the transactions of the user
                        Console.WriteLine($"No privileges have assigned to this user: {_testedUser!._Login_name}\n");
                        break;
                }
            }
            else
            {
                //Display the "no privileges" message when authentication failed, and if the user is null then input a default string value to prevent an error
                string? userLoginName = (_testedUser != null) ? _testedUser._Login_name : "No user name found";
                Console.WriteLine($"No privileges have assigned to this user: {userLoginName}\n");
            }
        }

        /*
        * Method Name: Auditing
        * Purpose: This method will print out the number of transactions of all valid and invalid users and show the user login name
        * Accepts: Nothing
        * Returns: Nothing
        */
        public void Auditing()
        {
            //Iterate through out registeredUsers and print out the number of transactions as well as their username
            foreach(User user in _registeredUsers)
            {
                Console.WriteLine("User Login Name: {0}\nNo. of Transactions: {1}\n", user._Login_name, user._NoOfTransactions);
            }
            //If the user was invalid, also print out the number of transactions and the user login name
            if (!_IsValidUser)
            {
                //Check if the user is null, and if they are then input default string and int values to prevent an error
                string? userLoginName = (_testedUser != null) ? _testedUser._Login_name + " (Failed)" : "No user name found";
                int? userTransactions = (_testedUser != null) ? _testedUser._NoOfTransactions : 0;
                Console.WriteLine("User Login Name: {0}\nNo. of Transactions: {1}\n", userLoginName, userTransactions);
            }
        }
}
}
