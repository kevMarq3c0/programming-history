﻿/*
 * Program: Program.cs
 * Date: 2024-02-02
 * Author: Kevin Marquez #1054838
 * Purpose: This is the main method of the Exercise where we will create our delegates to chain and execute the Security methods against users that we declared in this class.
 */

namespace Exercises3_KM
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Create a generic list of Users 
            List<User> users = new List<User>
            {
                new User("adminUser", "A1267K", "Admin"),
                new User("trustedUser", "T456J", "Trusted"),
                new User("guestUser", "G0984X", "Guest")
            };

            //Declare a Security instance and use the InsertUsers method to pass over the list to the private list in the Security class
            Security secureSystem = new Security();
            secureSystem.InsertUsers(users);

            //Create three different users with different roles to test against the registered users above
            List<User> testUsers = new List<User>
            {
                new User("adminUser", "A5067K", "Admin"),
                new User("trustedUser", "T456J", "Trusted"),
                new User("guestUser", "G0984X", "Guest")
            };

            //Use the built-in Action delegate which can take 0 up to 16 parameters if you use <> to chain and execute the Security methods,
            //Authentication, Authorization and Auditing for each individual user 
            Action securityDelegate = new Action(secureSystem.Authentication);
            securityDelegate += secureSystem.Authorization;
            securityDelegate += secureSystem.Auditing;

            //Test each user by passing over its value using the SetUser method of the Security class and invoke our Delegate
            foreach(User user in testUsers)
            {
                secureSystem.SetUser(user._Login_name!, user._Password!, user._Role!);
                securityDelegate();
                Console.WriteLine("------------------------------------------------------");
            }
        }
    }
}