﻿/*
 * Program: User.cs
 * Date: 2024-02-02
 * Author: Kevin Marquez #1054838
 * Purpose: This is a non-generic class that represents a user trying to log into a security system. It has four properties which the Security class will use to test Users against registered Users already in the Security System.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises3_KM
{
    public class User
    {
        //Declare four properties, 3 which are strings with default values of null that we will use to log in to the system
        //and a calculated field that will keep track of the number of transactions for this User in the system with a default value of Zero
        public string? _Login_name;
        public string? _Password;
        public string? _Role;
        public int _NoOfTransactions = 0;

        //This is the default constructor for the User class to initialize our properties to null
        public User() 
        { 
            _Login_name = null;
            _Password = null;
            _Role = null;
        }

        //This constructor will take in 3 parameters to initialize the Login Name, the Password and the Role of the User
        public User(string login_name, string password, string role)
        {
            _Login_name = login_name;
            _Password = password;
            _Role = role;
        }
    }
}
