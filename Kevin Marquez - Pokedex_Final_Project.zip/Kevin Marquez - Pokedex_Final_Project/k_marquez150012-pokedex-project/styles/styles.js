import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
    screen: {
        flex: 1,
        padding: 50,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#AA4A44'
    },
    title: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    section: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        alignItems: 'flex-start'
    },
    titleText: {
        color: 'white',
        fontSize: 35,
        fontWeight: 'bold',
        marginBottom: 10
    },
    subtitleText: {
        color: 'white',
        fontSize: 25,
    },
    list: {
        flex: 1,
        margin: 5,
        height: 100,
        justifyContent: 'space-around',
        elevation: 1
    },
    inputCaption: {
        color: 'white',
        alignItems: 'flex-start',
        marginLeft: 30,
    },
    listItem: {
        padding: 10,
        marginVertical: 10,
        backgroundColor: '#FDDA0D',
        borderColor: 'gray',
        flexDirection: 'row',
        borderWidth: 1,
        justifyContent: 'center',
        alignItems: 'center'
    }, 
    inputContainer: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        backgroundColor: '#AA4A44',
    },
    imageContainer: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#AA4A44',
    },
    input: {
        width: '80%',
        borderColor: 'grey',
        borderWidth: 1,
        backgroundColor: 'white',
        padding: 10,
        marginBottom: 15,
        marginLeft: 30,
    },
    buttonContainer: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#AA4A44',
        paddingTop: 20,
    },
    navButton: {
        padding: 10,
        borderColor: 'grey',
        borderWidth: 1,
    },
    headerButtonText: {
       color: 'white',
       fontSize: 20,
    }, 
    text: {
        color: 'white',
    },
    imagePreview: {
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 20,
    },
    image: {
        width: '50%', // Make image responsive by using percentage
        borderRadius: 50,
        backgroundColor: 'gray',
        height: 100,   // Fixed height, you might want to make this responsive as well
        marginBottom: 10
    },
    infoImage: {
        width: '100%',
        height: 200,
        marginBottom: 10
    },
    defaultImage: {
        width: 100, // Make image responsive by using percentage
        borderRadius: 50,
        backgroundColor: 'gray',
        alignItems: 'center',
        height: 100,   // Fixed height, you might want to make this responsive as well
        marginBottom: 10
    },
    imageText: {
        color: 'yellow',
        verticalAlign: 'middle',
        lineHeight: 100,
    },
    pickerInput: {
        borderColor: '#ccc',
        width: '100%',
        paddingLeft: 5,
        borderWidth: 1,
        marginBottom: 15,
        marginRight: 15,
    },
    inputGroup: {
        flexWrap: 'wrap',
        alignItems: 'flex-start',
        width: '100%',
    }, 
    inputLabel: {
        fontSize: 18,
        marginBottom: 16,
        color: 'white',
        textAlign: 'left'
    },
    textInput: {
        borderColor: '#ccc',
        color: 'white',
        width: '100%',
        minWidth: '100%',
        paddingLeft: 5,
        borderWidth: 1,
        marginBottom: 15,
        marginRight: 15,
    },
    scrollViewContainer: {
        flexGrow: 1,
        justifyContent: 'center',
    },
    checkbox: {
        margin: 8,
    },
    checkboxContainer: {
        marginTop: 10,
        flexDirection: 'row',
    },
    authContainer: {
        padding: 20,
        marginTop: 50,
    },
    bottom: {
        flexDirection: 'column',
        justifyContent: 'flex-end',
    },
})