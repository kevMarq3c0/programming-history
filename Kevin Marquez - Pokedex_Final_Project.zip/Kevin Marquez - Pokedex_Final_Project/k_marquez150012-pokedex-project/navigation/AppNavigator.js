import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import MainScreen from '../screens/MainScreen';
import PokedexInfoScreen from '../screens/PokedexInfoScreen';
import PokedexInputScreen from '../screens/PokedexInputScreen';

const Stack = createNativeStackNavigator();

function AppNavigator() {
    return (
        <NavigationContainer>
            <Stack.Navigator
                initialRouteName="MainScreen"
                screenOptions={{
                    headerTintColor: 'white',
                    headerStyle: {backgroundColor: '#5F9EA0'},
                    headerTitleStyle: {fontWeight: 'bold'},
                    headerTitleAlign: 'center',
                }}
            >
                <Stack.Screen name="MainScreen" component={MainScreen} options={{title: 'Pokedex'}}/>
                <Stack.Screen name="PokedexInputScreen" component={PokedexInputScreen} options={{title: 'Add Pokedex Entry'}}/>
                <Stack.Screen name="PokedexInfoScreen" component={PokedexInfoScreen} options={(route) => ({title: route.params?.screenTitle || 'Pokemon Information'})}/>
            </Stack.Navigator>
        </NavigationContainer>
    );
};

export default AppNavigator;