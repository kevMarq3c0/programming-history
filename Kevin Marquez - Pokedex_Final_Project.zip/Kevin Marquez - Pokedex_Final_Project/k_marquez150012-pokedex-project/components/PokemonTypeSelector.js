import React, {useState, useEffect} from 'react';
import {View, Text} from 'react-native';
import {Picker} from "@react-native-picker/picker";
import {styles} from "../styles/styles";

const PokemonTypeSelector = (props) => {
    const [selectedPokemonType, setSelectedType] = useState();

    useEffect(() => {
        if(props.value)
        {
            setSelectedType(props.value);
        }
    }, [props.value]);

    const typeChosen = (pokemonType) => {
        setSelectedType(pokemonType);
        props.onChangeText(pokemonType);
    };

    var pokemonTypes = [
        'Bug', 'Dark', 'Dragon', 'Electric', 'Fairy', 'Fighting', 'Fire', 'Flying', 'Ghost', 'Grass', 'Ground', 'Ice', 'Normal', 'Poison', 'Psychic', 'Rock', 'Steel', 'Water'
    ];

    return (
        <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>{props.label}</Text>
            <View style={styles.input}>
                <Picker
                    style={styles.pickerInput}
                    selectedValue={props.value ? props.value : selectedPokemonType }
                    onValueChange={(itemValue, itemIndex) =>
                        typeChosen(itemValue)
                    }>
                        <Picker.Item key={'unselectable'} label={props.placeHolder} value='0' enabled={false}/>
                        {pokemonTypes.map((pokemonType)=> {
                            return (<Picker.Item label={pokemonType} value={pokemonType} key={pokemonType}/>)
                        })}
                </Picker>
            </View>
        </View>
    )
};

export default PokemonTypeSelector;