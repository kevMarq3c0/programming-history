import React from 'react';
import { TouchableOpacity, Text } from 'react-native';
import {styles} from '../styles/styles';

const CustomHeaderButton = ({title, onPress}) => {
    return (
        <TouchableOpacity onPress={onPress} style={styles.navButton}>
            <Text style={styles.headerButtonText}>{title}</Text>
        </TouchableOpacity>
    );
};

export default CustomHeaderButton;