import React, {useState} from 'react';
import {View, Text, TouchableOpacity, Image} from 'react-native';
import {styles} from '../styles/styles';

const PokedexListItem = (props) => {
    return (
        <TouchableOpacity onPress={props.onPress.bind(this, props.id)}>
            <View style={styles.listItem}>
                <Image style={styles.image} source={{uri: props.item.uri}}/>
                <Text style={{marginLeft: 10}}>No. {props.number} - {props.item.name}</Text>
            </View>
        </TouchableOpacity>
    )
}

export default PokedexListItem;