import React, {useEffect, useState} from "react";
import {View, Image, Text, ScrollView, Button} from 'react-native';
import { styles } from "../styles/styles";
import * as MailComposer from "expo-mail-composer";
import * as SMS from 'expo-sms';

const PokedexInfoScreen = ({navigation, route}) => {
    const [selectedPokemon, SetSelectedPokemon] = useState();

    useEffect(() => {
        if(route.params?.newPokemon) {
            SetSelectedPokemon(route.params?.newPokemon.value);
        }
    }, [route.params?.newPokemon]);

    const sendMessageWithSMS = async () => {
        const isAvailable = await SMS.isAvailableAsync();

        let smsMsg = 'Name: ' + selectedPokemon.name + '\nCategory: ' + selectedPokemon.category + '\nType: ' + selectedPokemon.primaryType;
        if(selectedPokemon.secondaryType)
        {
            smsMsg += ', ' + selectedPokemon.secondaryType;
        }

        smsMsg += '\nHeight: ' + selectedPokemon.height + '\nWeight: ' + selectedPokemon.weight + '\nDescription: ' + selectedPokemon.description + '\nCaught: ' + selectedPokemon.status;

        if(isAvailable) {
            const {result} = await SMS.sendSMSAsync('1234567890', smsMsg);
            console.log(result);
        } else {
            console.log('SMS is not available');
        }
    };

    const sendMessageWithEmail = async () => {
        const isAvailable = await MailComposer.isAvailableAsync();
        
        let emailMsg = 'Name: ' + selectedPokemon.name + '\nCategory: ' + selectedPokemon.category + '\nType: ' + selectedPokemon.primaryType;
        if(selectedPokemon.secondaryType)
        {
            emailMsg += ', ' + selectedPokemon.secondaryType;
        }

        emailMsg += '\nHeight: ' + selectedPokemon.height + '\nWeight: ' + selectedPokemon.weight + '\nDescription: ' + selectedPokemon.description + '\nCaught: ' + selectedPokemon.status;

        if(isAvailable) {
            const options = {
                recipients: ['kev@test.com'],
                subject: `${selectedPokemon.name} - Pokémon Information`,
                body: emailMsg,
            };

            MailComposer.composeAsync(options)
                .then((result) => console.log(result.status));
        } else {
            console.log('Email is not available');
        }
    };

    return (
        <ScrollView contentContainerStyle={styles.scrollViewContainer}>
            <View style={styles.screen}>
                <View style={styles.inputContainer}>
                    <View style={styles.imageContainer}>
                        <Image style={styles.infoImage} source={{uri: route.params?.newPokemon.value.uri}}/>
                    </View>

                    <View styles={styles.section}>
                        <Text style={styles.inputLabel}>No.{route.params?.newPokemon.number} {route.params?.newPokemon.value.name}</Text>
                    </View>

                    <View style={styles.section}>
                        <Text style={styles.inputLabel}>{route.params?.newPokemon.value.category}</Text>
                    </View>

                    <View style={styles.section}>
                        <Text style={styles.inputLabel}>TYPE {route.params?.newPokemon.value.primaryType}&nbsp; 
                            {route.params?.newPokemon.value.secondaryType && (
                                <Text style={styles.inputLabel}>
                                    {route.params?.newPokemon.value.secondaryType}
                                </Text>
                            )}
                        </Text>
                    </View>

                    <View styles={styles.section}>
                        <Text style={styles.inputLabel}>HEIGHT {route.params?.newPokemon.value.height}</Text>
                        <Text style={styles.inputLabel}>WEIGHT {route.params?.newPokemon.value.weight}</Text>
                    </View>

                    <View styles={styles.section}>
                        <Text style={styles.inputLabel}>{route.params?.newPokemon.value.description}</Text>
                    </View>

                    <View styles={styles.section}>
                        {route.params?.newPokemon.value.status && (
                            <Text style={styles.inputLabel}>Caught: TRUE</Text>
                        )}

                        {!route.params?.newPokemon.value.status && (
                            <Text style={styles.inputLabel}>Caught: FALSE</Text>
                        )}
                    </View>

                    <View style={styles.buttonContainer}>
                        <Button 
                            title="Send via SMS"
                            onPress={sendMessageWithSMS}
                            color="#808000"
                        />
                    </View>
                    <View style={styles.buttonContainer}>
                        <Button 
                            title="Send via Email"
                            onPress={sendMessageWithEmail}
                            color="#808000"
                        />
                    </View>
                </View>
            </View>
        </ScrollView>
    )
}

export default PokedexInfoScreen;