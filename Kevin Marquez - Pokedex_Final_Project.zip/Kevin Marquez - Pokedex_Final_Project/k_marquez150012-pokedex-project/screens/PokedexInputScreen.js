import React, {useState, useEffect} from "react";
import {View, Button, Text, TouchableOpacity, ScrollView, Image} from "react-native";
import {styles} from "../styles/styles";
import PokemonTypeSelector from "../components/PokemonTypeSelector";
import ImageSelector from "../components/ImageSelector";
import InputField from '../components/InputFields';
import Checkbox from "expo-checkbox";

const PokedexInputScreen = ({navigation}) => {
    const [selectedImageUri, setSelectedImageUri] = useState();
    const [enteredName, setName] = useState();
    const [enteredCategory, setCategory] = useState();
    const [enteredPrimaryType, setPrimaryType] = useState([]);
    const [enteredSecondaryType, setSecondaryType] = useState([]);
    const [enteredHeight, setHeight] = useState();
    const [enteredWeight, setWeight] = useState();
    const [enteredDescription, setDescription] = useState();
    const [isCaught, setIsCaught] = useState(false);

    const imageSelectedHandler = (uri) => {
        setSelectedImageUri(uri);
    };

    const resetHandler = () => {
        setSelectedImageUri(null);
    };

    const nameInputHandler = (value) => {
        setName(value);
    };

    const categoryInputHandler = (value) => {
        setCategory(value);
    };

    const primaryTypeHandler = (value) => {
        setPrimaryType(value);
    };

    const secondaryTypeHandler = (value) => {
        setSecondaryType(value);
    };

    const heightInputHandler = (value) => {
        setHeight(value);
    };

    const weightInputHandler = (value) => {
        setWeight(value);
    };

    const descriptionInputHandler = (value) => {
        setDescription(value);
    };

    const addPokemonHandler = () => {
        const pokemonState = {
            uri: selectedImageUri,
            name: enteredName,
            category: enteredCategory,
            primaryType: enteredPrimaryType,
            secondaryType: enteredSecondaryType,
            height: enteredHeight,
            weight: enteredWeight,
            description: enteredDescription,
            status: isCaught,
        };

        resetHandler();
        setName('');
        setCategory('');
        setPrimaryType('');
        setSecondaryType('');
        setHeight('');
        setWeight('');
        setDescription('');
        setIsCaught(false);

        navigation.navigate('MainScreen', {newPokemon: pokemonState}, {merge: true});
    }

    return (
        <ScrollView contentContainerStyle={styles.scrollViewContainer}>
            <View style={styles.screen}>
                <View style={styles.inputContainer}>
                    <View style={styles.imageContainer}>
                        {!selectedImageUri ? (
                            <ImageSelector onImageSelected={imageSelectedHandler}/>
                        ) : (
                            <TouchableOpacity style={styles.imagePreview} onPress={resetHandler}>
                                <Image style={styles.image} source={{uri: selectedImageUri}}/>
                            </TouchableOpacity>
                        )}
                    </View>

                    <View styles={styles.section}>
                        <InputField label="Name" onChangeText={(text) => nameInputHandler(text)} placeHolder="Enter Pokemon Name"/>
                        <InputField label="Category" onChangeText={(text) => categoryInputHandler(text)} placeHolder="Enter Pokemon Category"/>
                    </View>

                    <View style={styles.section}>
                        <PokemonTypeSelector label="Primary Type" onChangeText={(value) => primaryTypeHandler(value)} placeHolder="Enter Type"/>
                        <PokemonTypeSelector label="Secondary Type" onChangeText={(value) => secondaryTypeHandler(value)} placeHolder="Enter Type"/>
                    </View>
                    
                    <View style={styles.section}>
                        <InputField label="Height" onChangeText={(text) => heightInputHandler(text)} placeHolder="Enter Height"/>
                        <InputField label="Weight" onChangeText={(text) => weightInputHandler(text)} placeHolder="Enter Weight"/>
                    </View>

                    <View styles={styles.section}>
                        <InputField label="Description" onChangeText={(text) => descriptionInputHandler(text)} placeHolder="Enter Description"/>
                    </View>

                    <View styles={styles.section}>
                        <Text style={styles.inputLabel}>Captured?</Text>
                        <Checkbox style={styles.checkbox} value={isCaught} onValueChange={setIsCaught}/>
                    </View>

                    <View style={styles.buttonContainer}>
                        <Button 
                            title="Add Pokemon"
                            onPress={addPokemonHandler}
                            color="#007bff"
                        />
                    </View>
                </View>
            </View>
        </ScrollView>
    )
}

export default PokedexInputScreen;