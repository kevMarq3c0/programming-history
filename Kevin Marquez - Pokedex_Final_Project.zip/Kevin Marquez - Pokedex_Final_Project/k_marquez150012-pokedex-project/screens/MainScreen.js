import React, {useEffect, useState} from "react";
import {View, Alert, Text, FlatList, TextInput, Button, ScrollView} from "react-native";
import {db, firestore, auth} from '../FirebaseConfig';
import {createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from 'firebase/auth';
import { ref, get, set } from 'firebase/database';
import CustomHeaderButton from "../components/CustomHeaderButton";
import Checkbox from "expo-checkbox";
import {styles} from "../styles/styles";
import PokedexListItem from "../components/PokedexListItem";
import * as Network from 'expo-network';

const MainScreen = ({navigation, route}) => {
    const [pokeDexList, setPokeDexList] = useState([]);
    const [pokemonNumber, setPokemonNumber] = useState(1);
    const [isInternetReachable, setIsInternetReachable] = useState();
    const [isRegistering, setIsRegistering] = useState(true);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loggedIn, setLoggedIn] = useState(false);

    const handleAuth = () => {
        if(isInternetReachable)
        {
            const action = isRegistering ? createUserWithEmailAndPassword : signInWithEmailAndPassword;
    
            action(auth, email, password)
            .then(() => {
                Alert.alert(isRegistering ? 'User registered!' : 'User logged in!');
                if (isRegistering) {
                setIsRegistering(false);
                setEmail('');
                setPassword('');
                }
                else {
                setLoggedIn(true);
                setEmail('');
                setPassword('');
                }
            })
            .catch(error => {
                Alert.alert(error.message);
                console.log(error);
            });
        } else {
            Alert.alert('No Internet', 'No Internet connection was found, please connect to Internet to use service', [{ text: 'Okay' }]);
        }
    };

    const signoutWithFirebase = () => {
        signOut(auth).then(() => {
          Alert.alert('User was logged out!');
          setLoggedIn(false);
          setPokeDexList([]);
        });
    };

    const saveDataWithFirebase = async () => {
        const userId = auth.currentUser.uid;
    
        // SAVE DATA TO REALTIME DB
        const dbRef = ref(db, 'users/' + userId);
        await set(dbRef, { pokedex: pokeDexList });
    };

    const retrieveDataFromFirebase = async () => {
        const userId = auth.currentUser.uid;
    
        // LOAD DATA FROM REALTIME DATABASE
        const dbRef = ref(db, 'users/' + userId);
        const snapshot = await get(dbRef);
        if (snapshot.exists()) {
            setPokeDexList(snapshot.val().pokedex);
        } else {
            console.log("No such document in Realtime Database!");
        }
    };

    const addPokeDexEntryHandler = (pokeDexEntry) => {
        if(!pokeDexList.find((pokemon) => pokemon.value.name === pokeDexEntry.name))
        {
            if(pokeDexList.length === 0 || pokeDexList.length === pokemonNumber) {
                console.log("PokemonNumber: " + pokemonNumber);
                setPokeDexList(pokeDexList => [...pokeDexList, {key: Math.random().toString(), number: pokemonNumber, value: pokeDexEntry}]);
                setPokemonNumber(pokemonNumber + 1);
            } else {
                let newNumber = pokeDexList.length + 1;
                console.log("New Number: " + newNumber + ", PokemonNumber: " + pokemonNumber);
                setPokeDexList(pokeDexList => [...pokeDexList, {key: Math.random().toString(), number: newNumber, value: pokeDexEntry}]);
                setPokemonNumber(newNumber + 1);
            }
        }
    };

    const goToPokemonInfoHandler = (pokemonId) => {
        let pokemonChosen = pokeDexList.find((pokemon) => pokemon.key === pokemonId);
        navigation.navigate('PokedexInfoScreen', {newPokemon: pokemonChosen}, {merge: true});
    };

    const checkNetwork = async () => {
        try {
            const networkState = await Network.getNetworkStateAsync();

            setIsInternetReachable(networkState ? networkState.isInternetReachable : false);
        } catch (e) {
            Alert.alert('Error: Internet Connectivity Issue', e.message, [{ text: 'Okay' }]);
            return false;
        }
    };

    React.useLayoutEffect(() => {
        navigation.setOptions({
            headerRight: () => (
                <CustomHeaderButton
                    title="+"
                    onPress={() => navigation.navigate('PokedexInputScreen', {pokemonNumber: pokemonNumber}, {merge: true})}
                />
            )
        })
    }, [navigation]);

    useEffect(() => {
        checkNetwork();
    }, []);

    useEffect(() => {
        if(route.params?.newPokemon) {
            addPokeDexEntryHandler(route.params?.newPokemon);
        }
    }, [route.params?.newPokemon]);

    useEffect(() => {
        if(loggedIn)
        {
            saveDataWithFirebase();
        }
    }, [pokeDexList])

    return (
        <View style={styles.screen}>
            {!loggedIn ? (
                <View style={styles.authContainer}>
                    <Text style={styles.titleText}>{isRegistering ? 'Register for' : 'Login to'} Pokedex</Text>
                    <TextInput 
                        style={styles.textInput}
                        value={email}
                        onChangeText={setEmail}
                        autoCapitalize="none"
                        autoCorrect={false}
                        keyboardType="email-address"
                        placeholder="Enter Email"
                    />
                    <TextInput
                        style={styles.textInput}
                        value={password}
                        onChangeText={setPassword}
                        autoCapitalize="none"
                        autoCorrect={false}
                        secureTextEntry
                        placeholder="Password"
                    />
                    <Button title={isRegistering ? 'Register' : 'Login'} onPress={handleAuth}/>
                    <View style={styles.checkboxContainer}>
                        <Checkbox style={styles.checkbox} value={isRegistering} onValueChange={setIsRegistering}/>
                        <Text style={styles.inputLabel}>{isRegistering ? 'Currently Registering' : 'Currently Logging in'}</Text>
                    </View>
                </View>    
            ) : (
                <View>
                    <View style={styles.list}>
                        <FlatList
                            data={pokeDexList}
                            renderItem={
                                itemData => (
                                    <PokedexListItem
                                        id={itemData.item.key}
                                        onPress={goToPokemonInfoHandler}
                                        number={itemData.item.number}
                                        item={itemData.item.value}
                                    />
                                )
                            }
                        />
                    </View> 
                    <View style={styles.bottom}>
                        <Button title="Sign Out" onPress={signoutWithFirebase} color="#CC5500" />
                        <Button title="Load Data" onPress={retrieveDataFromFirebase} color="#088F8F" />
                    </View>
                </View>
            )}
        </View>
    )
}

export default MainScreen;