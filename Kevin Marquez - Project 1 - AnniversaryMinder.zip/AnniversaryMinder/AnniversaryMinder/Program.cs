﻿/**
 * Class Name:  Program.cs
 * Purpose:     The main console of our program. This will create the AnniversaryMinder and let us populate our Anniversary and Address objects by parsing data in our anniversary-instance
 *              JSON file. We will then display the data from the JSON file and any new entries we add in a numbered list. The user will be able to various commands that will allow them 
 *              to select (From there on, edit or delete an entry), add a new entry, view all upcoming anniversaries within 2 weeks (14 days) or then choose to exit. We will then generate
 *              and write to the JSON file with data from a populated Anniversary object.
 * Coder:       Kevin Marquez
 * Date:        June 5, 2023
 */

using Newtonsoft.Json;
using Newtonsoft.Json.Schema;
using Newtonsoft.Json.Linq;
using System.IO;
using System;
using System.Text.RegularExpressions;

namespace AnniversaryMinder
{
    internal class Program
    {
        //Constant static strings that will hold the path to our JSON anniversary instance and to our schema to validate it 
        const string JsonFile = @"..\..\..\anniversary-instance.json";
        private const string JsonSchemaFile = @"..\..\..\anniversary-obj-schema.json";

        //A list and a command that will be accessible throughout all the methods, most importantly a List of Anniversary objects to allow us to write to the JSON file as an array of objects 
        static List<Anniversary?>? anniversaryList = null;
        static string command = "";
        static void Main(string[] args)
        {
            try
            {
                //Read the JSONFile and then return a string of the JSON Data
                if (ReadFile(JsonFile, out string jsonData))
                {
                    //Deserialize the string as an List of Anniversary objects
                    var anniversaryResponse = JsonConvert.DeserializeObject<List<Anniversary?>>(jsonData);

                    //Print the main menu
                    PrintMainMenu(anniversaryResponse!);
                }
            }
            catch (IOException)
            {
                Console.WriteLine("ERROR: Can't open the JSON file");
            }
            catch (JsonWriterException ex) 
            { 
                Console.WriteLine($"JSON Error: {ex.Message}");
            }
        }

        /*
         * Method Name: ReadFile
         * Purpose: Reads in a File Path into a string that represents our JSON file
         * Accepts: A string representing a string, and an output string representing our JSON string
         * Returns: A bool letting us know if it could successfully read the file 
         */
        private static bool ReadFile(string path, out string json)
        {
            try
            {
                json = File.ReadAllText(path);
                return true;
            }
            catch
            {
                json = "";
                return false;
            }
        }
        
        /*
         * Method Name: PrintMainMenu
         * Purpose: Prints the main menu to the console and checks if there is any data in our List of Anniversary objects, then prompt the user to input a command
         * Accepts: A List of Anniversary objects to constantly check updates to the data or see if there is anything
         * Returns: Nothing
         */
        static void PrintMainMenu(List<Anniversary?>? anniversaryObject)
        {
            //Clear the Console to imitate changing pages on a site and write the header 
            Console.Clear();
            Console.WriteLine("*************************************************************************");
            Console.WriteLine("*\t\tAnniversary Minder ~ All Anniversaries\t\t\t*");
            Console.WriteLine("*************************************************************************");
            Console.WriteLine("*\tName(s)\t\t\t\tDate\t\tType\t\t*");
            Console.WriteLine("*************************************************************************");

            //Check if our List is null or not, if it is then generate a new list and if not then print out all of the Anniversaries as a numbered list with their dates
            if (anniversaryObject is not null)
            {
                anniversaryList = anniversaryObject!;
                string anniversariesStringFormat = "";
                int numericListIndex = 0;

                //Iterate through the list and format the printing to the console as a numbered list 
                foreach(Anniversary? anniversary in anniversaryList)
                {
                    numericListIndex++;
                    anniversariesStringFormat += String.Format("*\t{0, -20}\t\t{1,-10}\t{2,-10:NO}\t*\n", numericListIndex + ". " + $"{anniversary!.names}", $"{anniversary!.anniversarydate}", $"{anniversary!.anniversarytype}");
                }

                //Print the formatted string to the Console representing all the Anniversaries in our list
                Console.Write(anniversariesStringFormat);
                Console.WriteLine("*************************************************************************");
            }
            else
            {
                //Generate a new list of Anniversaries if it is nnull, and let the user know there are currently no saved anniversaries 
                anniversaryList = new();
                Console.WriteLine("*\tThere are currently no saved anniversaries.\t\t\t*");
                Console.WriteLine("*************************************************************************");
            }
            //Display to the user all of the commands that they can input
            Console.WriteLine("*\tPress # from the above list to select an entry.\t\t\t*");
            Console.WriteLine("*\tPress N to add a new anniversary.\t\t\t\t*");
            Console.WriteLine("*\tPress U to list upcoming anniversaries.\t\t\t\t*");
            Console.WriteLine("*\tPress X to quit.\t\t\t\t\t\t*");
            Console.WriteLine("*************************************************************************");

            //Prompt the user to enter a command and then detemine what to execute
            Console.Write("\nEnter a command: ");
            command = Console.ReadLine() ?? "";

            DetermineUserCommand(command);
        }

        /*
         * Method Name: PrintSelectAnniversary
         * Purpose: Prints the selected Anniversary to the Console, and prompts the user whether they would like to edit or delete this anniversary, or go back to the main menu
         * Accepts: An int representing the index 
         * Returns: Nothing
         */
        static void PrintSelectAnniversary(int index)
        {
            //Clear the Console to imitate changing pages on a site and write the header
            Console.Clear();
            Console.WriteLine("*************************************************************************");
            Console.WriteLine("*\t\tAnniversary Minder ~ Selected Anniversary\t\t*");
            Console.WriteLine("*************************************************************************");
            Console.WriteLine("*\tName(s)\t\t\t\tDate\t\tType\t\t*");
            Console.WriteLine("*************************************************************************");

            //Check if our annviersary is null or not
            if(anniversaryList is not null)
            {
                //Format the string and add each line so they all match together and display the data in a visually appealing way
                string anniStringFormat = "";
                anniStringFormat += String.Format("*\t{0, -6}\t\t\t{1,-10:NO}\t\t\t\t*\n", "Names:" ,$"{anniversaryList[index]!.names}");
                anniStringFormat += String.Format("*\t{0, -6}\t\t\t{1,-10:NO}\t\t\t\t*\n", "Date:", $"{anniversaryList[index]!.anniversarydate}");
                anniStringFormat += String.Format("*\t{0, -6}\t\t\t{1,-10:NO}\t\t\t\t*\n", "Type:", $"{anniversaryList[index]!.anniversarytype}");
                anniStringFormat += String.Format("*\t{0, -11}\t\t{1,-30:NO}\t\t*\n", "Description:", $"{anniversaryList[index]!.description}");
                anniStringFormat += String.Format("*\t{0, -6}\t\t\t{1,-30:NO}\t\t*\n", "Email:", $"{anniversaryList[index]!.email}");
                anniStringFormat += String.Format("*\t{0, -6}\t\t\t{1,-10:NO}\t\t\t\t*\n", "Phone:", $"{anniversaryList[index]!.phone}");
                anniStringFormat += String.Format("*\t{0, -8}\t\t{1,-20:NO}\t\t\t*\n*\t\t\t\t{2,-30:NO}\t\t*\n", 
                    "Address:", $"{anniversaryList[index]!.address!.streetaddress}", 
                    $"{anniversaryList[index]!.address!.municipality} {anniversaryList[index]!.address!.province} {anniversaryList[index]!.address!.postalcode}");
           
                //Print out all the data 
                Console.Write( anniStringFormat );
                Console.WriteLine("*************************************************************************");
            }
            else
            {
                Console.WriteLine("*\tThere are currently no saved anniversaries.\t\t\t*");
                Console.WriteLine("*************************************************************************");
            }

            //Display the various commands that the user can choose from
            Console.WriteLine("*\tPress E to edit this anniversary\t\t\t\t*");
            Console.WriteLine("*\tPress D to delete this anniversary.\t\t\t\t*");
            Console.WriteLine("*\tPress M to return to the main menu.\t\t\t\t*");
            Console.WriteLine("*************************************************************************");

            //Prompt the user for input
            Console.Write("\nEnter a command: ");
            command = Console.ReadLine() ?? "";
            
            DetermineUserCommand(command, index);
        }

        /*
         * Method Name: PrintEditSelect
         * Purpose: Prints prompt for editing a selected Anniversary and allows the user to input new data for each line
         * Accepts: An int representing the index 
         * Returns: Nothing
         */
        static void PrintEditSelect(int selectedIndex)
        {
            //Clear the Console to imitate changing pages on a site and write the header
            Console.Clear();
            Console.WriteLine("*************************************************************************");
            Console.WriteLine("*\t\tAnniversary Minder ~ Edit Selected Anniversary\t\t*");
            Console.WriteLine("*************************************************************************");

            Console.WriteLine("KEY-IN NEW values for any field, or PRESS ENTER to accept the current field value...\n");
            //Read in the JSON Schema and get a string representing the deserialized jsonSchema
            if(ReadFile(JsonSchemaFile, out string jsonSchema))
            {
                bool valid = false;
                //Have a do while loop to ensure that the user inputs new values for each property that fits with the JSON rules
                do
                {
                    string input;
                    if (anniversaryList is not null)
                    {
                        //If the user has simply pressed enter, then do not overwrite that value in the file
                        input = GetTextInput("Name(s): " + $"{anniversaryList[selectedIndex]!.names}: ");
                        if (!string.IsNullOrEmpty(input))
                            anniversaryList[selectedIndex]!.names = input;

                        input = GetTextInput("Anniversary Type: " + $"{anniversaryList[selectedIndex]!.anniversarytype}: ");
                        if (!string.IsNullOrEmpty(input))
                            anniversaryList[selectedIndex]!.anniversarytype = input; 

                        input = GetTextInput("Description: " + $"{anniversaryList[selectedIndex]!.description}: ");
                        if (!string.IsNullOrEmpty(input))
                            anniversaryList[selectedIndex]!.description = input;

                        input = GetTextInput("Anniversary Date (yyyy-mm-dd): " + $"{anniversaryList[selectedIndex]!.anniversarydate}: ");
                        if (!string.IsNullOrEmpty(input))
                            anniversaryList[selectedIndex]!.anniversarydate = input;

                        input = GetTextInput("Email: " + $"{anniversaryList[selectedIndex]!.email}: ");
                        if(!string.IsNullOrEmpty(input))
                            anniversaryList[selectedIndex]!.email = input;

                        input = GetTextInput("Phone #: " + $"{anniversaryList[selectedIndex]!.phone}: ");
                        if(!string.IsNullOrEmpty(input))
                            anniversaryList[selectedIndex]!.phone = input;

                        input = GetTextInput("Street Address: " + $"{anniversaryList[selectedIndex]!.address!.streetaddress}: ");
                        if(!string.IsNullOrEmpty(input))
                            anniversaryList[selectedIndex]!.address!.streetaddress = input;

                        input = GetTextInput("Municipality: " + $"{anniversaryList[selectedIndex]!.address!.municipality}: ");
                        if(!string.IsNullOrEmpty(input))
                            anniversaryList[selectedIndex]!.address!.municipality = input;

                        input = GetTextInput("Province: " + $"{anniversaryList[selectedIndex]!.address!.province}: ");
                        if (!string.IsNullOrEmpty(input))
                            anniversaryList[selectedIndex]!.address!.province = input;

                        input = GetTextInput("PostalCode: " + $"{anniversaryList[selectedIndex]!.address!.postalcode}: ");
                        if(!string.IsNullOrEmpty(input))
                            anniversaryList[selectedIndex]!.address!.postalcode = input;

                        //Validate all the newly inputted values in the anniversaryList at its index
                        valid = ValidateAnniversaryData(anniversaryList[selectedIndex]!, jsonSchema, out IList<string> messages);
                        //If not validate, display an error and have them try again
                        if (!valid)
                        {
                            Console.WriteLine("\nError:\tAnniversary data does not match the required format. Please try again.\n");
                            foreach (string msg in messages)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine($"\t{msg}");
                            }
                            Console.ForegroundColor = ConsoleColor.White;
                        }
                    }
                } while (!valid);
            }
            else
            {
                Console.WriteLine("\nERROR:\tUnable to read the schema file.");
            }

            //Once it exists, try to write the Anniversary Object to the JSON file
            try
            {
               WriteAnniversaryToJsonFile(anniversaryList![selectedIndex]!, JsonFile, selectedIndex);
                //Go back to main menu after this
               PrintMainMenu(anniversaryList);
            }
            catch (JsonWriterException ex)
            {
                Console.WriteLine($"JSON Error: {ex.Message}");
            }
            catch (IOException ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        /*
         * Method Name: PrintDeleteSelect
         * Purpose: Prints prompt for deleting a selected Anniversary and asks the user to ensure that they wish to delete the item
         * Accepts: An int representing the index 
         * Returns: Nothing
         */
        static void PrintDeleteSelect(int selectedIndex)
        {
            //Clear the Console to imitate changing pages on a site and write the header
            Console.Clear();
            Console.WriteLine("*************************************************************************");
            Console.WriteLine("*\t\tAnniversary Minder ~ Delete Selected Anniversary\t*");
            Console.WriteLine("*************************************************************************");
            if(anniversaryList is not null)
            {
                bool yesDelete;
                //Prompt the user to input Y or N to verify if they wish to delete the selected item or not 
                Console.Write($"Delete \"{anniversaryList[selectedIndex]!.anniversarytype}\" anniversary for \"{anniversaryList[selectedIndex]!.names}\"? (Y/N): ");
                //Check if the key they typed is Y or y and return true if that occurred
                yesDelete = Console.ReadKey().KeyChar == 'Y' || Console.ReadKey().KeyChar == 'y';
                if (yesDelete) {
                    //Remove that item from the anniversary list 
                    anniversaryList.RemoveAt(selectedIndex);
                    selectedIndex--;
                    //Rewrite the JSON file to reflect the new changes
                    WriteAnniversaryToJsonFile(anniversaryList[selectedIndex - 1]!, JsonFile, selectedIndex);
                }
                //Return to the main menu
                PrintMainMenu(anniversaryList);
            }
            else 
            {
                Console.WriteLine("No anniversary record to delete");
            }
        }

        /*
         * Method Name: PrintAddNewAnniversary
         * Purpose: Prints prompt for adding a new Anniversary and prompts user to input the new values
         * Accepts: Nothing
         * Returns: Nothing
         */
        static void PrintAddNewAnniversary()
        {
            //Clear the console 
            Console.Clear();
            Console.WriteLine("*************************************************************************");
            Console.WriteLine("*\t\tAnniversary Minder ~ Add a New Anniversary\t\t*");
            Console.WriteLine("*************************************************************************");
            
            //Create a new Anniversary object to accept user input
            Anniversary annivObj = new Anniversary();

            Console.WriteLine("Please key-in values for the following fields...");
            //Read in the JSONSchema and return a string of the json schema to validate the user input
            if(ReadFile(JsonSchemaFile, out string jsonSchema))
            {
                bool valid;
                //Keep looping through in case the user input doesn't follow the rules of our JSON Schema
                do
                {
                    annivObj.names = GetTextInput("Name(s): ");
                    annivObj.anniversarytype = GetTextInput("Anniversary Type: ");
                    annivObj.description = GetTextInput("Description: ");
                    annivObj.anniversarydate = GetTextInput("Anniversary Date (yyyy-mm-dd): ");
                    annivObj.email = GetTextInput("Email: ");
                    annivObj.phone = GetTextInput("Phone #: ");

                    //Create a new Address object to accept user input 
                    Address addressObj = new();
                    addressObj.streetaddress = GetTextInput("Street Address: ");
                    addressObj.municipality = GetTextInput("Municipality: ");
                    addressObj.province = GetTextInput("Province: ");
                    addressObj.postalcode = GetTextInput("PostalCode: ");

                    //Initialize the Address object in our Anniversary object
                    annivObj.address = addressObj;

                    //Validate our newly made Anniversary object
                    valid = ValidateAnniversaryData(annivObj, jsonSchema, out IList<string> messages);

                    //If not valid, display an error message and keep going through the loops\
                    if (!valid)
                    {
                        Console.WriteLine("\nError:\tAnniversary data does not match the required format. Please try again.\n");
                        foreach(string msg in messages)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine($"\t{msg}");
                        }
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                } while (!valid);
            }
            else
            {
                Console.WriteLine("\nERROR:\tUnable to read the schema file.");
            }

            //Write our Anniversary List to the JSON schema and then return to the main menu
            try
            {
                WriteAnniversaryToJsonFile(annivObj, JsonFile);
                PrintMainMenu(anniversaryList);
            }
            catch (JsonWriterException ex)
            {
                Console.WriteLine($"JSON Error: {ex.Message}");
            }
            catch (IOException ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        /*
         * Method Name: PrintUpcomingAnniversary
         * Purpose: Prints the upcoming Anniversary within 2 weeks of the current date
         * Accepts: Nothing
         * Returns: Nothing
         */
        static void PrintUpcomingAnniversary()
        {
            //Clear the Console
            Console.Clear();
            Console.WriteLine("*************************************************************************");
            Console.WriteLine("* Anniversary Minder ~ Anniversaries Happening in The Next Two Weeks\t*");
            Console.WriteLine("*************************************************************************");
            Console.WriteLine("*\tName(s)\t\t\tDate\t\tType\t\tYears\t*");
            Console.WriteLine("*************************************************************************");

            //Check if our List of Anniversaries is null or not 
            if (anniversaryList is not null)
            {
                //Create a DateTime object that is the System's new date 
                DateTime today = DateTime.Today;

                string anniversariesStringFormat = "";
                //Iterate through the list of anniversaries
                foreach (Anniversary? anniversary in anniversaryList)
                {
                    //Get the date of our Anniversary object and convert to a DateTime object
                    DateTime anniversaryDate = DateTime.ParseExact(anniversary!.anniversarydate, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);

                    //Check if the anniversary date is older than our current date
                    if(today > anniversaryDate)
                    {
                        //Check the difference in years to both of the dates
                        int yearDifference = today.Year - anniversaryDate.Year;
                        //Add the year difference so we can determine if the date anniversary in our current year is within 2 weeks of the current date
                        DateTime dateToSameYear = anniversaryDate.AddYears(yearDifference);
                        
                        //See how many days are between the two dates if they were in the same year
                        double differenceInDays = (dateToSameYear - today).TotalDays;

                        //Check if the differenceIndays is 2 weeks or less
                        if(differenceInDays <= 14 && differenceInDays >= 0)
                        {
                            //Print out the Anniversary if it is 2 weeks or less of our current date
                            anniversariesStringFormat += String.Format("*\t{0, -20}\t{1,-10}\t{2,-10:NO}\t{3,2}\t*\n", $"{anniversary!.names}", $"{anniversary!.anniversarydate}", $"{anniversary!.anniversarytype}", yearDifference);
                        }
                    }
                }
                Console.Write(anniversariesStringFormat);
                Console.WriteLine("*************************************************************************");

                //Prompt the user to enter any key to return the main meny 
                Console.WriteLine("\nPress any key to return to the main menu.");
                Console.ReadKey();
                PrintMainMenu(anniversaryList);
            }
        }

        /*
         * Method Name: DetermineUserCommand
         * Purpose: Reads in user input and determines which method to execute, and checks to make sure the input is valid 
         * Accepts: A string representing the command, and an optional parameter of an int representing the index if it is from a selected entry
         * Returns: Nothing
         */
        static void DetermineUserCommand(string command, int selectIndex = -1)
        {
            //If the command is numeric, that means it is selecting an item in the list 
            int index;
            //Try to parse to ensure that it is a numeric value
            bool isNumeric = int.TryParse(command, out index);
            if (isNumeric)
            {
                //Check to make sure the index is within the range of our List of Anniversaries 
                index--;
                if (index <= anniversaryList!.Count() - 1)
                {
                    //Select that item 
                    PrintSelectAnniversary(index);
                }
                else
                {
                    //Give the command an input that will trigger an error to prompt the user to re-enter the value
                    command = "B";
                }
            }

            //In case the user typed a lowercase key of our valid letters, send to Upper Case so it doesn't cause an error
            command = command.ToUpper();

            //Check the command to determine which command to execute
            switch(command) {
                case "N":
                    PrintAddNewAnniversary();
                    break;
                case "U":
                    PrintUpcomingAnniversary();
                    break;
                case "X":
                    //We are exiting the program, print to let the user know and to have a good day
                    Console.WriteLine("\n\nExiting Anniversary Minder...Have a good day!");
                    break;
                case "E":
                    PrintEditSelect(selectIndex);
                    break;
                case "D":
                    PrintDeleteSelect(selectIndex);
                    break;
                case "M":
                    PrintMainMenu(anniversaryList);
                    break;
                default:
                    //Check to ensure that the value is a letter 
                    if(Regex.IsMatch(command, @"^[a-zA-Z]+$"))
                    {
                        //Print an error letting the user know they put invalid input
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("\nError: Invalid Input. Please try again.");
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.Write("\nEnter a command: ");
                        command = Console.ReadLine() ?? "";

                        //Prompt the user to try again
                        DetermineUserCommand(command);
                    }
                    break;
            }
        }

        /*
         * Method Name: WriteAnniversaryToJsonFile
         * Purpose: Writes the list of Anniveraries to the JSON File 
         * Accepts: An anniversary object if it is an add or delete or edit of one object, 
         *          a string representing the path to the JSON file and an optional index in case we aren't changing just one object in the list
         * Returns: Nothing
         */
        static void WriteAnniversaryToJsonFile(Anniversary anni, string path, int index = -1)
        {
            if (index == -1) {
                anniversaryList!.Add(anni);
            }
            string json = JsonConvert.SerializeObject(anniversaryList);
            File.WriteAllText(path, json);
        }

        /*
         * Method Name: GetTextInput
         * Purpose: Prompts the user for and validates input from the console 
         * Accepts: A string that we will print as the prompt, and optional parameters of the validation
         * Returns: A string 
         */
        static string GetTextInput(string prompt, string[]? fromValues = null)
        {
            bool valid;
            string input;

            do
            {
                //Print the prompt then read in user input
                Console.Write(prompt);
                Console.ForegroundColor = ConsoleColor.Yellow;
                input = Console.ReadLine() ?? "";
                Console.ForegroundColor = ConsoleColor.White;
                //IS and == works, is is new syntax
                //If it is null, we aren't even validating, making it true, if not check second condition 
                valid = fromValues is null || fromValues.Contains(input);

                if (!valid && fromValues is not null)
                {
                    Console.Write("Error: input must be one of ");
                    foreach (string value in fromValues)
                    {

                        //Add delimiter, which is just a slash character
                        //We will make this delimiter conditional
                        Console.Write(value + (value == fromValues.Last() ? "" : "/"));
                    }
                    Console.WriteLine(".");
                }
            } while (!valid);

            return input;
        }

        /*
         * Method Name: ValidateAnniversaryData
         * Purpose: Validates the user input against the JSON schema rules, and returns a list of messages detailing all inputs that were invalid
         * Accepts: An Anniversary object representing the new one made by the user, a string representing the JSONSchema and a list of messages of all invalid inputs
         * Returns: A bool letting us know if it was valid or not 
         */
        private static bool ValidateAnniversaryData(Anniversary anniversary, string jsonSchema, out IList<string> messages)
        {
            string jsonData = JsonConvert.SerializeObject(anniversary);

            JSchema schema = JSchema.Parse(jsonSchema);
            JObject anniObj = JObject.Parse(jsonData);
            return anniObj.IsValid(schema, out messages);
        }
    }
}