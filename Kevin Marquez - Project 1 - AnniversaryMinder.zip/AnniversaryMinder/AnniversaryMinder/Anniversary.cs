﻿/**
 * Class Name:  Anniversary.cs
 * Purpose:     Defines the Anniversary and Address object classes from our JSON anniversary data file so that we can serialize it using JSONConvert. 
 *              This will allow us to access the class properties that match the properties in our JSON file with getters. We can also set new a value to the properties  
 *              that we can write back to update the JSON File, while making sure to validate the newly set values to make sure they work with our schema.
 * Coder:       Kevin Marquez
 * Date:        June 5, 2023
 */

using Newtonsoft.Json;

namespace AnniversaryMinder
{
    /*
     * Class Name: Address
     * Purpose: Acts as an C# object instance of our Address object in the JSON file so that we can set and get values from it when serializing 
     */
    class Address
    {
        public string streetaddress { get; set; } = "";
        public string municipality { get; set; } = "";
        public string province { get; set; } = "";
        public string postalcode { get; set; } = "";
    }

    /*
     * Class Name: Anniversary
     * Purpose: Acts as an C# object instance of our Anniversary object in the JSON file, while also including an Address object to match the JSON Schema rules
     */
    class Anniversary
    {
        public string names { get; set; } = "";
        public string anniversarydate { get; set; } = "";
        public string anniversarytype { get; set; } = "";
        public string description { get; set; } = "";
        public string email { get; set; } = "";
        public string phone { get; set; } = "";

        public Address? address { get; set; }
    }
}
