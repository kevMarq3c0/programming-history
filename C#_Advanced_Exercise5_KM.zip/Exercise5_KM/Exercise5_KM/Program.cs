﻿/*
 * Program: Program.cs
 * Date: 2024-03-16
 * Author: Kevin Marquez #1054838
 * Purpose: This is the main method of the Exercise where we will test our Extension Method CompareTo with various list cases and print to the console a meaningful statement showing the comparison result.
 */

namespace Exercise5_KM
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Create two string lists with elements in different order
            List<string> listOfStrings = new List<string> { "widen", "castle", "enhance", "jest", "cause",};
            //Create a second list based on the first list with a randomized order
            List<string> randomListOfStrings = listOfStrings.OrderBy(item => Random.Shared.Next()).ToList();

            Console.WriteLine("The result of comparing two lists of strings with the same elements but in different orders is: " + listOfStrings.CompareTo(randomListOfStrings));

            //Create two string lists of the same length but with different elements
            List<string> equalListOfStrings = new List<string> { "pay", "junior", "uncle", "promotion", "outlook" };
            List<string> differentListOfStrings = new List<string> { "beam", "width", "determine", "balance", "budget" };

            Console.WriteLine("The result of comparing two lists of strings of the same length but different elements is: " + equalListOfStrings.CompareTo(differentListOfStrings));

            //Create two int lists with the same elements but different lengths
            List<int> threeNumbers = new List<int> { 1, 2, 3 };
            List<int> fourNumbers = new List<int> { 1, 2, 3, 4 };

            Console.WriteLine("The result of comparing two lists of ints with similar elements but of different lengths is: " + threeNumbers.CompareTo(fourNumbers));

            //Create two null lists
            List<int> firstNullList = new List<int>();
            List<int> secondNullList = new List<int>();

            Console.WriteLine("The result of comparing two null lists is: " + firstNullList.CompareTo(secondNullList));

            //Create two identical double lists, having the same elements in the same order
            List<double> listOfDoubles = new List<double> { 2.3, 3.4, 4.5, 5.6 };
            var duplicateListOfDoubles = listOfDoubles.Select(item => item);

            Console.WriteLine("The result of comparing two idential lists of doubles is: " + listOfDoubles.CompareTo(duplicateListOfDoubles));
        }
    }
}
