﻿/*
 * Program: ListExtensions.cs
 * Date: 2024-03-16
 * Author: Kevin Marquez #1054838
 * Purpose: This is a static class that will hold an extension method for generic lists to compare elements between two List instances.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise5_KM
{
    public static class ListExtensions
    {
        /*
        * Method Name: CompareTo
        * Purpose: This method will compare the elements of two List<T> instances and return if they are equal or not
        * Accepts: Two IEnumerable<T> instances, the first with keyword "this" to tell the compiler that this Extension method should be added to objects of IEnumerable<T> like List<T>
        * Returns: A boolean
        */
        public static bool CompareTo<T>(this IEnumerable<T> list, IEnumerable<T> listToCompare)
        {
            //Check if both lists are null
            if(list == null && listToCompare == null)
            {
                return true;
            }

            //Check if both lists are not the same size 
            if(list?.Count() != listToCompare.Count())
            {
                return false;
            }

            //Compare both lists by putting them in order and comparing their sequence to see if they have the same elements or not, then return the result
            return Enumerable.SequenceEqual(list.OrderBy(item => item), listToCompare.OrderBy(item => item));
        }
    }
}
