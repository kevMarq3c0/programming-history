﻿/*
 * Program: Person.cs
 * Date: 2024-01-20
 * Author: Kevin Marquez #1054838
 * Purpose: This is a parent interface whose children are the Student class and the Professor class. They will override the ToString method but the interface here will allow ToString and both classes
 *          to be stored in a unified generic list and call their methods.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise1Generics
{
    public interface IPerson
    {
        /*
         * Method Name: ToString
         * Purpose: A Interface method that will be defined by the children of the IPerson interface
         * Accepts: nothing
         * Returns: A formatted string which includes the information stored in its child classes
         */
        public string ToString();
    }
}
