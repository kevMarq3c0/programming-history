﻿/*
 * Program: GenericList.cs
 * Date: 2024-01-20
 * Author: Kevin Marquez #1054838
 * Purpose: This is a custom generic class will hold a list of type T to accept any object that is past to it. It will act similarly to generic lists defined in C#, including all the methods to
 *          insert elements, add elements, remove elements from and clear the list. It will inherit from the IEnumerable interface to help enable the class to be used in a foreach that will iterate
 *          through the generic list.
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise1Generics
{
    public class GenericList<T> : IEnumerable
    {
        //Our private members - One which is an array of T elements that can have a maximum of ten items and another which is our index counter to use in our methods
        private T[] _list = new T[10];
        private int _numberOfItems = 0;

        /*
         * Method Name: Clear
         * Purpose: It will clear the generic list and leave all its elements empty
         * Accepts: nothing
         * Returns: nothing
         */
        public void Clear()
        {
            Array.Clear(_list, 0, _list.Length);
            _numberOfItems = 0;
        }

        /*
         * Method Name: GetItem
         * Purpose: This method will return an item stored in the generic list at a given index
         * Accepts: An int which is the index to retrieve from
         * Returns: An object of Type T
         */
        public T GetItem(int index)
        {
            //If the index is out of range, throw an exception error 
            if (index < 0 || index >= _list.Length)
            {
                throw new ArgumentOutOfRangeException("index");
            }

            return _list[index];
        }

        /*
         * Method Name: Add
         * Purpose: Insert an item to the end of the generic list
         * Accepts: A object of Type T
         * Returns: nothing
         */
        public void Add(T item)
        {
            //Check if the generic list is full, throw an exception error if the user tries to add an item if it is full
            if (_numberOfItems >= _list.Length)
            {
                throw new ArgumentOutOfRangeException("item");
            }
            //Add the item to the list and increment our index counter
            _list[_numberOfItems] = item;
            _numberOfItems++;
        }

        /*
         * Method Name: Insert
         * Purpose: Adds an item at a given index without leaving gaps in the list, any previously stored items will be shifted to the right
         * Accepts: An int representing the index and an object of Type T
         * Returns: nothing
         */
        public void Insert(int index, T item)
        {
            //Validate the index and throw an exception if it is out of range
            if (index < 0 || index >= _list.Length)
            {
                throw new ArgumentOutOfRangeException("index");
            }

            //Check if the element at that index is not null, if it is then store the value currently at that index
            //and recursively call the Insert method for each element beside it to shift values to the right of the list
            if (_list[index] != null)
            {
                T oldItem = GetItem(index);
                Insert(index + 1, oldItem);
            }

            //After verifying that any previously stored values have been shifted to the right, insert the new object at the given index
            //and increment our index counter
            _list[index] = item;
            _numberOfItems++;
        }

        /*
         * Method Name: Remove
         * Purpose: Deletes an item from the generic list at a given index without leaving gaps in the list, moving items after removing the targeted elements to the left
         * Accepts: An int which is the index we will remove an element from
         * Returns: nothing
         */
        public void Remove(int index)
        {
            //Validate that the index is not out of range, if it is then throw an exception
            if (index < 0 || index >= _list.Length)
            {
                throw new ArgumentOutOfRangeException();
            }
            
            //Using a for loop, set the element at the given area to the value of the adjacent index, doing so for each index until it reaches the end
            for (int i = index; i + 1 < _list.Length; i++)
            {
                _list[i] = _list[i + 1];
            }
            //Decrement our index counter 
            _numberOfItems--;
        }

        /*
         * Method Name: GetEnumerator
         * Purpose: This method will enable foreach to iterate through the generic list
         * Accepts: nothing
         * Returns: An IEnumerator object
         */
        public IEnumerator GetEnumerator()
        {
            //Iterate through the generic list and yield the return of each index to be used when calling foreach 
            for (int i = 0; i < _list.Length; i++)
            {
                yield return _list[i];
            }
        }
    }
}
