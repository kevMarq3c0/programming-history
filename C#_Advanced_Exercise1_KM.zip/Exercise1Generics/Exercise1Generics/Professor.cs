﻿/*
 * Program: Professor.cs
 * Date: 2024-01-20
 * Author: Kevin Marquez #1054838
 * Purpose: This is a non-generic class that will generate a Professor object with four fields, the first name, last name, email and the hiring date of a Professor.
 *          It will override the ToString() method to print those fields. It is a child of the IPerson interface, which will allow the GenericList to hold various children of the IPerson interface.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise1Generics
{
    public class Professor : IPerson
    {
        //Our private fields which hold information on the Professor
        private string _firstName;
        private string _lastName;
        private string _email;
        private DateTime _hiringDate;

        //A constructor for a Professor object, which accepts 4 parameters to pass to our private fields
        public Professor(string firstName, string lastName, string email, DateTime hiringDate)
        {
            _firstName = firstName;
            _lastName = lastName;
            _email = email;
            _hiringDate = hiringDate;
        }

        /*
         * Method Name: ToString
         * Purpose: An override of the function ToString() which will return values of the Professor's member fields
         * Accepts: nothing
         * Returns: A formatted string which includes the first name, last name, email and hiring date of the Professor
         */
        public override string ToString()
        {
            return "Name: " + _firstName + " " + _lastName
                   + "\nEmail: " + _email
                   + "\nHiring Date: " + _hiringDate.ToString("MM/dd/yyyy");
        }
    }
}
