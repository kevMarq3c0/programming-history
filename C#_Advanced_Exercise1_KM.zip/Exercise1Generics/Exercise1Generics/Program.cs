﻿/*
 * Program: Program.cs
 * Date: 2024-01-20
 * Author: Kevin Marquez #1054838
 * Purpose: This is the console client where we will test our Student objects using List<T> to create and print a list of students
 */

namespace Exercise1Generics
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Create two lists for Students and Professors
            GenericList<Student> students = new GenericList<Student>();
            GenericList<Professor> professors = new GenericList<Professor>();

            //Populate the list of Students and populate the list of Professors with at least three items
            students.Add(new Student("Kevin", "Marquez", "kmar@here.com"));
            students.Add(new Student("Peter", "Parker", "ppar@here.com"));
            students.Add(new Student("Miles", "Morales", "mmor@here.com"));

            professors.Add(new Professor("Charles", "Xavier", "charles_xavier@there.com", new DateTime(1963, 9, 23)));
            professors.Add(new Professor("Thomas", "Light", "drlight@there.com", new DateTime(1987, 12, 17)));
            professors.Add(new Professor("Elven", "Gadd", "egadd@there.com", new DateTime(2001, 9, 14)));

            //Use a foreach loop to iterate through the two lists by calling the CallForEach() method and passing the GenericList objects to them
            Console.WriteLine("Students");
            Console.WriteLine("--------");
            CallForEach(students);

            Console.WriteLine("\nProfessors");
            Console.WriteLine("----------");
            CallForEach(professors);

            //Test the Clear method of the GenericList on the list of Students and display the outcomes after calling the method to the Console using a foreach loop
            Console.WriteLine("\nClear Test - Students");
            Console.WriteLine("-----------------------");
            students.Clear();
            CallForEach(students);

            //Test the Add method of the GenericList on the list of Students and display the outcomes after calling the method to the Console using a foreach loop
            Console.WriteLine("\nAdd Test - Students");
            Console.WriteLine("----------------------");
            students.Add(new Student("Kevin", "Marquez", "kmar@here.com"));
            students.Add(new Student("Peter", "Parker", "ppar@here.com"));
            students.Add(new Student("Miles", "Morales", "mmor@here.com"));
            students.Add(new Student("Harry", "Potter", "hpot@here.com"));
            CallForEach(students);

            //Test the Insert method of the GenericList on the list of Professors and display the outcomes after calling the method to the Console using a foreach loop
            Console.WriteLine("\nInsert Test - Professors");
            Console.WriteLine("--------------------------");
            professors.Insert(1, new Professor("Henry \"Indiana\"", "Jones Jr.", "indy@there.com", new DateTime(1981, 6, 21)));
            CallForEach(professors);

            //Test the Remove method  of the GenericList on the list of Students and display the outcomes after calling the method to the Console using a foreach loop
            Console.WriteLine("\nRemove Test - Students");
            Console.WriteLine("------------------------");
            students.Remove(1);
            CallForEach(students);

            //Create a unified list that holds members of both the Students and Professors altogether using the IPerson interface
            GenericList<IPerson> people = new GenericList<IPerson>
            {
                new Student("Kevin", "Marquez", "kmar@here.com"),
                new Professor("Charles", "Xavier", "charles_xavier@there.com", new DateTime(1963, 9, 23)),
                new Student("Peter", "Parker", "ppar@here.com"),
                new Professor("Thomas", "Light", "drlight@there.com", new DateTime(1987, 12, 17)),
                new Student("Miles", "Morales", "mmor@here.com"),
                new Professor("Elven", "Gadd", "egadd@there.com", new DateTime(2001, 9, 14)),
                new Student("Harry", "Potter", "hpot@here.com"),
                new Professor("Henry \"Indiana\"", "Jones Jr.", "indy@there.com", new DateTime(1981, 6, 21))
            };

            //Display the unified list to the Console
            Console.WriteLine("\nUnified List of Students and Professors test");
            Console.WriteLine("----------------------------------------------");
            CallForEach(people);
        }

        /*
         * Method Name: CallForEach
         * Purpose: This method will be used to iterate a foreach loop for various GenericList objects of type T
         * Accepts: A GenericList of type T
         * Returns: nothing
         */
        static void CallForEach<T>(GenericList<T> people)
        {
            //Grab the name of the object type stored in the GenericList
            string objectName = typeof(T).Name;

            //Use a foreach to iterate through every object in the GenericList
            foreach(T person in people)
            {
                //Validate if the object is not empty, if it returns true, call the ToString() method of the Object
                //If it returns false, then print to the Console that it is an empty object in the GenericList
                if(person != null)
                {
                    Console.WriteLine(person.ToString());
                    Console.WriteLine();
                }
                else
                {
                    Console.WriteLine("Empty " + objectName + " slot!");
                }
            }
        }
    }
}