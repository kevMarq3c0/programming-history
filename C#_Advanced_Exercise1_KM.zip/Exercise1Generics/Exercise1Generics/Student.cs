﻿/*
 * Program: Student.cs
 * Date: 2024-01-20
 * Author: Kevin Marquez #1054838
 * Purpose: This is a non-generic class that will generate a Student object with three fields, the first name, the last name and a corresponding email. It will override the ToString method
 *          to print out these fields. The Student class is a child of IPerson, which will allow the GenericList to hold various children of the IPerson interface.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise1Generics
{
    public class Student : IPerson
    {
        //Our three private fields
        private string _firstName;
        private string _lastName;
        private string _email;

        //A constructor for a Student object, which accepts 3 parameters to pass to our private fields
        public Student(string firstName, string lastName, string email)
        {
            _firstName = firstName;
            _lastName = lastName;  
            _email = email;
        }

        /*
         * Method Name: ToString
         * Purpose: An override of the function ToString() which will return the Student object's information (first name, last name and email)
         * Accepts: nothing
         * Returns: A formatted string which includes the first name, last name and email of the Student
         */
        public override string ToString()
        {
            return "Name: " + _firstName + " " + _lastName 
                    + "\nEmail: " + _email; 
        }
    }
}
